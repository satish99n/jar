﻿

-- CREATE LOGIN
PRINT  '*************************************************'         
PRINT  'Verifying if login exists for SQL/Windows authentication'
IF NOT EXISTS (     SELECT 'x' 
                           FROM   sysLogins 
                           WHERE  Name = RTRIM(REPLACE(REPLACE('$(LoggingUserAccount)','[',''),']',''))
                      )
BEGIN
       IF     N'$(LoggingAuthType)' = 'S'
       BEGIN
                    PRINT  '*************************************************'
                    PRINT 'Login doesn''t exist. creating new login account : ' + N'$(LoggingUserAccount)'
                    CREATE LOGIN [$(LoggingUserAccount)] WITH PASSWORD = '$(LoggingUserPassword)'
                    PRINT  '*************************************************'
       END
       IF     N'$(LoggingAuthType)' = 'W'
       BEGIN

                    PRINT  '*************************************************'
                    PRINT 'Login doesn''t exist. creating new login account : ' + N'$(LoggingUserAccount)'
                    CREATE LOGIN [$(LoggingUserAccount)] FROM WINDOWS;
                    PRINT  '*************************************************'
       END

END
ELSE
BEGIN
             PRINT  '*************************************************'
             PRINT N'$(LoggingUserAccount)' + ' login already exists.' 
             PRINT  '*************************************************'
END    

-- CREATE User
IF NOT EXISTS (     SELECT 'x' 
                           FROM   Sysusers WHERE      Name = RTRIM(REPLACE(REPLACE('$(LoggingUserAccount)','[',''),']',''))
                      )
BEGIN
       PRINT 'User doesn''t Exist.creating new user account : ' + N'$(LoggingUserAccount)'
       CREATE USER [$(LoggingUserAccount)] FOR LOGIN [$(LoggingUserAccount)]
END    
ELSE
BEGIN
       PRINT N'$(LoggingUserAccount)' + ' User already exists.'
END

PRINT	'********Granting Execute Permission to Tables-Start******************'
GRANT INSERT ON dbo.LogEntry					TO [$(LoggingUserAccount)];
PRINT	'********Granting Execute Permission to Tables-Complete******************'


