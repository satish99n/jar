﻿ALTER TABLE [dbo].[LogEntry]
	ADD CONSTRAINT [PK_LogEntry]
	PRIMARY KEY (LogEntryKey)
