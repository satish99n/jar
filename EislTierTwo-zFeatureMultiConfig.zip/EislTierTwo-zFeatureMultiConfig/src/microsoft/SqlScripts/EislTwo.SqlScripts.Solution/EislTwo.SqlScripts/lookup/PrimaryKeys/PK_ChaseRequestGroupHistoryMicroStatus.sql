﻿ALTER TABLE [lookup].[ChaseRequestGroupHistoryMicroStatus]
	ADD CONSTRAINT [PK_ChaseRequestGroupHistoryMicroStatus]
	PRIMARY KEY (ChaseRequestGroupHistoryMicroStatusKey)
