﻿CREATE TABLE [lookup].[EMROrganization]
(	EMROrganizationKey		SMALLINT		NOT NULL,
	EMROrganizationCode		VARCHAR(10)		NOT NULL,
	EMROrganizationName		NVARCHAR(256)	NOT NULL,
	InsertDate				DATETIME		CONSTRAINT [DF_EMROrganization_InsertDate]		DEFAULT CURRENT_TIMESTAMP NOT NULL		,
	InsertedBy				NVARCHAR(64)	CONSTRAINT [DF_EMROrganization_InsertedBy]		DEFAULT SUSER_SNAME() NOT NULL			,
	LastUpdated				DATETIME		CONSTRAINT [DF_EMROrganization_LastUpdated]		DEFAULT CURRENT_TIMESTAMP NOT NULL		,
	LastUpdatedBy			NVARCHAR(64)	CONSTRAINT [DF_EMROrganization_LastUpdatedBy]	DEFAULT SUSER_SNAME() NOT NULL			,
	CONSTRAINT [UQ_EMROrganization_EMROrganizationCode] UNIQUE(EMROrganizationCode) 
)		
