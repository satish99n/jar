﻿ALTER TABLE [lookup].[ClinicalDataOriginMacroStatus]
       ADD CONSTRAINT [PK_ClinicalDataOriginMacroStatus]
       PRIMARY KEY (ClinicalDataOriginMacroStatusKey)
