﻿ALTER TABLE [lookup].[ClinicalDataOriginSettingType]
	ADD CONSTRAINT [PK_ClinicalDataOriginSettingType]
	PRIMARY KEY (ClinicalDataOriginSettingTypeKey)
