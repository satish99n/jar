﻿CREATE TABLE [lookup].[ChaseRequestHistoryMicroStatus]
(
	ChaseRequestHistoryMicroStatusKey		SMALLINT		NOT NULL,
    ChaseRequestHistoryMicroStatusName		VARCHAR(64)     NOT NULL,
	ChaseRequestHistoryMacroStatusKey		SMALLINT		NOT NULL, /* FK to "Parent" */
    InsertDate								DATETIME        CONSTRAINT [DF_ChaseRequestHistoryMicroStatus_InsertDate]		DEFAULT CURRENT_TIMESTAMP	NOT NULL,
    InsertedBy								NVARCHAR(64)    CONSTRAINT [DF_ChaseRequestHistoryMicroStatus_InsertedBy]		DEFAULT SUSER_SNAME()		NOT NULL,
    LastUpdated								DATETIME        CONSTRAINT [DF_ChaseRequestHistoryMicroStatus_LastUpdated]		DEFAULT CURRENT_TIMESTAMP	NOT NULL,
    LastUpdatedBy							NVARCHAR(64)    CONSTRAINT [DF_ChaseRequestHistoryMicroStatus_LastUpdatedBy]	DEFAULT SUSER_SNAME()		NOT NULL
)
