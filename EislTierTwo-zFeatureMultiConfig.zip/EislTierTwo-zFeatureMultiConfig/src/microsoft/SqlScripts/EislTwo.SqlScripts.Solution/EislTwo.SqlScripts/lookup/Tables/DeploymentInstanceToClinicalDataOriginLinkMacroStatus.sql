﻿
CREATE TABLE [lookup].[DeploymentInstanceToClinicalDataOriginLinkMacroStatus]
(
    [DeploymentInstanceToClinicalDataOriginLinkMacroStatusKey]        SMALLINT            NOT NULL,
    [DeploymentInstanceToClinicalDataOriginLinkMacroStatusName]          VARCHAR(64)     NOT NULL,
    [InsertDate]                                                     DATETIME        CONSTRAINT [DF_DeploymentInstanceToClinicalDataOriginLinkMacroStatus_InsertDate]    DEFAULT CURRENT_TIMESTAMP   NOT NULL,
    [InsertedBy]                                                     NVARCHAR(64)    CONSTRAINT [DF_DeploymentInstanceToClinicalDataOriginLinkMacroStatus_InsertedBy]    DEFAULT SUSER_SNAME()             NOT NULL,
    [LastUpdated]                                                    DATETIME        CONSTRAINT [DF_DeploymentInstanceToClinicalDataOriginLinkMacroStatus_LastUpdated]   DEFAULT CURRENT_TIMESTAMP   NOT NULL,
    [LastUpdatedBy]                                           NVARCHAR(64)    CONSTRAINT [DF_DeploymentInstanceToClinicalDataOriginLinkMacroStatus_LastUpdatedBy] DEFAULT SUSER_SNAME()             NOT NULL,
       CONSTRAINT [UC_DeploymentInstanceToClinicalDataOriginLinkMacroStatus_DeploymentInstanceToClinicalDataOriginLinkMacroStatusName]UNIQUE(DeploymentInstanceToClinicalDataOriginLinkMacroStatusName)
)
