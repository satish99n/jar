﻿ALTER TABLE [lookup].[ChaseRequestGroupTrigger]
	ADD CONSTRAINT [PK_ChaseRequestGroupTrigger]
	PRIMARY KEY (ChaseRequestGroupTriggerKey)
