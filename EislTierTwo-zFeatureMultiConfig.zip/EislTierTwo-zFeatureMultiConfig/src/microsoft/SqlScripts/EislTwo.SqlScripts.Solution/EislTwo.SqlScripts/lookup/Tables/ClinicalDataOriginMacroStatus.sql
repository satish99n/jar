﻿
CREATE TABLE [lookup].[ClinicalDataOriginMacroStatus]
(
    [ClinicalDataOriginMacroStatusKey]        SMALLINT            NOT NULL,
    [ClinicalDataOriginMacroStatusName]          VARCHAR(64)     NOT NULL,
    [InsertDate]                                                     DATETIME        CONSTRAINT [DF_ClinicalDataOriginMacroStatus_InsertDate]    DEFAULT CURRENT_TIMESTAMP   NOT NULL,
    [InsertedBy]                                                     NVARCHAR(64)    CONSTRAINT [DF_ClinicalDataOriginMacroStatus_InsertedBy]    DEFAULT SUSER_SNAME()             NOT NULL,
    [LastUpdated]                                                    DATETIME        CONSTRAINT [DF_ClinicalDataOriginMacroStatus_LastUpdated]   DEFAULT CURRENT_TIMESTAMP   NOT NULL,
    [LastUpdatedBy]                                           NVARCHAR(64)    CONSTRAINT [DF_ClinicalDataOriginMacroStatus_LastUpdatedBy] DEFAULT SUSER_SNAME()             NOT NULL,
       CONSTRAINT [UC_ClinicalDataOriginMacroStatus_ClinicalDataOriginMacroStatusName]UNIQUE(ClinicalDataOriginMacroStatusName)
)
