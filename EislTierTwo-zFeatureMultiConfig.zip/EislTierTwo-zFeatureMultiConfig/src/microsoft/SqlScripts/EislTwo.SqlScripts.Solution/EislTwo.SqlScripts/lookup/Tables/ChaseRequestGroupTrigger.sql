﻿CREATE TABLE [lookup].[ChaseRequestGroupTrigger]
(
	ChaseRequestGroupTriggerKey				SMALLINT		NOT NULL,
    ChaseRequestGroupTriggerName			VARCHAR(64)     NOT NULL,
    InsertDate								DATETIME        CONSTRAINT [DF_ChaseRequestGroupOrigin_InsertDate]	DEFAULT CURRENT_TIMESTAMP	NOT NULL,
    InsertedBy								NVARCHAR(64)    CONSTRAINT [DF_ChaseRequestGroupOrigin_InsertedBy]	DEFAULT SUSER_SNAME()		NOT NULL,
    LastUpdated								DATETIME        CONSTRAINT [DF_ChaseRequestGroupOrigin_LastUpdated]	DEFAULT CURRENT_TIMESTAMP	NOT NULL,
    LastUpdatedBy							NVARCHAR(64)    CONSTRAINT [DF_ChaseRequestGroupOrigin_LastUpdatedBy]	DEFAULT SUSER_SNAME()		NOT NULL
)
