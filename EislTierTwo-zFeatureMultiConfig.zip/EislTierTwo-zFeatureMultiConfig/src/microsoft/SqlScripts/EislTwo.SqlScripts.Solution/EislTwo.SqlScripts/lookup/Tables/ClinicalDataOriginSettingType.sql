﻿CREATE TABLE [lookup].[ClinicalDataOriginSettingType]
(
	ClinicalDataOriginSettingTypeKey		SMALLINT		NOT NULL,
    ClinicalDataOriginSettingTypeName		VARCHAR(64)     NOT NULL,
	ClinicalDataOriginSettingTypeDescription		VARCHAR(1024)     NOT NULL,
	IsSecure								BIT NOT NULL,
    InsertDate								DATETIME        CONSTRAINT [DF_ClinicalDataOriginSettingType_InsertDate]	DEFAULT CURRENT_TIMESTAMP	NOT NULL,
    InsertedBy								NVARCHAR(64)    CONSTRAINT [DF_ClinicalDataOriginSettingType_InsertedBy]	DEFAULT SUSER_SNAME()		NOT NULL,
    LastUpdated								DATETIME        CONSTRAINT [DF_ClinicalDataOriginSettingType_LastUpdated]	DEFAULT CURRENT_TIMESTAMP	NOT NULL,
    LastUpdatedBy							NVARCHAR(64)    CONSTRAINT [DF_ClinicalDataOriginSettingType_LastUpdatedBy]	DEFAULT SUSER_SNAME()		NOT NULL
)
