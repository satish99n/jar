﻿ALTER TABLE [lookup].[DeploymentInstanceToClinicalDataOriginLinkMacroStatus]
       ADD CONSTRAINT [PK_DeploymentInstanceToClinicalDataOriginLinkMacroStatus]
       PRIMARY KEY (DeploymentInstanceToClinicalDataOriginLinkMacroStatusKey)
