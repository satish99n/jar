﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

SET NOCOUNT ON

/* DEVELOPER READ ME

IF YOU CHANGE THIS FILE, YOU NEED TO UPDATE THE ~DICTIONARY~ java file.
	com.uhc.ucs.cdsm.domain.dictionaries.ClinicalDataOriginSettingTypeDictionary

*/

/* Please use 
Title Case, aka Initial Caps, aka Proper Case for ClinicalDataOriginSettingTypeName
*/
 
MERGE INTO [lookup].[ClinicalDataOriginSettingType] AS TARGET
USING
(
	VALUES
		(111,	'ProviderGroupId', 'Provider Group ID',0)
		, (122,	'EmrStandardCode', 'Standard Code for each EMR',0)
		, (133,	'TransportProtocol', '',0)
		, (201,	'Unity.Program.Fhir.Endpoint', 'Unity Program Fhir Endpoint',0)
		, (202,	'Unity.Program.Unity.Endpoint', 'Unity Program Unity Endpoint',0)
		, (203,	'Unity.Program.Unity.User', 'Unity Program Unity User',1)
		, (204,	'Unity.Program.Unity.Password', 'Unity Program Unity Password',1)
		, (205,	'Unity.Program.Svc.User', 'Unity Program Svc User',1)
		, (206,	'Unity.Program.Svc.Password', 'Unity Program Svc Password',1)
		, (207,	'Unity.Program.Unity.Appname', 'Unity Program Unity Appname',0)
		, (208,	'Unity.Program.Ehr.Touchworks.Fhir.oauth.Authorize', 'Ehr.touchworks.fhir.oauth.authorize',0)
		, (209,	'Unity.Program.Ehr.Touchworks.Fhir.oauth.Token', 'Ehr.touchworks.fhir.oauth.token',0)
		, (210,	'Unity.Program.Ehr.Allscripts.Redirect.Uri', 'Ehr.Allscripts.redirect.uri',0)
		, (211,	'Unity.Program.Ehr.Allscripts.Client.Id', 'Client Id',1)
		, (212,	'Unity.Program.Ehr.Allscripts.Client.Secret', 'Client Secret',1)
		, (301,	'LookbackDaysForRecurringJob', 'Numbers of days to go back for determining start date for the recurring job',1)
) 
AS SOURCE ([ClinicalDataOriginSettingTypeKey], [ClinicalDataOriginSettingTypeName], [ClinicalDataOriginSettingTypeDescription],[IsSecure])
ON (TARGET.[ClinicalDataOriginSettingTypeKey] = SOURCE.[ClinicalDataOriginSettingTypeKey])
WHEN MATCHED THEN
	UPDATE SET
		[ClinicalDataOriginSettingTypeName] = SOURCE.[ClinicalDataOriginSettingTypeName],
		[ClinicalDataOriginSettingTypeDescription] = SOURCE.[ClinicalDataOriginSettingTypeDescription],
		[IsSecure] =SOURCE.[IsSecure],
		[LastUpdated] = CURRENT_TIMESTAMP,
		[LastUpdatedBy] = SUSER_SNAME()       

WHEN NOT MATCHED BY TARGET THEN
	INSERT([ClinicalDataOriginSettingTypeKey], [ClinicalDataOriginSettingTypeName], [ClinicalDataOriginSettingTypeDescription], [IsSecure],[InsertDate], [InsertedBy], [LastUpdated], [LastUpdatedBy])
	VALUES(SOURCE.[ClinicalDataOriginSettingTypeKey], SOURCE.[ClinicalDataOriginSettingTypeName], SOURCE.[ClinicalDataOriginSettingTypeDescription],SOURCE.[IsSecure], CURRENT_TIMESTAMP, SUSER_SNAME(), CURRENT_TIMESTAMP, SUSER_SNAME())

WHEN NOT MATCHED BY SOURCE THEN 
 DELETE; 
GO

DECLARE @mergeError INT, @mergeCount INT

SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT
IF (@mergeError != 0)
BEGIN
	PRINT 'ERROR OCCURRED IN MERGE FOR [ClinicalDataOriginSettingType]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); 
END
ELSE
BEGIN
	PRINT '[ClinicalDataOriginSettingType] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));
END
GO
 
SET NOCOUNT OFF
GO
