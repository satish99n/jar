﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

SET NOCOUNT ON

/* DEVELOPER READ ME

IF YOU CHANGE THIS FILE, YOU NEED TO UPDATE THE ~DICTIONARY~ java file.
	com.uhc.ucs.cdsm.domain.dictionaries.SystemSettingDictionary

*/

/* Please use 
Title Case, aka Initial Caps, aka Proper Case for SettingKeyName and SettingKeyDisplayName
*/
 
MERGE INTO [settings].[SystemSetting] AS TARGET
USING
(
	VALUES
		(101,	1, 'JobProcessingBetweenRunsSleepMilliseconds', 'Job Processing BetweenRunsSleep Milliseconds', '20000')
		, (201,	2, 'UnitedRegexOne', 'United Regex One', '(?i:.*UNITED.*)')
		, (202,	2, 'UnitedRegexTwo', 'United Regex Two', '(?i:.*UHG.*)')
		, (203,	2, 'UnitedRegexThree', 'United Regex Three', '(?i:.*UHC.*)')
		, (301,	3, 'CrontabExpression', 'Crontab Expression', '*/5 * * * * *')
		, (302,	3, 'NumberOfDays', 'Number Of Days', '1')
		, (401,	4, 'BlacklistRegexOne', 'Blacklist Regex One', '(?i:.*SELFPAY.*)')
		, (501,	5, 'DefaultHistoryDataNumberOfDays', 'DefaultHistoryDataNumber Of Days', '3')
		, (601,	6, 'PatientDetailsGetTimeoutSeconds', 'Patient Details Get Timeout Seconds', '60')
+		, (602,	6, 'DocumentRetrieveTimeoutSeconds', 'Document Retrieve Timeout Seconds', '60')
) 
AS SOURCE ([SystemSettingKey], [SystemSettingCategoryKey], [SettingKeyName], [SettingKeyDisplayName], [SettingValue])
ON (TARGET.[SystemSettingKey] = SOURCE.[SystemSettingKey])

WHEN MATCHED THEN
	UPDATE SET
		[SystemSettingCategoryKey] = SOURCE.[SystemSettingCategoryKey], 
		[SettingKeyName] = SOURCE.[SettingKeyName],
		[SettingKeyDisplayName] = SOURCE.[SettingKeyDisplayName],
		/* [SettingValue] = SOURCE.[SettingValue], */ /* Do NOT update the SettingValue when matched */
		[LastUpdated] = CURRENT_TIMESTAMP,
		[LastUpdatedBy] = SUSER_SNAME()       

WHEN NOT MATCHED BY TARGET THEN
	INSERT([SystemSettingKey], [SystemSettingCategoryKey], [SettingKeyName], [SettingKeyDisplayName], [SettingValue], [InsertDate], [InsertedBy], [LastUpdated], [LastUpdatedBy])
	VALUES(SOURCE.[SystemSettingKey], SOURCE.[SystemSettingCategoryKey], SOURCE.[SettingKeyName], SOURCE.[SettingKeyDisplayName], SOURCE.[SettingValue], CURRENT_TIMESTAMP, SUSER_SNAME(), CURRENT_TIMESTAMP, SUSER_SNAME())

WHEN NOT MATCHED BY SOURCE THEN 
 DELETE; 
GO

DECLARE @mergeError INT, @mergeCount INT

SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT
IF (@mergeError != 0)
BEGIN
	PRINT 'ERROR OCCURRED IN MERGE FOR [SystemSetting]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); 
END
ELSE
BEGIN
	PRINT '[SystemSetting] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));
END
GO
 
SET NOCOUNT OFF
GO
