﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

SET NOCOUNT ON

/* DEVELOPER READ ME

IF YOU CHANGE THIS FILE, YOU NEED TO UPDATE THE ~DICTIONARY~ java file.
	com.uhc.ucs.cdsm.domain.dictionaries.ClinicalDataOriginSettingTypeDictionary

*/

/* Please use 
Title Case, aka Initial Caps, aka Proper Case for ClinicalDataOriginSettingTypeName
*/
 
MERGE INTO [lookup].[DeploymentInstanceToClinicalDataOriginLinkMacroStatus] AS TARGET
USING
(
       VALUES
               (1,  'Active')
             , (2,  'Inactive')
			 , (3,  'Suspended')
             
) 
AS SOURCE ([DeploymentInstanceToClinicalDataOriginLinkMacroStatusKey], [DeploymentInstanceToClinicalDataOriginLinkMacroStatusName])
ON (TARGET.[DeploymentInstanceToClinicalDataOriginLinkMacroStatusKey] = SOURCE.[DeploymentInstanceToClinicalDataOriginLinkMacroStatusKey])

WHEN MATCHED THEN
       UPDATE SET
             [DeploymentInstanceToClinicalDataOriginLinkMacroStatusName] = SOURCE.[DeploymentInstanceToClinicalDataOriginLinkMacroStatusName]

WHEN NOT MATCHED BY TARGET THEN
       INSERT([DeploymentInstanceToClinicalDataOriginLinkMacroStatusKey], [DeploymentInstanceToClinicalDataOriginLinkMacroStatusName])
       VALUES(SOURCE.[DeploymentInstanceToClinicalDataOriginLinkMacroStatusKey], SOURCE.[DeploymentInstanceToClinicalDataOriginLinkMacroStatusName])

WHEN NOT MATCHED BY SOURCE THEN 
 DELETE; 
GO

DECLARE @mergeError INT, @mergeCount INT

SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT
IF (@mergeError != 0)
BEGIN
       PRINT 'ERROR OCCURRED IN MERGE FOR [DeploymentInstanceToClinicalDataOriginLinkMacroStatus]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); 
END
ELSE
BEGIN
       PRINT '[DeploymentInstanceToClinicalDataOriginLinkMacroStatus] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));
END
GO
 
SET NOCOUNT OFF
GO
