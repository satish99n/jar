﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

SET NOCOUNT ON

/* DEVELOPER READ ME

IF YOU CHANGE THIS FILE, YOU NEED TO UPDATE THE ~DICTIONARY~ java file.
	com.uhc.ucs.cdsm.domain.dictionaries.ClinicalDataOriginSettingTypeDictionary

*/

/* Please use 
Title Case, aka Initial Caps, aka Proper Case for ClinicalDataOriginSettingTypeName
*/
 
MERGE INTO [lookup].[ClinicalDataOriginMacroStatus] AS TARGET
USING
(
       VALUES
               (1,  'Active')
             , (2,  'Inactive')
             
) 
AS SOURCE ([ClinicalDataOriginMacroStatusKey], [ClinicalDataOriginMacroStatusName])
ON (TARGET.[ClinicalDataOriginMacroStatusKey] = SOURCE.[ClinicalDataOriginMacroStatusKey])

WHEN MATCHED THEN
       UPDATE SET
             [ClinicalDataOriginMacroStatusName] = SOURCE.[ClinicalDataOriginMacroStatusName]

WHEN NOT MATCHED BY TARGET THEN
       INSERT([ClinicalDataOriginMacroStatusKey], [ClinicalDataOriginMacroStatusName])
       VALUES(SOURCE.[ClinicalDataOriginMacroStatusKey], SOURCE.[ClinicalDataOriginMacroStatusName])

WHEN NOT MATCHED BY SOURCE THEN 
 DELETE; 
GO

DECLARE @mergeError INT, @mergeCount INT

SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT
IF (@mergeError != 0)
BEGIN
       PRINT 'ERROR OCCURRED IN MERGE FOR [ClinicalDataOriginMacroStatus]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); 
END
ELSE
BEGIN
       PRINT '[ClinicalDataOriginMacroStatus] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));
END
GO
 
SET NOCOUNT OFF
GO
