﻿

-- CREATE LOGIN
PRINT  '*************************************************'         
PRINT  'Verifying if login exists for SQL/Windows authentication'
IF NOT EXISTS (     SELECT 'x' 
                           FROM   sysLogins 
                           WHERE  Name = RTRIM(REPLACE(REPLACE('$(CoreUserAccount)','[',''),']',''))
                      )
BEGIN
       IF     N'$(CoreAuthType)' = 'S'
       BEGIN
                    PRINT  '*************************************************'
                    PRINT 'Login doesn''t exist. creating new login account : ' + N'$(CoreUserAccount)'
                    CREATE LOGIN [$(CoreUserAccount)] WITH PASSWORD = '$(CoreUserPassword)'
                    PRINT  '*************************************************'
       END
       IF     N'$(CoreAuthType)' = 'W'
       BEGIN

                    PRINT  '*************************************************'
                    PRINT 'Login doesn''t exist. creating new login account : ' + N'$(CoreUserAccount)'
                    CREATE LOGIN [$(CoreUserAccount)] FROM WINDOWS;
                    PRINT  '*************************************************'
       END

END
ELSE
BEGIN
             PRINT  '*************************************************'
             PRINT N'$(CoreUserAccount)' + ' login already exists.' 
             PRINT  '*************************************************'
END    

-- CREATE User
IF NOT EXISTS (     SELECT 'x' 
                           FROM   Sysusers WHERE      Name = RTRIM(REPLACE(REPLACE('$(CoreUserAccount)','[',''),']',''))
                      )
BEGIN
       PRINT 'User doesn''t Exist.creating new user account : ' + N'$(CoreUserAccount)'
       CREATE USER [$(CoreUserAccount)] FOR LOGIN [$(CoreUserAccount)]
END    
ELSE
BEGIN
       PRINT N'$(CoreUserAccount)' + ' User already exists.'
END

PRINT  '********Granting Execute Permission to Stored Procedures-Start******************'
GRANT EXECUTE ON dbo.uspPatientEncounterUpsert                           TO [$(CoreUserAccount)];
GRANT EXECUTE ON dbo.uspChaseRequestGroupDeepGetByKey              TO [$(CoreUserAccount)];
GRANT EXECUTE ON dbo.uspChaseRequestGroupHistoryInsertSingle       TO [$(CoreUserAccount)];
GRANT EXECUTE ON dbo.uspChaseRequestHistoryInsertSingle                  TO [$(CoreUserAccount)];
GRANT EXECUTE ON dbo.uspEncounterUpdateSingle                            TO [$(CoreUserAccount)];
GRANT EXECUTE ON dbo.uspPatientGetSingleByKey                            TO [$(CoreUserAccount)];
GRANT EXECUTE ON [settings].[uspSystemSettingGetByCategoryKey]  TO [$(CoreUserAccount)];
GRANT EXECUTE ON [history].[uspInsuranceHistoryInsertDistinct]  TO [$(CoreUserAccount)];
GRANT EXECUTE ON [settings].[uspClinicalDataOriginAllSettingGetByClinicalDataOriginKey] TO [$(CoreUserAccount)];
PRINT  '********Granting Execute Permission to Stored Procedures-Complete******************'

