﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

SET NOCOUNT ON

/* DEVELOPER READ ME

IF YOU CHANGE THIS FILE, YOU NEED TO UPDATE THE ~DICTIONARY~ java file.
	com.uhc.ucs.cdsm.domain.dictionaries.ChaseRequestGroupTriggerDictionary

*/

/* Please use 
Title Case, aka Initial Caps, aka Proper Case for ChaseRequestGroupTriggerName
*/
 
MERGE INTO [lookup].[ChaseRequestGroupTrigger] AS TARGET
USING
(
	VALUES
		(55,	'Recurring Job')
		, (77,	'Historical Pull')
) 
AS SOURCE ([ChaseRequestGroupTriggerKey], [ChaseRequestGroupTriggerName])
ON (TARGET.[ChaseRequestGroupTriggerKey] = SOURCE.[ChaseRequestGroupTriggerKey])
WHEN MATCHED THEN
	UPDATE SET
		[ChaseRequestGroupTriggerName] = SOURCE.[ChaseRequestGroupTriggerName],
		[LastUpdated] = CURRENT_TIMESTAMP,
		[LastUpdatedBy] = SUSER_SNAME()       

WHEN NOT MATCHED BY TARGET THEN
	INSERT([ChaseRequestGroupTriggerKey], [ChaseRequestGroupTriggerName], [InsertDate], [InsertedBy], [LastUpdated], [LastUpdatedBy])
	VALUES(SOURCE.[ChaseRequestGroupTriggerKey], SOURCE.[ChaseRequestGroupTriggerName], CURRENT_TIMESTAMP, SUSER_SNAME(), CURRENT_TIMESTAMP, SUSER_SNAME())

WHEN NOT MATCHED BY SOURCE THEN 
 DELETE; 
GO

DECLARE @mergeError INT, @mergeCount INT

SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT
IF (@mergeError != 0)
BEGIN
	PRINT 'ERROR OCCURRED IN MERGE FOR [ChaseRequestGroupTrigger]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); 
END
ELSE
BEGIN
	PRINT '[ChaseRequestGroupTrigger] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));
END
GO
 
SET NOCOUNT OFF
GO
