
PRINT 'Checking if Master Key exists ......'
IF EXISTS (
			SELECT name FROM sys.symmetric_keys
			WHERE name LIKE '%DatabaseMasterKey%'

          )
BEGIN
	PRINT '...............................................'
	PRINT 'Master Key already exists in the database......'
END
ELSE
BEGIN
	PRINT 'Master Key doesn''t exists in the database......'
	
	PRINT 'Creating Master Key in the database......'
	CREATE MASTER KEY ENCRYPTION BY PASSWORD = '$(CoreMasterKeyPassword)'
	PRINT 'Master Key created in the database..............'

END

PRINT '...................................'
PRINT '...................................'

PRINT 'Checking if Certificate already exists ......'
IF EXISTS (
			SELECT name FROM sys.certificates
			WHERE name = N'$(CoreCertificateName)'

          )
BEGIN
	PRINT '...................................'
	PRINT 'Cerficate already exists..........'

END
ELSE
BEGIN
	PRINT 'Cerficate doesnt exists..........'
	PRINT 'Creating Cerficate...............'
    CREATE CERTIFICATE [$(CoreCertificateName)] WITH SUBJECT = 'Clinical Data Origin Secret Values';	

	PRINT 'Cerficate Created...............'
END

PRINT '...................................'
PRINT '...................................'

PRINT 'Checking if sysmmetric key exists ......'
IF EXISTS (
			SELECT name FROM sys.symmetric_keys
			WHERE name = N'$(CoreSymmetricKeyName)'

          )
BEGIN
	PRINT '...................................'
	PRINT 'Symmetric Key already exists.......'

END
ELSE
BEGIN
	PRINT 'Symmetric Key doesnt exists.......'
	PRINT 'Creating Symmetric Key............'

	CREATE SYMMETRIC KEY [$(CoreSymmetricKeyName)] WITH ALGORITHM = AES_256 
    ENCRYPTION BY CERTIFICATE [$(CoreCertificateName)] ;  
	
	PRINT 'Symmetric Key Created............'

END
PRINT '................................................................'
PRINT '................................................................'

PRINT 'Granting permission to Symmetrickey to ' + '$(CoreUserAccount)'
GRANT VIEW  DEFINITION ON SYMMETRIC KEY::[$(CoreSymmetricKeyName)] TO [$(CoreUserAccount)];		
PRINT 'Granting permission to certifcate to ' + '$(CoreUserAccount)'
GRANT CONTROL  ON CERTIFICATE::[$(CoreCertificateName)]			   TO [$(CoreUserAccount)];