﻿CREATE TABLE [settings].[ClinicalDataOriginSecureSetting]

(	ClinicalDataOriginSecureSettingKey				INT					NOT NULL,
	ClinicalDataOriginKey							INT					NOT NULL,
	ClinicalDataOriginSettingTypeKey				SMALLINT			NOT NULL,
	ClinicalDataOriginSecureSettingValue			VARBINARY(MAX),
	InsertDate										DATETIME		CONSTRAINT [DF_ClinicalDataOriginSecureSetting_InsertDate]		DEFAULT CURRENT_TIMESTAMP NOT NULL		,
	InsertedBy										NVARCHAR(64)	CONSTRAINT [DF_ClinicalDataOriginSecureSetting_InsertedBy]		DEFAULT SUSER_SNAME() NOT NULL			,
	LastUpdated										DATETIME		CONSTRAINT [DF_ClinicalDataOriginSecureSetting_LastUpdated]		DEFAULT CURRENT_TIMESTAMP NOT NULL		,
	LastUpdatedBy									NVARCHAR(64)	CONSTRAINT [DF_ClinicalDataOriginSecureSetting_LastUpdatedBy]	DEFAULT SUSER_SNAME() NOT NULL			,
	CONSTRAINT [UQ_ClinicalDataOriginSecureSetting_ClinicalDataOriginKey_ClinicalDataOriginSettingTypeKey] UNIQUE(ClinicalDataOriginKey,ClinicalDataOriginSettingTypeKey) 
)