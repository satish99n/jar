﻿CREATE TABLE [settings].[ClinicalDataOriginSetting]

(	ClinicalDataOriginSettingKey				INT					NOT NULL,
	ClinicalDataOriginKey						INT					NOT NULL,
	ClinicalDataOriginSettingTypeKey			SMALLINT			NOT NULL,
	ClinicalDataOriginSettingValue				NVARCHAR(MAX),
	InsertDate									DATETIME		CONSTRAINT [DF_ClinicalDataOriginSetting_InsertDate]		DEFAULT CURRENT_TIMESTAMP NOT NULL		,
	InsertedBy									NVARCHAR(64)	CONSTRAINT [DF_ClinicalDataOriginSetting_InsertedBy]		DEFAULT SUSER_SNAME() NOT NULL			,
	LastUpdated									DATETIME		CONSTRAINT [DF_ClinicalDataOriginSetting_LastUpdated]		DEFAULT CURRENT_TIMESTAMP NOT NULL		,
	LastUpdatedBy								NVARCHAR(64)	CONSTRAINT [DF_ClinicalDataOriginSetting_LastUpdatedBy]	DEFAULT SUSER_SNAME() NOT NULL			,
	CONSTRAINT [UQ_ClinicalDataOriginSetting_ClinicalDataOriginKey_ClinicalDataOriginSettingTypeKey] UNIQUE(ClinicalDataOriginKey,ClinicalDataOriginSettingTypeKey) 
)