﻿ALTER TABLE [settings].[ClinicalDataOriginSetting]
	ADD CONSTRAINT [FK_ClinicalDataOriginSettingToClinicalDataOriginSettingType]
	FOREIGN KEY (ClinicalDataOriginSettingTypeKey)
	REFERENCES [lookup].[ClinicalDataOriginSettingType] (ClinicalDataOriginSettingTypeKey)
