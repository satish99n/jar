﻿ALTER TABLE [settings].[SystemSetting]
	ADD CONSTRAINT [FK_SystemSettingToSystemSettingCategory]
	FOREIGN KEY (SystemSettingCategoryKey)
	REFERENCES [settings].[SystemSettingCategory] (SystemSettingCategoryKey)
