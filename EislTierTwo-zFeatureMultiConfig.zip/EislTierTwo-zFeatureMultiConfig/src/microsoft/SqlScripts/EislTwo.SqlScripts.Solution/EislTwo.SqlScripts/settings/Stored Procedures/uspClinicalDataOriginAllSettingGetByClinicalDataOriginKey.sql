﻿CREATE PROCEDURE [settings].[uspClinicalDataOriginAllSettingGetByClinicalDataOriginKey]
(@ClinicalDataOriginKey	INT
)
AS
BEGIN
	/*
		DECLARE @ClinicalDataOriginKey INT = 10001
		EXEC settings.uspClinicalDataOriginAllSettingGetByClinicalDataOriginKey 10001
	
	*/	

	SET NOCOUNT ON

		SELECT	ClinicalDataOriginKey				,
				ClinicalDataOriginSettingTypeKey	,
				ClinicalDataOriginSettingTypeName   ,
				ClinicalDataOriginSettingValue		,
				IsSecure
		FROM	[settings].[vwClinicalDataOriginAllSetting]	 
		WHERE   ClinicalDataOriginKey= @ClinicalDataOriginKey

	SET NOCOUNT OFF
END	 
