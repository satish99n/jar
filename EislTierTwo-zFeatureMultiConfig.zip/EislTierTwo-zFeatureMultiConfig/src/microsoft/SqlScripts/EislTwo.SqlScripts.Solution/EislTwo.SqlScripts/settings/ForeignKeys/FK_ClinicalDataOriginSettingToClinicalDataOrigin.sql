﻿ALTER TABLE [settings].[ClinicalDataOriginSetting]
	ADD CONSTRAINT [FK_ClinicalDataOriginSettingToClinicalDataOrigin]
	FOREIGN KEY (ClinicalDataOriginKey)
	REFERENCES [dbo].[ClinicalDataOrigin] (ClinicalDataOriginKey)
