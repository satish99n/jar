﻿CREATE VIEW [settings].[vwClinicalDataOriginAllSetting]	 
AS

SELECT	CDOSS.ClinicalDataOriginKey																	,
		CDOST.ClinicalDataOriginSettingTypeKey				AS	ClinicalDataOriginSettingTypeKey	,
		CDOST.ClinicalDataOriginSettingTypeName				AS	ClinicalDataOriginSettingTypeName	,
		CONVERT(VARCHAR(MAX), DECRYPTBYKEYAUTOCERT(CERT_ID('CertClinicalDataOriginSecureSetting'), NULL,ClinicalDataOriginSecureSettingValue))   ClinicalDataOriginSettingValue ,
		CDOST.[IsSecure]
FROM	[settings].[ClinicalDataOriginSecureSetting] CDOSS INNER JOIN
		[lookup].[ClinicalDataOriginSettingType]	 CDOST
ON		CDOSS.ClinicalDataOriginSettingTypeKey =CDOST.[ClinicalDataOriginSettingTypeKey]

UNION	ALL

SELECT	CDOSS.ClinicalDataOriginKey																	,
		CDOST.ClinicalDataOriginSettingTypeKey				AS	ClinicalDataOriginSettingTypeKey	,
		CDOST.ClinicalDataOriginSettingTypeName				AS	ClinicalDataOriginSettingTypeName	,
		ClinicalDataOriginSettingValue						AS	ClinicalDataOriginSettingValue	,
		CDOST.[IsSecure]
FROM	[settings].[ClinicalDataOriginSetting]		CDOSS INNER JOIN
		[lookup].[ClinicalDataOriginSettingType]	CDOST
ON		CDOSS.ClinicalDataOriginSettingTypeKey =CDOST.[ClinicalDataOriginSettingTypeKey]
