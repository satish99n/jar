﻿CREATE PROCEDURE [settings].[uspSystemSettingGetByCategoryKey]
	@SystemSettingCategoryKey INT
AS

BEGIN
	SET NOCOUNT ON

	SELECT  
		alias.[SystemSettingKey]
		, alias.[SystemSettingCategoryKey]
		, alias.[SettingKeyName]
		, alias.[SettingKeyDisplayName]
		, alias.[SettingValue]
		, alias.[SettingValueType]
		, alias.[InsertDate]
		, alias.[InsertedBy]
		, alias.[LastUpdated]
		, alias.[LastUpdatedBy] 
	FROM 
		settings.[SystemSetting] alias
	WHERE
		alias.SystemSettingCategoryKey = @SystemSettingCategoryKey

	SET NOCOUNT OFF

END