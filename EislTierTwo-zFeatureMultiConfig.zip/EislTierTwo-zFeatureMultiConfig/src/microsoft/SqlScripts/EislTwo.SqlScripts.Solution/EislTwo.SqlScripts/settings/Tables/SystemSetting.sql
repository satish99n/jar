﻿CREATE TABLE [settings].[SystemSetting]
(
       [SystemSettingKey]				[INT]				NOT NULL,
       [SystemSettingCategoryKey]		[INT]				NOT NULL,     /* FK */
       [SettingKeyName]					[NVARCHAR](128)		NOT NULL, 
       [SettingKeyDisplayName]			[NVARCHAR](128)		NOT NULL, 
       [SettingValue]					[NVARCHAR](1024)	NOT NULL, 
       [SettingValueType]				[VARCHAR](128)		NULL,
       [InsertDate]						[DATETIME]			NOT NULL CONSTRAINT [DF_SystemSetting_InsertDate]		DEFAULT CURRENT_TIMESTAMP	,
       [InsertedBy]						[NVARCHAR](50)		NOT NULL CONSTRAINT [DF_SystemSetting_InsertedBy]		DEFAULT (SUSER_SNAME())		,        
       [LastUpdated]					[DATETIME]			NOT NULL CONSTRAINT [DF_SystemSetting_LastUpdated]		DEFAULT CURRENT_TIMESTAMP	,                     
       [LastUpdatedBy]					[NVARCHAR](50)		NOT NULL CONSTRAINT [DF_SystemSetting_LastUpdatedBy]	DEFAULT (SUSER_SNAME())		,  
	   CONSTRAINT [PK_SystemSetting] PRIMARY KEY ([SystemSettingKey]),
       CONSTRAINT [UC_SystemSettingCategoryKey_SettingKeyName] UNIQUE (SystemSettingCategoryKey, SettingKeyName)
)