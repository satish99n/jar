﻿ALTER TABLE [settings].[ClinicalDataOriginSecureSetting]
	ADD CONSTRAINT [FK_ClinicalDataOriginSecureSettingToClinicalDataOriginSettingType]
	FOREIGN KEY (ClinicalDataOriginSettingTypeKey)
	REFERENCES [lookup].[ClinicalDataOriginSettingType] (ClinicalDataOriginSettingTypeKey)
