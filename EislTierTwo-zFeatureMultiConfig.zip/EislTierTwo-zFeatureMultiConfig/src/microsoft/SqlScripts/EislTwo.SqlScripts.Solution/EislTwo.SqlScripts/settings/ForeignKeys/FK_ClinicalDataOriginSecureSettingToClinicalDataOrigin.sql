﻿ALTER TABLE [settings].[ClinicalDataOriginSecureSetting]
	ADD CONSTRAINT [FK_ClinicalDataOriginSecureSettingToClinicalDataOrigin]
	FOREIGN KEY (ClinicalDataOriginKey)
	REFERENCES [dbo].[ClinicalDataOrigin] (ClinicalDataOriginKey)
