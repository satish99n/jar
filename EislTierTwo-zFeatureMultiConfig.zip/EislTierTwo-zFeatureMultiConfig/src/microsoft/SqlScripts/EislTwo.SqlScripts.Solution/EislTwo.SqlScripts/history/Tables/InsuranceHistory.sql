﻿CREATE TABLE [history].[InsuranceHistory]
(
	[InsuranceHistoryKey]			INT				NOT NULL IDENTITY(1,1),
	[ClinicalDataOriginKey]			INT				NOT NULL,
	[InsuranceIdentifierType]		SMALLINT		NULL,
	[InsuranceIdentifier]			VARCHAR(256)	NULL
)
