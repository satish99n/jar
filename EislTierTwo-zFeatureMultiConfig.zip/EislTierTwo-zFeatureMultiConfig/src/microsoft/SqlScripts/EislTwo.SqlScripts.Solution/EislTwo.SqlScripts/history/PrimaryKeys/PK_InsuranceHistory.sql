﻿ALTER TABLE [history].[InsuranceHistory]
	ADD CONSTRAINT [PK_InsuranceHistory]
	PRIMARY KEY (InsuranceHistoryKey)
