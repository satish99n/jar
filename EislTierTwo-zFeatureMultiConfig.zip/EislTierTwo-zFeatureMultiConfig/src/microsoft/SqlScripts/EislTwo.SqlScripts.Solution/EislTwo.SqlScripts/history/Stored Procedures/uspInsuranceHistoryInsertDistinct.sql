﻿CREATE PROCEDURE [history].[uspInsuranceHistoryInsertDistinct]
	@PrimaryInsuranceIdentifier			VARCHAR(256)
	, @SecondaryInsuranceIdentifier		VARCHAR(256)
	, @TertiaryInsuranceIdentifier		VARCHAR(256)		= NULL
	, @QuartaneryInsuranceIdentifier	VARCHAR(256)		= NULL
	, @QuinaryInsuranceIdentifier		VARCHAR(256)		= NULL
	, @ClinicalDataOriginKey			INT
AS

BEGIN

	SET NOCOUNT ON

		;WITH CTEInsuranceIdentifier AS
		(
			SELECT ISNULL(LTRIM(RTRIM(@PrimaryInsuranceIdentifier)),'')		AS InsuranceIdentifier, 1 AS InsuranceIdentifierType
			UNION
			SELECT ISNULL(LTRIM(RTRIM(@SecondaryInsuranceIdentifier)),'')	AS InsuranceIdentifier, 2 AS InsuranceIdentifierType
			UNION
			SELECT ISNULL(LTRIM(RTRIM(@TertiaryInsuranceIdentifier)),'')	AS InsuranceIdentifier, 3 AS InsuranceIdentifierType
			UNION
			SELECT ISNULL(LTRIM(RTRIM(@QuartaneryInsuranceIdentifier)),'')	AS InsuranceIdentifier, 4 AS InsuranceIdentifierType
			UNION
			SELECT ISNULL(LTRIM(RTRIM(@QuinaryInsuranceIdentifier)),'')		AS InsuranceIdentifier, 5 AS InsuranceIdentifierType
		)
		INSERT INTO history.InsuranceHistory 
		(
		ClinicalDataOriginKey		,
		InsuranceIdentifierType		,
		InsuranceIdentifier
		)
		SELECT	@ClinicalDataOriginKey,
				InsuranceIdentifierType,
				InsuranceIdentifier
		
		FROM	CTEInsuranceIdentifier CTE

		WHERE	InsuranceIdentifier <> ''
		AND		NOT EXISTS (
							SELECT 1 
							FROM	history.InsuranceHistory realTable 
							WHERE	realTable.ClinicalDataOriginKey		=@ClinicalDataOriginKey
							AND		realTable.InsuranceIdentifier		= CTE.InsuranceIdentifier
							AND		realTable.InsuranceIdentifierType	= CTE.InsuranceIdentifierType
						)

		SET NOCOUNT OFF

END