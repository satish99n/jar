﻿ALTER TABLE [history].[InsuranceHistory] ADD CONSTRAINT FK_InsuranceHistoryToClinicalDataOrigin FOREIGN KEY (ClinicalDataOriginKey) REFERENCES
[dbo].[ClinicalDataOrigin]([ClinicalDataOriginKey])


