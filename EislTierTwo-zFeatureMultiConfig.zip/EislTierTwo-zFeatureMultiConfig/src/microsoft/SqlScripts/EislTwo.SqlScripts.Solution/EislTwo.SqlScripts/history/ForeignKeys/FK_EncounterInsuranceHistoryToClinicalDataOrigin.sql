﻿ALTER TABLE [history].[EncounterInsuranceHistory] ADD CONSTRAINT FK_EncounterInsuranceHistoryToClinicalDataOrigin FOREIGN KEY (ClinicalDataOriginKey) REFERENCES
[dbo].[ClinicalDataOrigin]([ClinicalDataOriginKey])


