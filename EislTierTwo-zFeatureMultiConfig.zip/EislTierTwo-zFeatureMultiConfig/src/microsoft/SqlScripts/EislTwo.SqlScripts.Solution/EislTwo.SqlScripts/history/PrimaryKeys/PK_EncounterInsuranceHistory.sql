﻿ALTER TABLE [history].[EncounterInsuranceHistory] ADD CONSTRAINT PK_EncounterInsuranceHistory PRIMARY KEY (EncounterInsuranceHistoryKey)
