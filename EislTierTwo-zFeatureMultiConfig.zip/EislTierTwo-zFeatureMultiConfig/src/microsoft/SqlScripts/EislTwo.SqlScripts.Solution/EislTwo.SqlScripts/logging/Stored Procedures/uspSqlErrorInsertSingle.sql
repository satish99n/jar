﻿CREATE PROCEDURE [logging].[uspSqlErrorInsertSingle]
  @ErrorNumber INT
, @ErrorSeverity INT
, @ErrorState INT
, @ErrorProcedure NVARCHAR(128)
, @ErrorLine INT
, @ErrorMessage NVARCHAR(4000)
, @XmlFragment NVARCHAR(MAX) = NULL
AS

BEGIN

	SET NOCOUNT ON 

	INSERT INTO [logging].[SqlError] 
	( [ErrorNumber], [ErrorSeverity], [ErrorState], [ErrorProcedure], [ErrorLine], [ErrorMessage], [XmlFragment] ) 
	VALUES (
	  @ErrorNumber
	, @ErrorSeverity
	, @ErrorState
	, @ErrorProcedure
	, @ErrorLine
	, @ErrorMessage
	, @XmlFragment
	)

	SET NOCOUNT OFF

END
