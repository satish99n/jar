﻿CREATE PROCEDURE dbo.uspDeploymentInstanceToCompanyLinkGetByDeploymentInstanceUuid
(@DeploymentInstanceUuID UNIQUEIDENTIFIER
)
AS
BEGIN
		/*
		DECLARE @DeploymentInstanceUuID UNIQUEIDENTIFIER = 'A830C416-9343-4931-9E1B-73E4473D5718'
		EXEC dbo.uspDeploymentInstanceToCompanyLinkGetByDeploymentInstanceUuid @DeploymentInstanceUuID
		*/
		
		SELECT	DeploymentInstanceKey	,
				DeploymentInstanceUuID	,
				MachineName				,
				InstanceName			,
				MacroStatusKey			,
				InsertDate				,
				InsertedBy				,		
				LastUpdated				,
				LastUpdatedBy 
		FROM	dbo.DeploymentInstance DI
		WHERE	DeploymentInstanceUuID = @DeploymentInstanceUuID

		
		SELECT	DICD.DeploymentInstanceKey	,
				DICD.ClinicalDataOriginKey	,
				DICD.InsertDate				,
				DICD.InsertedBy				,
				DICD.LastUpdated			,
				DICD.LastUpdatedBy			,
				DICD.MacroStatusKey			,
				DICD.DataPullPriorityOrdinal
		FROM	dbo.DeploymentInstance DI INNER JOIN
				dbo.DeploymentInstanceToClinicalDataOriginLink DICD
		ON		DI.DeploymentInstanceKey = DICD.DeploymentInstanceKey		
		WHERE	DI.DeploymentInstanceUuID = @DeploymentInstanceUuID

		SELECT	CDO.ClinicalDataOriginKey					,	
				CDO.ClinicalDataOriginCode					,
				CDO.ClinicalDataOriginName					,
				CDO.ClinicalDataOriginDisplayName			,
				CDO.ClinicalAdapterConcreteName				,
				CDO.EMRSystemKey							,
				CDO.MacroStatusKey							,
				CDO.StartDate								,
				CDO.InsertDate								,
				CDO.InsertedBy								,
				CDO.LastUpdated								,			
				CDO.LastUpdatedBy							
		FROM	dbo.DeploymentInstance DI									INNER JOIN
				dbo.DeploymentInstanceToClinicalDataOriginLink DICD
		ON		DI.DeploymentInstanceKey = DICD.DeploymentInstanceKey		INNER JOIN
				dbo.ClinicalDataOrigin	CDO
		ON		DICD.ClinicalDataOriginKey = CDO.ClinicalDataOriginKey
		WHERE	DI.DeploymentInstanceUuID = @DeploymentInstanceUuID		

		SELECT	DISTINCT
				ESY.EMRSystemKey				,
				ESY.EMRSystemCode				,
				ESY.EMRSystemName				,
				ESY.EMROrganizationKey			,
				ESY.EMRStandardCode				,
				ESY.InsertDate					,
				ESY.InsertedBy					,
				ESY.LastUpdated					,
				ESY.LastUpdatedBy				

		FROM	[lookup].EMRSystem ESY
		WHERE	EXISTS
		(	
			SELECT	NULL 
			FROM	dbo.DeploymentInstance DI									INNER JOIN
					dbo.DeploymentInstanceToClinicalDataOriginLink DICD
			ON		DI.DeploymentInstanceKey = DICD.DeploymentInstanceKey		INNER JOIN
					dbo.ClinicalDataOrigin	CDO
			ON		DICD.ClinicalDataOriginKey = CDO.ClinicalDataOriginKey	
			WHERE	DeploymentInstanceUuID = @DeploymentInstanceUuID	
			AND		CDO.EMRSystemKey = ESY.EMRSystemKey							
		)
		
		
		SELECT	EOR.EMROrganizationKey			,
				EOR.EMROrganizationCode			,
				EOR.EMROrganizationName			,
				EOR.InsertDate					,
				EOR.InsertedBy					,
				EOR.LastUpdated					,
				EOR.LastUpdatedBy

		FROM	[lookup].EMROrganization	EOR
		WHERE	EXISTS
		(	SELECT	NULL
			FROM	dbo.DeploymentInstance DI									INNER JOIN
					dbo.DeploymentInstanceToClinicalDataOriginLink DICD
			ON		DI.DeploymentInstanceKey = DICD.DeploymentInstanceKey		INNER JOIN
					dbo.ClinicalDataOrigin	CDO
			ON		DICD.ClinicalDataOriginKey = CDO.ClinicalDataOriginKey		INNER JOIN
					[lookup].EMRSystem ESY
			ON		CDO.EMRSystemKey = ESY.EMRSystemKey							
			WHERE	DeploymentInstanceUuID = @DeploymentInstanceUuID
			AND		Esy.EMROrganizationKey = Eor.EMROrganizationKey
		)
		
END