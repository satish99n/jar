﻿ALTER TABLE [dbo].[ChaseRequestHistory]
	ADD CONSTRAINT [FK_ChaseRequestHistoryToMacroStatus]
	FOREIGN KEY (MacroStatusKey)
	REFERENCES lookup.[ChaseRequestHistoryMacroStatus] (ChaseRequestHistoryMacroStatusKey)
