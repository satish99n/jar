﻿ALTER TABLE [dbo].[ChaseRequestHistory]
	ADD CONSTRAINT [FK_ChaseRequestHistoryToMicroStatus]
	FOREIGN KEY (MicroStatusKey)
	REFERENCES lookup.[ChaseRequestHistoryMicroStatus] (ChaseRequestHistoryMicroStatusKey)
