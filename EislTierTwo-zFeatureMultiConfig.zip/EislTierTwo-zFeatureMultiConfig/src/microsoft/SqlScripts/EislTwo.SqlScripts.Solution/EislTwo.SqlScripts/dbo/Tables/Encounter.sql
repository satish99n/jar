﻿CREATE TABLE [dbo].[Encounter]
(
	[EncounterKey]						BIGINT			NOT NULL IDENTITY(1, 1),
	[ClinicalDataOriginKey]				INT				NOT NULL,
	[EncounterUniqueIdentifier]			VARCHAR(256)	NOT NULL,
	[PatientKey]						BIGINT NOT		NULL, /* FK */
    [InsertDate]						DATETIME        CONSTRAINT [DF_Encounter_InsertDate]	DEFAULT CURRENT_TIMESTAMP NOT NULL	,
    [InsertedBy]						NVARCHAR(64)    CONSTRAINT [DF_Encounter_InsertedBy]	DEFAULT SUSER_SNAME() NOT NULL		,
    [LastUpdated]						DATETIME        CONSTRAINT [DF_Encounter_LastUpdated]	DEFAULT CURRENT_TIMESTAMP NOT NULL	,
    [LastUpdatedBy]						NVARCHAR(64)    CONSTRAINT [DF_Encounter_LastUpdatedBy]	DEFAULT SUSER_SNAME() NOT NULL		,
	CONSTRAINT [UC_Encounter_PatientKey_EncounterUniqueIdentifier] UNIQUE (PatientKey , EncounterUniqueIdentifier)
)