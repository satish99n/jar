﻿CREATE PROCEDURE [dbo].[uspChaseRequestHistoryInsertSingle]
		@ChaseRequestKey		BIGINT
	,	@MacroStatusKey			SMALLINT
	,	@MicroStatusKey			SMALLINT
	,	@ClinicalDataOriginKey	INT
AS

BEGIN

	SET NOCOUNT ON

	DECLARE @ChaseRequestHistoryKeyIdentity BIGINT 

	INSERT INTO [dbo].[ChaseRequestHistory]
			   ([ChaseRequestKey]
			   ,[MacroStatusKey]
			   ,[MicroStatusKey]
			   ,[ClinicalDataOriginKey]
			   )
		 VALUES
			   (
				@ChaseRequestKey
				,@MacroStatusKey
				,@MicroStatusKey
				,@ClinicalDataOriginKey
				)

		SELECT @ChaseRequestHistoryKeyIdentity = IDENT_CURRENT('[dbo].[ChaseRequestHistory]')

		SELECT  
			alias.[ChaseRequestHistoryKey]
			, alias.[ChaseRequestKey]
			, alias.[MacroStatusKey]
			, alias.[MicroStatusKey]
			, alias.[InsertDate]
			, alias.[InsertedBy]
			, alias.[LastUpdated]
			, alias.[LastUpdatedBy] 
			, alias.[ClinicalDataOriginKey]
		FROM [ChaseRequestHistory] alias
		WHERE
			alias.ChaseRequestHistoryKey = @ChaseRequestHistoryKeyIdentity

	SET NOCOUNT OFF

END