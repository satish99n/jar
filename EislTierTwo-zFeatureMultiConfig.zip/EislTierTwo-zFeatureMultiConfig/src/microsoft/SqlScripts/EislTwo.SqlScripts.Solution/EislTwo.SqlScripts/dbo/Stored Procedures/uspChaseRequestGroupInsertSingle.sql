﻿CREATE PROCEDURE [dbo].[uspChaseRequestGroupInsertSingle]
	@ClinicalDataOriginKey	INT
AS

BEGIN

	SET NOCOUNT ON

	/*
		EXEC [dbo].[uspChaseRequestGroupInsertSingle] 10001
		EXEC [dbo].[uspChaseRequestGroupInsertSingle] 10002
	 */

	DECLARE @ChaseRequestGroupKeyIdentity BIGINT 

	INSERT INTO [dbo].[ChaseRequestGroup]
			   (
			   [ChaseRequestGroupUniqueIdentifier]
			   ,[ClinicalDataOriginKey]
			   )
		 VALUES
			   (
				NEWID()
				,@ClinicalDataOriginKey
				)

		SELECT @ChaseRequestGroupKeyIdentity = IDENT_CURRENT('[dbo].[ChaseRequestGroup]')

		SELECT
				alias.[ChaseRequestGroupKey]  
			, alias.[ChaseRequestGroupUniqueIdentifier]	
			, alias.[InsertDate]
			, alias.[InsertedBy]
			, alias.[LastUpdated]
			, alias.[LastUpdatedBy]
			, alias.ClinicalDataOriginKey 
		FROM [ChaseRequestGroup] alias
		WHERE
			alias.ChaseRequestGroupKey = @ChaseRequestGroupKeyIdentity

	SET NOCOUNT OFF

END