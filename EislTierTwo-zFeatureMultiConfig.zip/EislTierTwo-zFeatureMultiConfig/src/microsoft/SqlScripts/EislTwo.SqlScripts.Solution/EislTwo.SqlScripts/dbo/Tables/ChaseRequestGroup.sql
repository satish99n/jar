﻿CREATE TABLE [dbo].[ChaseRequestGroup]
(
	[ChaseRequestGroupKey]					BIGINT			NOT NULL IDENTITY(1, 1),
	[ClinicalDataOriginKey]					INT				NOT NULL,
	[ChaseRequestGroupUniqueIdentifier]		VARCHAR(64)		NOT NULL,	/* this is needed to help OUTPUT clause and bulk Upsert */
	[ChaseRequestGroupTriggerKey]			SMALLINT		NULL ,  /* CHANGE TO NOT NULL */
	[RequestStartDateTime]					DATETIMEOFFSET	NULL , /* CHANGE TO NOT NULL */
	[RequestEndDateTime]					DATETIMEOFFSET	NULL , /* CHANGE TO NOT NULL */
    [InsertDate]							DATETIME        CONSTRAINT [DF_ChaseRequestGroup_InsertDate]	DEFAULT CURRENT_TIMESTAMP NOT NULL,
    [InsertedBy]							NVARCHAR(64)    CONSTRAINT [DF_ChaseRequestGroup_InsertedBy]	DEFAULT SUSER_SNAME() NOT NULL,
    [LastUpdated]							DATETIME        CONSTRAINT [DF_ChaseRequestGroup_LastUpdated]	DEFAULT CURRENT_TIMESTAMP NOT NULL,
    [LastUpdatedBy]							NVARCHAR(64)    CONSTRAINT [DF_ChaseRequestGroup_LastUpdatedBy]	DEFAULT SUSER_SNAME() NOT NULL,
	CONSTRAINT [UC_ChaseRequestGroup_ChaseRequestGroupUniqueIdentifier] UNIQUE (ChaseRequestGroupUniqueIdentifier)
)