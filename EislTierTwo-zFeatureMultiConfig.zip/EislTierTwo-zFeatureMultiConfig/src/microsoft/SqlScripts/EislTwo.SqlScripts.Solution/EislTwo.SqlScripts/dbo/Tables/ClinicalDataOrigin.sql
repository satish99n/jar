﻿CREATE TABLE [dbo].[ClinicalDataOrigin]
(	[ClinicalDataOriginKey]			INT			NOT NULL,
	[ClinicalDataOriginCode]			VARCHAR(64)	NOT NULL,
	[ClinicalDataOriginName]			NVARCHAR(256)		,
	[ClinicalDataOriginDisplayName]	NVARCHAR(256)		,
	[ClinicalAdapterConcreteName]		NVARCHAR(256) NOT NULL,
	[EMRSystemKey]					SMALLINT	NOT NULL,
	[MacroStatusKey]				SMALLINT	NULL, /* NEED TO CHANGE TO NOT NULL */ /* Need basic look values Active and Inactive */
	[StartDate]						DATE		, /* StartDate on which Clinical Data Origin went live a.k.a.* Go live Date*/
	[InsertDate]						DATETIME		CONSTRAINT [DF_ClinicalDataOrigin_InsertDate]		DEFAULT CURRENT_TIMESTAMP NOT NULL		,
	[InsertedBy]						NVARCHAR(64)	CONSTRAINT [DF_ClinicalDataOrigin_InsertedBy]		DEFAULT SUSER_SNAME() NOT NULL			,
	[LastUpdated]						DATETIME		CONSTRAINT [DF_ClinicalDataOrigin_LastUpdated]		DEFAULT CURRENT_TIMESTAMP NOT NULL		,
	[LastUpdatedBy]					NVARCHAR(64)	CONSTRAINT [DF_ClinicalDataOrigin_LastUpdatedBy]	DEFAULT SUSER_SNAME() NOT NULL			,
	CONSTRAINT [UQ_ClinicalDataOrigin_ClinicalDataOriginCode] UNIQUE(ClinicalDataOriginCode) 
	/* Please add unique constraint new lookup table for [MacroStatusKey] */
)		
GO