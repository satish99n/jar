ALTER TABLE [dbo].[EncounterInsurance] ADD CONSTRAINT FK_EncounterInsuranceToClinicalDataOrigin FOREIGN KEY (ClinicalDataOriginKey) REFERENCES
[dbo].[ClinicalDataOrigin]([ClinicalDataOriginKey])


