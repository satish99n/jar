﻿CREATE PROCEDURE [dbo].[uspEncounterUpdateSingle]
	  @EncounterKey BIGINT
	, @PerformUpdateEncounterUniqueIdentifier BIT
	, @EncounterUniqueIdentifier VARCHAR(256)
	, @PerformUpdatePatientKey BIT
	, @PatientKey BIGINT
	, @PerformUpdatePrimaryInsuranceIdentifier BIT
	, @PrimaryInsuranceIdentifier VARCHAR(256)
	, @PerformUpdateSecondaryInsuranceIdentifier BIT
	, @SecondaryInsuranceIdentifier VARCHAR(256)
	, @PerformUpdateTertiaryInsuranceIdentifier BIT
	, @TertiaryInsuranceIdentifier VARCHAR(256)
	, @PerformUpdateQuaternaryInsuranceIdentifier BIT
	, @QuaternaryInsuranceIdentifier VARCHAR(256)
	, @PerformUpdateQuinaryInsuranceIdentifier BIT
	, @QuinaryInsuranceIdentifier VARCHAR(256)
	, @ClinicalDataOriginKey	INT -- New Parameter Added
	, @PerformUpdateClinicalDataOriginKey INT
AS
	
BEGIN

	SET NOCOUNT ON


	DECLARE @EncounterHolder TABLE (
		 [EncounterKey]						BIGINT		 NOT NULL		
		,[PrimaryInsuranceIdentifier]		VARCHAR(256) NULL
		,[SecondaryInsuranceIdentifier]		VARCHAR(256) NULL
		,[TertiaryInsuranceIdentifier]		VARCHAR(256) NULL
		,[QuaternaryInsuranceIdentifier]	VARCHAR(256) NULL
		,[QuinaryInsuranceIdentifier]		VARCHAR(256) NULL
		,[InsertDate]						DATETIME
		,[InsertedBy]						NVARCHAR(128)
		,[LastUpdated]						DATETIME
		,[LastUpdatedBy]					NVARCHAR(128)
		);

	DECLARE @EncounterInsuranceUnpivot TABLE(  -- EncounterInsurance - 8.29.2018
	   [EncounterKey]                          BIGINT              NOT NULL	,
       [InsuranceIdentifierType]               SMALLINT            NULL		,
       [InsuranceIdentifier]                   VARCHAR(256) NULL			, 
	   [InsertDate]                            DATETIME				,
       [InsertedBy]                            NVARCHAR(64)			,
       [LastUpdated]                           DATETIME				,
	   [LastUpdatedBy]                         NVARCHAR(64)			
		); /* Natural Key will be EncounterUniqueIdentifier */

	DECLARE @EncounterInsuranceAudit TABLE( 
		  DatabaseKey							BIGINT 
		,InsuranceIdentifierType				SMALLINT
		,[DeletedInsuranceIdentifier]			VARCHAR(256)
		,[InsertedInsuranceIdentifier]			VARCHAR(256)
		,[DeletedLastUpdated]					DATETIME
		);

		IF EXISTS(	SELECT	NULL 
					FROM	dbo.Encounter 
					WHERE	EncounterKey = @EncounterKey
					AND		ClinicalDataOriginKey <> @ClinicalDataOriginKey
				 )
		BEGIN
			;THROW 51000, 'Encounter Key exist with different ClinicalDataorigin Key. (Mismatched EnounterKey-ClinicalDataOriginKey)', 1; 
		END

		IF	@PerformUpdatePrimaryInsuranceIdentifier	= 1 OR
			@PerformUpdateSecondaryInsuranceIdentifier	= 1 OR
			@PerformUpdateTertiaryInsuranceIdentifier	= 1 OR
			@PerformUpdateQuaternaryInsuranceIdentifier = 1 OR
			@PerformUpdateQuinaryInsuranceIdentifier	= 1
		BEGIN

				INSERT INTO @EncounterHolder
				([EncounterKey]
				,[PrimaryInsuranceIdentifier]
				,[SecondaryInsuranceIdentifier]
				,[TertiaryInsuranceIdentifier]	
				,[QuaternaryInsuranceIdentifier] 
				,[QuinaryInsuranceIdentifier]
				,[InsertDate]
				,[InsertedBy]
				,[LastUpdated]
				,[LastUpdatedBy]
				)
				VALUES
				(
				  @EncounterKey 
				, @PrimaryInsuranceIdentifier 
				, @SecondaryInsuranceIdentifier
				, @TertiaryInsuranceIdentifier 
				, @QuaternaryInsuranceIdentifier 
				, @QuinaryInsuranceIdentifier
				, CURRENT_TIMESTAMP
				, SUSER_SNAME()
				, CURRENT_TIMESTAMP
				, SUSER_SNAME()
				)
	
				;with CTEEncounterInsurance AS
					(	SELECT
								 EncounterKey		AS EncounterKey
								,CASE WHEN ISNULL(LTRIM(RTRIM (holder.[PrimaryInsuranceIdentifier])),'') =''	THEN NULL ELSE holder.[PrimaryInsuranceIdentifier] END			AS	PrimaryInsuranceIdentifier
								,CASE WHEN ISNULL(LTRIM(RTRIM (holder.[SecondaryInsuranceIdentifier])),'') =''	THEN NULL ELSE holder.[SecondaryInsuranceIdentifier] END			AS	[SecondaryInsuranceIdentifier]
								,CASE WHEN ISNULL(LTRIM(RTRIM (holder.TertiaryInsuranceIdentifier)) ,'') =''	THEN NULL ELSE holder.[TertiaryInsuranceIdentifier] END			AS	[TertiaryInsuranceIdentifier]
								,CASE WHEN ISNULL(LTRIM(RTRIM (holder.[QuaternaryInsuranceIdentifier])) ,'') =''THEN NULL ELSE holder.[QuaternaryInsuranceIdentifier] END			AS	[QuaternaryInsuranceIdentifier]
								,CASE WHEN ISNULL(LTRIM(RTRIM (holder.[QuinaryInsuranceIdentifier])) ,'') =''	THEN NULL ELSE holder.[QuinaryInsuranceIdentifier] END			AS	[QuinaryInsuranceIdentifier]
								,[InsertDate]		= ISNULL(holder.[InsertDate], CURRENT_TIMESTAMP)
								,[InsertedBy]		= ISNULL(holder.[InsertedBy], SUSER_SNAME())
								,[LastUpdated]		= ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
								,[LastUpdatedBy]	= ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())
						FROM	@EncounterHolder holder 
					)
					INSERT INTO @EncounterInsuranceUnpivot ( 
					[EncounterKey]                        ,
					[InsuranceIdentifierType]             ,
					[InsuranceIdentifier]                 , 
					[InsertDate]                          ,
					[InsertedBy]                          ,
					[LastUpdated]                         ,
					[LastUpdatedBy]                       
					) /* Natural Key will be EncounterUniqueIdentifier */
					SELECT	EncounterKey					,
							InsuranceIdentifierType			,
							InsuranceIdentifier				,
							[InsertDate]                    ,
							[InsertedBy]                    ,
							[LastUpdated]                   ,
							[LastUpdatedBy]                       

					FROM
						(
							SELECT	EI.EncounterKey					,
									CA.InsuranceIdentifierType		,
									CA.InsuranceIdentifier			,
									EI.[InsertDate]					,
									EI.[InsertedBy]					,
									EI.[LastUpdated]				,
									EI.[LastUpdatedBy]                 
							FROM	CTEEncounterInsurance EI
							CROSS APPLY (	VALUES	(1,PrimaryInsuranceIdentifier)		,
													(2,SecondaryInsuranceIdentifier)	,
													(3,TertiaryInsuranceIdentifier)		,
													(4,QuaternaryInsuranceIdentifier)	,
													(5,QuinaryInsuranceIdentifier)		
										)CA (InsuranceIdentifierType,InsuranceIdentifier)
						) UP

				INSERT INTO [dbo].[EncounterInsurance] (
					 --[EncounterKey]
					 [EncounterKey] 
					,[InsuranceIdentifierType]
					,[InsuranceIdentifier]
					,[InsertDate]
					,[InsertedBy]
					,[LastUpdated]
					,[LastUpdatedBy]
					,[ClinicalDataOriginKey]
					)
				--OUTPUT inserted.EncounterUniqueIdentifier , inserted.EncounterKey INTO @EncounterSurrogateKeyAudit(NaturalKey,DatabaseKey ) 
				SELECT
					 EncounterKey
					,[InsuranceIdentifierType]
					,[InsuranceIdentifier]
					,[InsertDate]		
					,[InsertedBy]		
					,[LastUpdated]		
					,[LastUpdatedBy]	
					,@ClinicalDataOriginKey
				FROM	@EncounterInsuranceUnpivot holder 
				WHERE   [InsuranceIdentifier] IS NOT NULL
				AND		NOT EXISTS (
									SELECT  NULL
									FROM    [dbo].[EncounterInsurance] realTable
									WHERE   holder.EncounterKey					= realTable.EncounterKey
									AND	    holder.[InsuranceIdentifierType]	= realTable.[InsuranceIdentifierType]
								);

				UPDATE	realtable
				SET		realtable.InsuranceIdentifier				=	holder.InsuranceIdentifier 	,
						realtable.LastUpdated						=	holder.LastUpdated			,
						realtable.LastUpdatedBy						=	holder.LastUpdatedBy	
					
				OUTPUT	inserted.EncounterKey				, 
						inserted.[InsuranceIdentifierType]	,
						deleted.InsuranceIdentifier			,
						inserted.InsuranceIdentifier		,
						Deleted.LastUpdated 

				INTO	@EncounterInsuranceAudit(DatabaseKey,InsuranceIdentifierType,DeletedInsuranceIdentifier,InsertedInsuranceIdentifier,DeletedLastUpdated ) 

				FROM	@EncounterInsuranceUnpivot holder	INNER JOIN
						[dbo].[EncounterInsurance] realTable
				ON		holder.EncounterKey					= realTable.EncounterKey
				AND	    holder.[InsuranceIdentifierType]	= realTable.[InsuranceIdentifierType]

	
				/***************************************** Encounter Insurance History Insert Starts********************************/
					
					INSERT INTO [history].[EncounterInsuranceHistory]
					(	EncounterKey
					,	BeforeInsuranceIdentifier
					,	AfterInsuranceIdentifier
					,	InsuranceIdentifierType
					,	OriginalRowLastUpdatedDate
					,	InsertDate
					,	InsertedBy
					,	ClinicalDataOriginKey
					)
					SELECT  DatabaseKey
					,		DeletedInsuranceIdentifier
					,		InsertedInsuranceIdentifier
					,		InsuranceIdentifierType
					,		DeletedLastUpdated
					,		CURRENT_TIMESTAMP
					,		SUSER_NAME()--CURRENT_USER
					,		@ClinicalDataOriginKey
					FROM	@EncounterInsuranceAudit
					WHERE	ISNULL(DeletedInsuranceIdentifier,'') <> ISNULL(InsertedInsuranceIdentifier,'')

					/***************************************** Encounter Insurance History Insert Ends********************************/
				
			/* record the "history" so we can tweak the matching regexs in the future */
				EXEC [history].[uspInsuranceHistoryInsertDistinct] @PrimaryInsuranceIdentifier,	SecondaryInsuranceIdentifier, @TertiaryInsuranceIdentifier , @QuaternaryInsuranceIdentifier , @QuinaryInsuranceIdentifier,@ClinicalDataOriginKey
	END

	;WITH CTEEncounter AS
		(SELECT  
			  alias.[EncounterKey]
			, alias.[EncounterUniqueIdentifier]
			, alias.[PatientKey]
			, EI.[InsuranceIdentifierType]
			, EI.[InsuranceIdentifier]
			, alias.[InsertDate]
			, alias.[InsertedBy]
			, alias.[LastUpdated]
			, alias.[LastUpdatedBy] 
			, alias.[ClinicalDataOriginKey]
		FROM 
			[dbo].[Encounter] alias			LEFT JOIN	  /* relationship */ 
			[dbo].[EncounterInsurance] EI
		ON	alias.EncounterKey = EI.EncounterKey

		
		WHERE	alias.EncounterKey = @EncounterKey
		)
		SELECT 			  
			  [EncounterKey]
			, [EncounterUniqueIdentifier]
			, [PatientKey]
			, [InsertDate]
			, [InsertedBy]
			, [LastUpdated]
			, [LastUpdatedBy] 
			, [1]  PrimaryInsuranceIdentifier
			, [2]  SecondaryInsuranceIdentifier
			, [3]  TertiaryInsuranceIdentifier
			, [4]  QuaternaryInsuranceIdentifier
			, [5]  QuinaryInsuranceIdentifier
			, [ClinicalDataOriginKey]
		FROM (	SELECT   
					  [EncounterKey]
					, [EncounterUniqueIdentifier]
					, [PatientKey]
					, [InsuranceIdentifierType]
					, [InsuranceIdentifier]
					, [InsertDate]
					, [InsertedBy]
					, [LastUpdated]
					, [LastUpdatedBy]
					, [ClinicalDataOriginKey]

				FROM  CTEEncounter	
			  )SRC 
			  PIVOT
			  (	MAX([InsuranceIdentifier]) FOR 	[InsuranceIdentifierType] IN ([1],[2],[3],[4],[5])) AS PVT	
			   	
	
	SET NOCOUNT OFF

END