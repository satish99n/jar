﻿ALTER TABLE [dbo].[ClinicalDataOrigin]  ADD CONSTRAINT[FK_ClinicalDataOriginToClinicalDataOriginMacroStatus]
FOREIGN KEY (MacroStatusKey)
       REFERENCES [lookup].[ClinicalDataOriginMacroStatus](ClinicalDataOriginMacroStatusKey)
