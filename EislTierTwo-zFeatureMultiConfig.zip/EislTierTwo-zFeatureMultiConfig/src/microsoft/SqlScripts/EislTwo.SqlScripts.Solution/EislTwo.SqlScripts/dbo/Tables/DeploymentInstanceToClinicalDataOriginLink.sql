﻿CREATE TABLE [dbo].[DeploymentInstanceToClinicalDataOriginLink]
(		[DeploymentInstanceKey]	INT		NOT NULL,
		[ClinicalDataOriginKey]	INT		NOT NULL,
		[MacroStatusKey]			SMALLINT	NULL, /* NEED TO CHANGE TO NOT NULL */ /* Need basic look values Active and Inactive */
		[DataPullPriorityOrdinal]	SMALLINT	    CONSTRAINT [CK_DeploymentInstanceToClinicalDataOriginLink_PriorityOrdinal]  CHECK  ( DataPullPriorityOrdinal> 0 )			,
		[InsertDate]				DATETIME		CONSTRAINT [DF_DeploymentInstanceToClinicalDataOriginLink_InsertDate]		DEFAULT CURRENT_TIMESTAMP NOT NULL		,
		[InsertedBy]				NVARCHAR(64)	CONSTRAINT [DF_DeploymentInstanceToClinicalDataOriginLink_InsertedBy]		DEFAULT SUSER_SNAME() NOT NULL			,
		[LastUpdated]				DATETIME		CONSTRAINT [DF_DeploymentInstanceToClinicalDataOriginLink_LastUpdated]		DEFAULT CURRENT_TIMESTAMP NOT NULL		,
		[LastUpdatedBy]			NVARCHAR(64)	CONSTRAINT [DF_DeploymentInstanceToClinicalDataOriginLink_LastUpdatedBy]	DEFAULT SUSER_SNAME() NOT NULL			,
		CONSTRAINT				[UQ_DeploymentInstance_DeploymentInstanceKey_ClinicalDataOriginKey] UNIQUE(DeploymentInstanceKey,ClinicalDataOriginKey) 
)