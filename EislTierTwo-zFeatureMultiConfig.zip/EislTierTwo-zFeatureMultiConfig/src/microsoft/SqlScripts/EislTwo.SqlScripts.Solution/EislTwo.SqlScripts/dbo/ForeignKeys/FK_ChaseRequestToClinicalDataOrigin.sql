﻿ALTER TABLE [dbo].[ChaseRequest]
	ADD CONSTRAINT [FK_ChaseRequestToClinicalDataOrigin]
	FOREIGN KEY (ClinicalDataOriginKey)
	REFERENCES [dbo].[ClinicalDataOrigin] (ClinicalDataOriginKey)
