﻿ALTER TABLE [dbo].[ChaseRequestGroup]
	ADD CONSTRAINT [FK_ChaseRequestGroupToChaseRequestGroupTrigger]
	FOREIGN KEY (ChaseRequestGroupTriggerKey)
	REFERENCES [lookup].[ChaseRequestGroupTrigger] (ChaseRequestGroupTriggerKey)

