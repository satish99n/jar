﻿CREATE PROCEDURE [dbo].[uspChaseRequestGroupDeepGetByKey]
	@ChaseRequestGroupKey BIGINT
AS

/*

Example Usage:

DBCC FREEPROCCACHE WITH NO_INFOMSGS; 
GO
SET STATISTICS IO ON
GO 
USE COREDB
GO

DECLARE @ChaseRequestGroupKey BIGINT
SELECT @ChaseRequestGroupKey = (SELECT TOP 1 ChaseRequestGroupKey FROM dbo.[ChaseRequestGroup] order by newid())
EXEC [dbo].[uspChaseRequestGroupDeepGetByKey] @ChaseRequestGroupKey

*/
BEGIN
	SET NOCOUNT ON

		SELECT  
			  alias.[ChaseRequestGroupKey]
			, alias.[ChaseRequestGroupUniqueIdentifier]
			, alias.[InsertDate]
			, alias.[InsertedBy]
			, alias.[LastUpdated]
			, alias.[LastUpdatedBy]
			, alias.[ClinicalDataOriginKey]
		FROM 
			[dbo].[ChaseRequestGroup] alias
		WHERE 
			alias.[ChaseRequestGroupKey] = @ChaseRequestGroupKey

		--

		SELECT  
			  alias.[ChaseRequestGroupHistoryKey]
			, alias.[ChaseRequestGroupKey]
			, alias.[MacroStatusKey]
			, alias.[MicroStatusKey]
			, alias.[InsertDate]
			, alias.[InsertedBy]
			, alias.[LastUpdated]
			, alias.[LastUpdatedBy] 
			, alias.[ClinicalDataOriginKey]
		FROM 
			[dbo].[ChaseRequestGroupHistory] alias --WITH(FORCESEEK)
		WHERE
			alias.[ChaseRequestGroupKey] = @ChaseRequestGroupKey

		--

		SELECT  
			  alias.[ChaseRequestKey]
			, alias.[ChaseRequestGroupKey]
			, alias.[EncounterKey]
			, alias.[InsertDate]
			, alias.[InsertedBy]
			, alias.[LastUpdated]
			, alias.[LastUpdatedBy] 
			, alias.[ClinicalDataOriginKey]
		FROM 
			[dbo].[ChaseRequest] alias --WITH(FORCESEEK)
		WHERE 
			alias.[ChaseRequestGroupKey] = @ChaseRequestGroupKey

		---

		SELECT  
			    alias.[ChaseRequestHistoryKey]
			  , alias.[ChaseRequestKey]
			  , alias.[MacroStatusKey]
			  , alias.[MicroStatusKey]
			  , alias.[InsertDate]
			  , alias.[InsertedBy]
			  , alias.[LastUpdated]
			  , alias.[LastUpdatedBy] 
			  , alias.[ClinicalDataOriginKey]
		FROM [dbo].[ChaseRequestHistory] alias INNER JOIN
		  	 [dbo].[ChaseRequest] cr 
		ON  	/* relationship */ cr.[ChaseRequestKey] = alias.[ChaseRequestKey]
		WHERE	 /* filter */ cr.[ChaseRequestGroupKey] = @ChaseRequestGroupKey
					

		;WITH CTEEncounter AS
		(SELECT  
			  alias.[EncounterKey]
			, alias.[EncounterUniqueIdentifier]
			, alias.[PatientKey]
			, EI.[InsuranceIdentifierType]
			, EI.[InsuranceIdentifier]
			, alias.[InsertDate]
			, alias.[InsertedBy]
			, alias.[LastUpdated]
			, alias.[LastUpdatedBy]
			, alias.[ClinicalDataOriginKey] 
		FROM 
			[dbo].[Encounter] alias			INNER JOIN 
			[dbo].[ChaseRequest] cr  
		ON
			  /* relationship */ 
			cr.[EncounterKey] = alias.[EncounterKey] LEFT JOIN 
			[dbo].[EncounterInsurance] EI
		ON	alias.EncounterKey = EI.EncounterKey

		WHERE  /* filter */ cr.[ChaseRequestGroupKey] = @ChaseRequestGroupKey
		)
		SELECT 			  
			  [EncounterKey]
			, [EncounterUniqueIdentifier]
			, [PatientKey]
			, [InsertDate]
			, [InsertedBy]
			, [LastUpdated]
			, [LastUpdatedBy] 
			, [1]  PrimaryInsuranceIdentifier
			, [2]  SecondaryInsuranceIdentifier
			, [3]  TertiaryInsuranceIdentifier
			, [4]  QuaternaryInsuranceIdentifier
			, [5]  QuinaryInsuranceIdentifier
			, [ClinicalDataOriginKey]
		FROM (	SELECT   
					  [EncounterKey]
					, [EncounterUniqueIdentifier]
					, [PatientKey]
					, [InsuranceIdentifierType]
					, [InsuranceIdentifier]
					, [InsertDate]
					, [InsertedBy]
					, [LastUpdated]
					, [LastUpdatedBy]
					, [ClinicalDataOriginKey]

				FROM  CTEEncounter	
			  )SRC 
			  PIVOT
			  (	MAX([InsuranceIdentifier]) FOR 	[InsuranceIdentifierType] IN ([1],[2],[3],[4],[5])) AS PVT	
			   	
	
		SELECT  
			  alias.[PatientKey]
			, alias.[PatientUniqueIdentifier]
			, alias.[InsertDate]
			, alias.[InsertedBy]
			, alias.[LastUpdated]
			, alias.[LastUpdatedBy] 
			, alias.[ClinicalDataOriginKey]
		FROM 
			[dbo].[Patient] alias 
		WHERE EXISTS (
						SELECT NULL 
						FROM	[dbo].[Encounter] enc JOIN	
								[dbo].[ChaseRequest] cr 
						ON		cr.[EncounterKey]			= enc.[EncounterKey]  
						AND		enc.PatientKey				= alias.PatientKey 
						WHERE	cr.[ChaseRequestGroupKey]	= @ChaseRequestGroupKey
					  )
END