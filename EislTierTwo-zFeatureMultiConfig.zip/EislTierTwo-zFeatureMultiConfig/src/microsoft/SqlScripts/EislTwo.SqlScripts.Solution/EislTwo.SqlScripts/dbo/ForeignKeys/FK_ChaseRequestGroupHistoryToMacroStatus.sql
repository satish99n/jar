﻿ALTER TABLE [dbo].[ChaseRequestGroupHistory]
	ADD CONSTRAINT [FK_ChaseRequestGroupHistoryToMacroStatus]
	FOREIGN KEY (MacroStatusKey)
	REFERENCES lookup.[ChaseRequestGroupHistoryMacroStatus] (ChaseRequestGroupHistoryMacroStatusKey)
