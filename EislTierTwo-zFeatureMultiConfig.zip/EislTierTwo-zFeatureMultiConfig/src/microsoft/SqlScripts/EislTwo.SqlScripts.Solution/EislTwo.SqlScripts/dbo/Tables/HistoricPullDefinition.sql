﻿CREATE TABLE [dbo].[HistoricPullDefinition]
(
	[HistoricPullDefinitionKey] INT NOT NULL,
	[ClinicalDataOriginKey] INT NOT NULL, /* TODO FK */
	[StartDate] DATETIMEOFFSET NOT NULL,
	[EndDate] DATETIMEOFFSET NOT NULL,
	[DataPullPriorityOrdinal] SMALLINT NOT NULL CONSTRAINT [CK_HistoricPullDefinition_PriorityOrdinal]  CHECK  ( DataPullPriorityOrdinal> 0 ),
	[MacroStatusKey]				SMALLINT	NOT NULL,
	[MicroStatusKey]				SMALLINT	NOT NULL,
	[InsertDate]						DATETIME			CONSTRAINT [DF_HistoricPullDefinition_InsertDate]		DEFAULT CURRENT_TIMESTAMP NOT NULL,
	[InsertedBy]						NVARCHAR(64)		CONSTRAINT [DF_HistoricPullDefinition_InsertedBy]		DEFAULT SUSER_SNAME() NOT NULL,
	[LastUpdated]					DATETIME			CONSTRAINT [DF_HistoricPullDefinition_LastUpdated]		DEFAULT CURRENT_TIMESTAMP NOT NULL,
	[LastUpdatedBy]                  NVARCHAR(64)		CONSTRAINT [DF_HistoricPullDefinition_LastUpdatedBy]     DEFAULT SUSER_SNAME() NOT NULL,
	CONSTRAINT [UQ_HistoricPullDefinition_ClinicalDataOriginKey_Priority] UNIQUE([ClinicalDataOriginKey] , [DataPullPriorityOrdinal]) 
	/* Please add CHECK constraint [Priority] > 0. */
)
