﻿ALTER TABLE [dbo].[ChaseRequestHistory]
	ADD CONSTRAINT [FK_ChaseRequestHistoryToClinicalDataOrigin]
	FOREIGN KEY (ClinicalDataOriginKey)
	REFERENCES [ClinicalDataOrigin] (ClinicalDataOriginKey)
