﻿CREATE TABLE [dbo].[DeploymentInstance]
(	DeploymentInstanceKey			INT					NOT NULL,
	DeploymentInstanceUuID			UNIQUEIDENTIFIER	NOT NULL,
	MachineName						VARCHAR(128),
	InstanceName					VARCHAR(128),
	[MacroStatusKey]				SMALLINT	NULL, /* NEED TO CHANGE TO NOT NULL */ /* Need basic look values Active and Inactive */
	InsertDate						DATETIME		CONSTRAINT [DF_DeploymentInstance_InsertDate]		DEFAULT CURRENT_TIMESTAMP NOT NULL		,
	InsertedBy						NVARCHAR(64)	CONSTRAINT [DF_DeploymentInstance_InsertedBy]		DEFAULT SUSER_SNAME() NOT NULL			,
	LastUpdated						DATETIME		CONSTRAINT [DF_DeploymentInstance_LastUpdated]		DEFAULT CURRENT_TIMESTAMP NOT NULL		,
	LastUpdatedBy						NVARCHAR(64)	CONSTRAINT [DF_DeploymentInstance_LastUpdatedBy]	DEFAULT SUSER_SNAME() NOT NULL			,
	CONSTRAINT						[UQ_DeploymentInstance_DeploymentInstanceUuID] UNIQUE(DeploymentInstanceUuID) 
	/* Please add unique constraint new lookup table for [MacroStatusKey] */
)		
