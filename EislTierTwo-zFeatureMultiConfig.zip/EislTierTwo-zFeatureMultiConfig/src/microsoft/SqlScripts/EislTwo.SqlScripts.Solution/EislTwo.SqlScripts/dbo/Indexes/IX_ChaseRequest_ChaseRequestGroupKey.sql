﻿CREATE NONCLUSTERED INDEX IX_ChaseRequest_ChaseRequestGroupKey 
	ON [dbo].[ChaseRequest]([ChaseRequestGroupKey])
	INCLUDE([EncounterKey])