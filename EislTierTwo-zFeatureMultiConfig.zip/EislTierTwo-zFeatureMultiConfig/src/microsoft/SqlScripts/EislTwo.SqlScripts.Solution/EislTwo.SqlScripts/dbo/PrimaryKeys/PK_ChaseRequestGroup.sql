﻿ALTER TABLE [dbo].[ChaseRequestGroup]
	ADD CONSTRAINT [PK_ChaseRequestGroup]
	PRIMARY KEY ([ChaseRequestGroupKey])
