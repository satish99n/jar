﻿CREATE PROCEDURE [dbo].[uspPatientEncounterUpsert] 
@ParameterXml XML
AS

BEGIN

/*

EXAMPLE USAGE :

DELETE FROM dbo.ChaseRequestHistory
DELETE FROM dbo.ChaseRequest
DELETE FROM dbo.ChaseRequestGroupHistory
DELETE FROM dbo.ChaseRequestGroup
DELETE FROM dbo.EncounterInsurance
DELETE FROM dbo.Encounter
DELETE FROM dbo.Patient


EXEC [dbo].[uspPatientEncounterUpsert] '
<root>
<Patients>
	<Patient PatientKey="-10001" PatientUniqueIdentifier="PatientAbc1008" ClinicalDataOriginKey="10001"/>
	<Patient PatientKey="-10002" PatientUniqueIdentifier="PatientAbc1009" ClinicalDataOriginKey="10001"	/>
	<Patient PatientKey="-10003" PatientUniqueIdentifier="PatientAbc1004" ClinicalDataOriginKey="10001"/>
	<Patient PatientKey="-10004" PatientUniqueIdentifier="PatientAbc1005" ClinicalDataOriginKey="10001"/>
	<Patient PatientKey="-10005" PatientUniqueIdentifier="PatientAbc1006" ClinicalDataOriginKey="10001"/>
	<Patient PatientKey="-10006" PatientUniqueIdentifier="PatientAbc1007" ClinicalDataOriginKey="10001"/>
	<Patient PatientKey="-10007" PatientUniqueIdentifier="PatientAbc1001" ClinicalDataOriginKey="10001"/>
	<Patient PatientKey="-10008" PatientUniqueIdentifier="PatientAbc1002" ClinicalDataOriginKey="10001"/>
	<Patient PatientKey="-10009" PatientUniqueIdentifier="PatientAbc1003" ClinicalDataOriginKey="10001"/>
	<Patient PatientKey="-10010" PatientUniqueIdentifier="PatientAbc1010" ClinicalDataOriginKey="10001"/>
</Patients>
<Encounters>
	<Encounter EncounterKey="-20001" EncounterUniqueIdentifier="MyEncounter1008.1" PatientKey="-10001" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20002" EncounterUniqueIdentifier="MyEncounter1008.2" PatientKey="-10001" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20003" EncounterUniqueIdentifier="MyEncounter1009.1" PatientKey="-10002" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20004" EncounterUniqueIdentifier="MyEncounter1009.2" PatientKey="-10002" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20005" EncounterUniqueIdentifier="MyEncounter1004.1" PatientKey="-10003" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20006" EncounterUniqueIdentifier="MyEncounter1004.2" PatientKey="-10003" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20007" EncounterUniqueIdentifier="MyEncounter1005.1" PatientKey="-10004" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20008" EncounterUniqueIdentifier="MyEncounter1005.2" PatientKey="-10004" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20009" EncounterUniqueIdentifier="MyEncounter1006.1" PatientKey="-10005" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20010" EncounterUniqueIdentifier="MyEncounter1006.2" PatientKey="-10005" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20011" EncounterUniqueIdentifier="MyEncounter1007.1" PatientKey="-10006" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20012" EncounterUniqueIdentifier="MyEncounter1007.2" PatientKey="-10006" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20013" EncounterUniqueIdentifier="MyEncounter1001.1" PatientKey="-10007" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20014" EncounterUniqueIdentifier="MyEncounter1001.2" PatientKey="-10007" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20015" EncounterUniqueIdentifier="MyEncounter1002.1" PatientKey="-10008" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20016" EncounterUniqueIdentifier="MyEncounter1002.2" PatientKey="-10008" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20017" EncounterUniqueIdentifier="MyEncounter1003.1" PatientKey="-10009" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20018" EncounterUniqueIdentifier="MyEncounter1003.2" PatientKey="-10009" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20019" EncounterUniqueIdentifier="MyEncounter1010.1" PatientKey="-10010" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
	<Encounter EncounterKey="-20020" EncounterUniqueIdentifier="MyEncounter1010.2" PatientKey="-10010" PrimaryInsuranceIdentifier="UnitedHealth" SecondaryInsuranceIdentifier="" ClinicalDataOriginKey="10001"/>
</Encounters>
<ChaseRequests>
	<ChaseRequest ChaseRequestKey="-30001" ChaseRequestGroupKey="-111" EncounterKey="-20001" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30002" ChaseRequestGroupKey="-111" EncounterKey="-20002" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30003" ChaseRequestGroupKey="-111" EncounterKey="-20003" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30004" ChaseRequestGroupKey="-111" EncounterKey="-20004" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30005" ChaseRequestGroupKey="-111" EncounterKey="-20005" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30006" ChaseRequestGroupKey="-111" EncounterKey="-20006" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30007" ChaseRequestGroupKey="-111" EncounterKey="-20007" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30008" ChaseRequestGroupKey="-111" EncounterKey="-20008" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30009" ChaseRequestGroupKey="-111" EncounterKey="-20009" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30010" ChaseRequestGroupKey="-111" EncounterKey="-20010" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30011" ChaseRequestGroupKey="-111" EncounterKey="-20011" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30012" ChaseRequestGroupKey="-111" EncounterKey="-20012" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30013" ChaseRequestGroupKey="-111" EncounterKey="-20013" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30014" ChaseRequestGroupKey="-111" EncounterKey="-20014" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30015" ChaseRequestGroupKey="-111" EncounterKey="-20015" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30016" ChaseRequestGroupKey="-111" EncounterKey="-20016" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30017" ChaseRequestGroupKey="-111" EncounterKey="-20017" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30018" ChaseRequestGroupKey="-111" EncounterKey="-20018" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30019" ChaseRequestGroupKey="-111" EncounterKey="-20019" ClinicalDataOriginKey="10001"/>
	<ChaseRequest ChaseRequestKey="-30020" ChaseRequestGroupKey="-111" EncounterKey="-20020" ClinicalDataOriginKey="10001"/>
</ChaseRequests>
<ChaseRequestHistorys>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40001" ChaseRequestKey="-30001" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40002" ChaseRequestKey="-30002" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40003" ChaseRequestKey="-30003" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40004" ChaseRequestKey="-30004" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40005" ChaseRequestKey="-30005" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40006" ChaseRequestKey="-30006" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40007" ChaseRequestKey="-30007" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40008" ChaseRequestKey="-30008" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40009" ChaseRequestKey="-30009" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40010" ChaseRequestKey="-30010" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40011" ChaseRequestKey="-30011" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40012" ChaseRequestKey="-30012" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40013" ChaseRequestKey="-30013" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40014" ChaseRequestKey="-30014" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40015" ChaseRequestKey="-30015" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40016" ChaseRequestKey="-30016" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40017" ChaseRequestKey="-30017" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40018" ChaseRequestKey="-30018" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40019" ChaseRequestKey="-30019" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
	<ChaseRequestHistory ChaseRequestHistoryKey="-40020" ChaseRequestKey="-30020" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
</ChaseRequestHistorys>
<ChaseRequestGroups>
	<ChaseRequestGroup ChaseRequestGroupKey="-111" ClinicalDataOriginKey="10001"/>
</ChaseRequestGroups>
<ChaseRequestGroupHistorys>
	<ChaseRequestGroupHistory ChaseRequestGroupHistoryKey="-222" ChaseRequestGroupKey="-111" MacroStatusKey="5" MicroStatusKey="1005" ClinicalDataOriginKey="10001"/>
</ChaseRequestGroupHistorys>	

</root>

 '


 SELECT * from dbo.Patient
 SELECT * from dbo.Encounter
 SELECT * from dbo.ChaseRequestGroup
  SELECT * from dbo.ChaseRequestGroupHistory
 SELECT * from dbo.ChaseRequest
  SELECT * from dbo.ChaseRequestHistory



*/

	SET NOCOUNT ON

	/* values for tcy/catch */
	DECLARE @ErrorNumber							INT,  
			@ErrorSeverity							INT , 
			@ErrorState								INT ,  
			@ErrorProcedure							NVARCHAR(4000) ,  
			@ErrorLine								INT , 
			@ErrorMessage							NVARCHAR(4000)


	/* variables to return all insert/update counts */
	DECLARE @PatientInsertCount						INT = 0, 
			@PatientUpdateCount						INT = 0, 
			@EncounterInsertCount					INT = 0, 
			@EncounterUpdateCount					INT = 0, 
			@ChaseRequestHistoryInsertCount			INT = 0, 
			@ChaseRequestHistoryUpdateCount			INT = 0, 
			@ChaseRequestInsertCount				INT = 0, 
			@ChaseRequestUpdateCount				INT = 0, 
			@ChaseRequestGroupInsertCount			INT = 0, 
			@ChaseRequestGroupUpdateCount			INT = 0, 
			@ChaseRequestGroupHistoryInsertCount	INT = 0,  
			@ChaseRequestGroupHistoryUpdateCount	INT = 0


	/********************************************* Table Variable Declaration***********************************/
	DECLARE @PatientHolder TABLE (
		 [XmlInputPatientKey]						BIGINT			NOT NULL
		,[DatabaseValuePatientKey]					INT
		,[PatientUniqueIdentifier]					VARCHAR(256)	NOT NULL
		,[ClinicalDataOriginKey]					INT				NOT NULL	
		,[InsertDate]								DATETIME
		,[InsertedBy]								NVARCHAR(128)
		,[LastUpdated]								DATETIME
		,[LastUpdatedBy]							NVARCHAR(128)
		);

	DECLARE @PatientSurrogateKeyAudit TABLE ( NaturalKey VARCHAR(256), DatabaseKey BIGINT,[ClinicalDataOriginKey] INT);

	DECLARE @EncounterHolder TABLE (
		[XmlInputEncounterKey]						BIGINT			NOT NULL
		,[DatabaseValueEncounterKey]				BIGINT			NULL
		,[XmlInputPatientKey]						BIGINT			NOT NULL
		,[DatabaseValuePatientKey]					BIGINT			NULL
		,[EncounterUniqueIdentifier]				VARCHAR(256)	NOT NULL
		,[ClinicalDataOriginKey]					INT				NOT NULL	
		,[PrimaryInsuranceIdentifier]				VARCHAR(256)	NULL
		,[SecondaryInsuranceIdentifier]				VARCHAR(256)	NULL
		,[TertiaryInsuranceIdentifier]				VARCHAR(256)	NULL
		,[QuaternaryInsuranceIdentifier]			VARCHAR(256)	NULL
		,[QuinaryInsuranceIdentifier]				VARCHAR(256)	NULL
		,[InsertDate]								DATETIME
		,[InsertedBy]								NVARCHAR(128)
		,[LastUpdated]								DATETIME
		,[LastUpdatedBy]							NVARCHAR(128)
		);

	DECLARE @EncounterSurrogateKeyAudit TABLE( 
		NaturalKey									VARCHAR(256)
		,DatabaseKey								BIGINT 
		,[ClinicalDataOriginKey]					INT			
		,[DeletedPrimaryInsuranceIdentifier]		VARCHAR(256)
		,[InsertedPrimaryInsuranceIdentifier]		VARCHAR(256)
		,[DeletedSecondaryInsuranceIdentifier]		VARCHAR(256)
		,[InsertedSecondaryInsuranceIdentifier]		VARCHAR(256)
		,[DeletedLastUpdated]						DATETIME
		); /* Natural Key will be EncounterUniqueIdentifier */

	
	DECLARE @ChaseRequestGroupHolder TABLE (
		[XmlInputChaseRequestGroupKey]				BIGINT			NOT NULL
		,[DatabaseValueChaseRequestGroupKey]		BIGINT
		,[ChaseRequestGroupUniqueIdentifier]		VARCHAR(64)		NOT NULL
		,[ClinicalDataOriginKey]					INT				NOT NULL	
		,[InsertDate]								DATETIME
		,[InsertedBy]								NVARCHAR(128)
		,[LastUpdated]								DATETIME
		,[LastUpdatedBy]							NVARCHAR(128)
		);

	DECLARE @ChaseRequestGroupSurrogateKeyAudit TABLE	( 
		NaturalKey									UNIQUEIDENTIFIER
		,DatabaseKey								BIGINT
		,[ClinicalDataOriginKey]					INT		); /* NaturalKey = [ChaseRequestGroupUniqueIdentifier] */

	DECLARE @ChaseRequestGroupHistoryHolder TABLE (
		[XmlInputChaseRequestGroupHistoryKey]		BIGINT	NOT NULL
		,[DatabaseValueChaseRequestGroupHistoryKey]	BIGINT
		,[XmlInputChaseRequestGroupKey]				BIGINT	NOT NULL
		,[DatabaseValueChaseRequestGroupKey]		BIGINT
		,[ClinicalDataOriginKey]					INT		NOT NULL	
		,[MicroStatusKey]							INT		NOT NULL
		,[MacroStatusKey]							INT		NOT NULL
		,[InsertDate]								DATETIME
		,[InsertedBy]								NVARCHAR(128)
		,[LastUpdated]								DATETIME
		,[LastUpdatedBy]							NVARCHAR(128)
		);

	DECLARE @ChaseRequestHolder TABLE (
		[XmlInputChaseRequestKey]					BIGINT	NOT NULL
		,[DatabaseValueChaseRequestKey]				BIGINT
		,[XmlInputChaseRequestGroupKey]				BIGINT	NOT NULL
		,[DatabaseValueChaseRequestGroupKey]		BIGINT
		,[XmlInputEncounterKey]						BIGINT	NOT NULL
		,[DatabaseValueEncounterKey]				BIGINT	NULL
		,[ClinicalDataOriginKey]					INT		NOT NULL	
		,[InsertDate]								DATETIME
		,[InsertedBy]								NVARCHAR(128)
		,[LastUpdated]								DATETIME
		,[LastUpdatedBy]							NVARCHAR(128)
		);

	DECLARE @ChaseRequestSurrogateKeyAudit TABLE (
		 NaturalKey1								BIGINT, 
		 NaturalKey2								BIGINT, 
		 DatabaseKey								BIGINT,
		 [ClinicalDataOriginKey]					INT  
	); /* NaturalKey1 = [ChaseRequestGroupKey], NaturalKey2= [EncounterKey] */

	DECLARE @ChaseRequestHistoryHolder TABLE (
		[XmlInputChaseRequestHistoryKey]			BIGINT	NOT NULL
		,[DatabaseValueChaseRequestHistoryKey]		BIGINT		
		, [XmlInputChaseRequestKey]					BIGINT	NOT NULL
		,[DatabaseValueChaseRequestKey]				BIGINT
		,[ClinicalDataOriginKey]					INT		NOT NULL	
		,[MicroStatusKey]							INT		NOT NULL
		,[MacroStatusKey]							INT		NOT NULL
		,[InsertDate]								DATETIME
		,[InsertedBy]								NVARCHAR(128)
		,[LastUpdated]								DATETIME
		,[LastUpdatedBy]							NVARCHAR(128)
		);

	/* shred the Patient xml */
	INSERT INTO @PatientHolder (
		 [XmlInputPatientKey]
		,[PatientUniqueIdentifier]
		,[ClinicalDataOriginKey]
		,[InsertDate]
		,[InsertedBy]
		,[LastUpdated]
		,[LastUpdatedBy]
		)
	SELECT T.MyEntity.value('@PatientKey', 'INT')						AS PatientKey
		,T.MyEntity.value('@PatientUniqueIdentifier', 'VARCHAR(256)')	AS PatientUniqueIdentifier
		,T.MyEntity.value('@ClinicalDataOriginKey', 'INT')				AS [ClinicalDataOriginKey]
		,T.MyEntity.value('@InsertDate', 'DATETIME')					AS InsertDate
		,T.MyEntity.value('@InsertedBy', 'NVARCHAR(50)')				AS InsertedBy
		,T.MyEntity.value('@LastUpdated', 'DATETIME')					AS LastUpdated
		,T.MyEntity.value('@LastUpdatedBy', 'NVARCHAR(50)')				AS LastUpdatedBy 
	FROM @ParameterXml.nodes('root/Patients/Patient') AS T(MyEntity);

	/* shred the Encounter xml */
	INSERT INTO @EncounterHolder (
		[XmlInputEncounterKey]
		,[XmlInputPatientKey]
		,[EncounterUniqueIdentifier]
		,[ClinicalDataOriginKey]
		,[PrimaryInsuranceIdentifier]
		,[SecondaryInsuranceIdentifier]
		,[TertiaryInsuranceIdentifier]	
		,[QuaternaryInsuranceIdentifier] 
		,[QuinaryInsuranceIdentifier]
		,[InsertDate]
		,[InsertedBy]
		,[LastUpdated]
		,[LastUpdatedBy]
		)
	SELECT T.MyEntity.value('@EncounterKey', 'INT')							AS EncounterKey
		,T.MyEntity.value('@PatientKey', 'INT')								AS PatientKey
		,T.MyEntity.value('@EncounterUniqueIdentifier', 'VARCHAR(256)')		AS EncounterUniqueIdentifier
		,T.MyEntity.value('@ClinicalDataOriginKey', 'INT')					AS [ClinicalDataOriginKey]
		,T.MyEntity.value('@PrimaryInsuranceIdentifier', 'VARCHAR(256)')	AS PrimaryInsuranceIdentifier
		,T.MyEntity.value('@SecondaryInsuranceIdentifier', 'VARCHAR(256)')	AS SecondaryInsuranceIdentifier
		,T.MyEntity.value('@TertiaryInsuranceIdentifier', 'VARCHAR(256)')	AS TertiaryInsuranceIdentifier
		,T.MyEntity.value('@QuaternaryInsuranceIdentifier', 'VARCHAR(256)')	AS QuaternaryInsuranceIdentifier
		,T.MyEntity.value('@QuinaryInsuranceIdentifier', 'VARCHAR(256)')	AS QuinaryInsuranceIdentifier
		,T.MyEntity.value('@InsertDate', 'DATETIME')						AS InsertDate
		,T.MyEntity.value('@InsertedBy', 'NVARCHAR(50)')					AS InsertedBy
		,T.MyEntity.value('@LastUpdated', 'DATETIME')						AS LastUpdated
		,T.MyEntity.value('@LastUpdatedBy', 'NVARCHAR(50)')					AS LastUpdatedBy 
	FROM @ParameterXml.nodes('root/Encounters/Encounter') AS T(MyEntity);

	/* shred the ChaseRequestGroup xml */
	INSERT INTO @ChaseRequestGroupHolder (
		[XmlInputChaseRequestGroupKey]
		,[ChaseRequestGroupUniqueIdentifier]
		,[ClinicalDataOriginKey]
		,[InsertDate]
		,[InsertedBy]
		,[LastUpdated]
		,[LastUpdatedBy]
		)
	SELECT T.MyEntity.value('@ChaseRequestGroupKey', 'INT')					AS ChaseRequestGroupKey
		,COALESCE(T.MyEntity.value('@ChaseRequestGroupUniqueIdentifier', 'VARCHAR(64)') , CONVERT(VARCHAR(64), NEWID())) as ChaseRequestGroupUniqueIdentifier
		,T.MyEntity.value('@ClinicalDataOriginKey', 'INT')					AS [ClinicalDataOriginKey]
		,T.MyEntity.value('@InsertDate', 'DATETIME')						AS InsertDate
		,T.MyEntity.value('@InsertedBy', 'NVARCHAR(50)')					AS InsertedBy
		,T.MyEntity.value('@LastUpdated', 'DATETIME')						AS LastUpdated
		,T.MyEntity.value('@LastUpdatedBy', 'NVARCHAR(50)')					AS LastUpdatedBy 
	FROM @ParameterXml.nodes('root/ChaseRequestGroups/ChaseRequestGroup')	AS T(MyEntity);

	/* shred the ChaseRequestGroupHistory xml */
	INSERT INTO @ChaseRequestGroupHistoryHolder (
		[XmlInputChaseRequestGroupHistoryKey]
		,[XmlInputChaseRequestGroupKey]
		,[ClinicalDataOriginKey]		
		,[MacroStatusKey]
		,[MicroStatusKey]
		,[InsertDate]
		,[InsertedBy]
		,[LastUpdated]
		,[LastUpdatedBy]
		)
	SELECT T.MyEntity.value('@ChaseRequestGroupHistoryKey', 'INT')			AS ChaseRequestGroupHistoryKey
		,T.MyEntity.value('@ChaseRequestGroupKey', 'INT')					AS ChaseRequestGroupKey
		,T.MyEntity.value('@ClinicalDataOriginKey', 'INT')					AS ClinicalDataOriginKey
		,T.MyEntity.value('@MacroStatusKey', 'INT')							AS MacroStatusKey
		,T.MyEntity.value('@MicroStatusKey', 'INT')							AS MicroStatusKey
		,T.MyEntity.value('@InsertDate', 'DATETIME')						AS InsertDate
		,T.MyEntity.value('@InsertedBy', 'NVARCHAR(50)')					AS InsertedBy
		,T.MyEntity.value('@LastUpdated', 'DATETIME')						AS LastUpdated
		,T.MyEntity.value('@LastUpdatedBy', 'NVARCHAR(50)')					AS LastUpdatedBy 
	FROM @ParameterXml.nodes('root/ChaseRequestGroupHistorys/ChaseRequestGroupHistory') AS T(MyEntity);

	
	/* shred the ChaseRequestHistory xml */
	INSERT INTO @ChaseRequestHistoryHolder (
		[XmlInputChaseRequestHistoryKey]
		,[XmlInputChaseRequestKey]
		,[ClinicalDataOriginKey]		
		,[MacroStatusKey]
		,[MicroStatusKey]
		,[InsertDate]
		,[InsertedBy]
		,[LastUpdated]
		,[LastUpdatedBy]
		)
	SELECT T.MyEntity.value('@ChaseRequestHistoryKey', 'INT')				AS ChaseRequestHistoryKey
		,T.MyEntity.value('@ChaseRequestKey', 'INT')						AS ChaseRequestKey
		,T.MyEntity.value('@ClinicalDataOriginKey', 'INT')					AS [ClinicalDataOriginKey]
		,T.MyEntity.value('@MacroStatusKey', 'INT')							AS MacroStatusKey
		,T.MyEntity.value('@MicroStatusKey', 'INT')							AS MicroStatusKey
		,T.MyEntity.value('@InsertDate', 'DATETIME')						AS InsertDate
		,T.MyEntity.value('@InsertedBy', 'NVARCHAR(50)')					AS InsertedBy
		,T.MyEntity.value('@LastUpdated', 'DATETIME')						AS LastUpdated
		,T.MyEntity.value('@LastUpdatedBy', 'NVARCHAR(50)')					AS LastUpdatedBy 
	FROM @ParameterXml.nodes('root/ChaseRequestHistorys/ChaseRequestHistory') AS T(MyEntity);


	/* shred the ChaseRequest xml */
	INSERT INTO @ChaseRequestHolder (
		[XmlInputChaseRequestKey]
		,[XmlInputChaseRequestGroupKey]
		,[XmlInputEncounterKey]
		,[ClinicalDataOriginKey]
		,[InsertDate]
		,[InsertedBy]
		,[LastUpdated]
		,[LastUpdatedBy]
		)
	SELECT T.MyEntity.value('@ChaseRequestKey', 'INT')						AS ChaseRequestKey
		,T.MyEntity.value('@ChaseRequestGroupKey', 'INT')					AS ChaseRequestGroupKey
		,T.MyEntity.value('@EncounterKey', 'BIGINT')						AS EncounterKey
		,T.MyEntity.value('@ClinicalDataOriginKey', 'INT')					AS [ClinicalDataOriginKey]
		,T.MyEntity.value('@InsertDate', 'DATETIME')						AS InsertDate
		,T.MyEntity.value('@InsertedBy', 'NVARCHAR(50)')					AS InsertedBy
		,T.MyEntity.value('@LastUpdated', 'DATETIME')						AS LastUpdated
		,T.MyEntity.value('@LastUpdatedBy', 'NVARCHAR(50)')					AS LastUpdatedBy 
	FROM @ParameterXml.nodes('root/ChaseRequests/ChaseRequest') AS T(MyEntity);

	/* post shred checks */

	BEGIN TRY

		IF EXISTS (	SELECT NULL FROM @EncounterHolder holder 
					WHERE NOT EXISTS (	SELECT 1 
										FROM @PatientHolder parentHolder 
										WHERE parentHolder.XmlInputPatientKey = holder.XmlInputPatientKey
										AND   parentHolder.ClinicalDataOriginKey = holder.ClinicalDataOriginKey
									 )
				   )
		BEGIN
			;THROW 51000, 'Encounter Rows exist without corresponding Patient rows. (Mismatched XmlInputPatientKey)', 1; 
		END

		IF EXISTS (	SELECT NULL FROM @ChaseRequestHolder holder 
					WHERE NOT EXISTS (	SELECT 1 
										FROM @ChaseRequestGroupHolder parentHolder 
										WHERE parentHolder.XmlInputChaseRequestGroupKey = holder.XmlInputChaseRequestGroupKey
										AND   parentHolder.ClinicalDataOriginKey		= holder.ClinicalDataOriginKey
									  )
				  )
		BEGIN
			;THROW 51000, 'ChaseRequest Rows exist without corresponding ChaseRequestGroup rows. (Mismatched XmlInputChaseRequestGroupKey)', 1;
		END

		IF EXISTS (	SELECT NULL from @ChaseRequestHolder holder 
					WHERE NOT EXISTS (	SELECT 1 
										FROM @EncounterHolder parentHolder 
										WHERE parentHolder.XmlInputEncounterKey = holder.XmlInputEncounterKey
										AND   parentHolder.ClinicalDataOriginKey = holder.ClinicalDataOriginKey
									  )
				  )
		BEGIN
			;THROW 51000, 'ChaseRequest Rows exist without corresponding Encounter rows. (Mismatched XmlInputEncounterKey)', 1;
		END

		IF EXISTS (	SELECT NULL FROM @ChaseRequestHistoryHolder holder 
					WHERE XmlInputChaseRequestKey < 0	
					AND		NOT EXISTS (	SELECT 1 
										FROM @ChaseRequestHolder parentHolder 
										WHERE parentHolder.XmlInputChaseRequestKey = holder.XmlInputChaseRequestKey
										AND   parentHolder.ClinicalDataOriginKey   = holder.ClinicalDataOriginKey
									  )
				)
		BEGIN
			;THROW 51000, 'ChaseRequestHistory Rows exist without corresponding ChaseRequest rows. (Mismatched XmlInputChaseRequestKey)', 1;
		END

		IF EXISTS (	SELECT NULL FROM @ChaseRequestHistoryHolder holder 
					WHERE XmlInputChaseRequestKey > 0	 
					AND	NOT EXISTS (	SELECT 1 
										FROM  dbo.ChaseRequest parentHolder 
										WHERE parentHolder.ChaseRequestKey = holder.XmlInputChaseRequestKey
										AND   parentHolder.ClinicalDataOriginKey = holder.ClinicalDataOriginKey
										)
				  )
		BEGIN
			;THROW 51000, 'ChaseRequestKey is not valid and doesn''t exist', 1;
		END

		IF EXISTS (	SELECT NULL FROM @ChaseRequestGroupHistoryHolder holder 
					WHERE NOT EXISTS (	SELECT 1 
										FROM @ChaseRequestGroupHolder parentHolder 
										WHERE parentHolder.XmlInputChaseRequestGroupKey = holder.XmlInputChaseRequestGroupKey
										AND   parentHolder.ClinicalDataOriginKey = holder.ClinicalDataOriginKey
										)
				  )
		BEGIN
			;THROW 51000, 'ChaseRequestGroupHistory Rows exist without corresponding ChaseRequestGroup rows. (Mismatched XmlInputChaseRequestGroupKey)', 1;
		END

		/* Because of the "MAX" trick to write the surrogate keys, start the TRAN here */
		BEGIN TRANSACTION;

	   ----    SELECT [Debugging@PatientHolder] = 'Debugging@PatientHolder' , * FROM @PatientHolder
	   ----    SELECT [Debugging@EncounterHolder] = 'Debugging@EncounterHolder' , * FROM @EncounterHolder
	   ----    SELECT [Debugging@ChaseRequestGroupHolder] = 'Debugging@ChaseRequestGroupHolder' , * FROM @ChaseRequestGroupHolder
	   ----    SELECT [Debugging@ChaseRequestHolder] = 'Debugging@ChaseRequestHolder' , * FROM @ChaseRequestHolder
	   ----    SELECT [Debugging@ChaseRequestHistoryHolder] = 'Debugging@ChaseRequestHistoryHolder' , * FROM @ChaseRequestHistoryHolder
	   ----    SELECT [Debugging@ChaseRequestGroupHistoryHolder] = 'Debugging@ChaseRequestGroupHistoryHolder' , * FROM @ChaseRequestGroupHistoryHolder

		/* Everything above is xml-shredding and setting key values in @variableTables.  Everything below is actually upserting the real tables */

		/* Sql Server MERGE functionality has multiple issues.  Use separate INSERT/UPDATE statements.  See https://www.mssqltips.com/sqlservertip/3074/use-caution-with-sql-servers-merge-statement/ */

		UPDATE [dbo].[Patient]
		SET		 [InsertDate]		= ISNULL(holder.[InsertDate], realTable.InsertDate) /* use the original InsertDate if no InsertDate is specified */
				,[InsertedBy]		= ISNULL(holder.[InsertedBy], realTable.InsertedBy) /* use the original InsertedBy if no InsertedBy is specified */
				,[LastUpdated]		= ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
				,[LastUpdatedBy]	= ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())
		OUTPUT	inserted.PatientUniqueIdentifier , inserted.PatientKey,inserted.ClinicalDataOriginKey
		INTO	@PatientSurrogateKeyAudit	(NaturalKey ,DatabaseKey,ClinicalDataOriginKey )
		FROM	@PatientHolder holder		INNER JOIN 
				[dbo].[Patient] realTable
		ON		realTable.ClinicalDataOriginKey		= holder.ClinicalDataOriginKey
		AND		realTable.PatientUniqueIdentifier	= holder.PatientUniqueIdentifier; /* Allow true Upsert for Patients */

		SELECT @PatientUpdateCount = @@ROWCOUNT

		INSERT INTO [dbo].[Patient] (
			 [PatientUniqueIdentifier]
			,ClinicalDataOriginKey
			,[InsertDate]
			,[InsertedBy]
			,[LastUpdated]
			,[LastUpdatedBy]
			
			)
		OUTPUT inserted.PatientUniqueIdentifier , inserted.PatientKey,inserted.ClinicalDataOriginKey 
		INTO	@PatientSurrogateKeyAudit(NaturalKey ,DatabaseKey,ClinicalDataOriginKey )
		SELECT
			holder.[PatientUniqueIdentifier]
			,holder.ClinicalDataOriginKey
			,[InsertDate]		= ISNULL(holder.[InsertDate], CURRENT_TIMESTAMP)
			,[InsertedBy]		= ISNULL(holder.[InsertedBy], SUSER_SNAME())
			,[LastUpdated]		= ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
			,[LastUpdatedBy]	= ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())
			
		FROM @PatientHolder holder
		WHERE NOT EXISTS (
							SELECT NULL
							FROM	[dbo].[Patient] realTable
							WHERE	realTable.ClinicalDataOriginKey		= holder.ClinicalDataOriginKey
							AND		realTable.PatientUniqueIdentifier	= holder.PatientUniqueIdentifier /* Allow true Upsert for Patients */
						);

		SELECT @PatientInsertCount = @@ROWCOUNT;

		/* update @variableTable to have the true database surrogate key */
		UPDATE @PatientHolder
		SET		[DatabaseValuePatientKey]		= auditTable.DatabaseKey
		FROM 	@PatientSurrogateKeyAudit auditTable		INNER JOIN 
				@PatientHolder holder
		ON		holder.PatientUniqueIdentifier	= auditTable.NaturalKey
		AND		holder.ClinicalDataOriginKey	= auditTable.ClinicalDataOriginKey

		/* Start massage the data in @EncounterHolder */

		/* "Reconnect" the Parent-Children relationship with the database-values (that exist or that will be inserted) */
		UPDATE	@EncounterHolder
		SET		[DatabaseValuePatientKey]			 = auditTable.DatabaseKey
		FROM	@PatientSurrogateKeyAudit auditTable		JOIN 
				@PatientHolder parentHolder
		ON		parentHolder.PatientUniqueIdentifier = auditTable.NaturalKey
		AND		parentholder.ClinicalDataOriginKey	 = auditTable.ClinicalDataOriginKey JOIN 
				@EncounterHolder holder
		ON		holder.XmlInputPatientKey			 = parentHolder.XmlInputPatientKey
		AND		holder.ClinicalDataOriginKey		 = parentHolder.ClinicalDataOriginKey

		UPDATE [dbo].[Encounter]
		SET	  [InsertDate]						= ISNULL(holder.[InsertDate], realTable.InsertDate) /* use the original InsertDate if no InsertDate is specified */
			, [InsertedBy]						= ISNULL(holder.[InsertedBy], realTable.InsertedBy) /* use the original InsertedBy if no InsertedBy is specified */
			, [LastUpdated]						= ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
			, [LastUpdatedBy]					= ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())
			/* on update, need to "history" capture the "before" PrimaryInsuranceIdentifier and SecondaryInsuranceIdentifier IIF they are different */
		OUTPUT	inserted.EncounterUniqueIdentifier			, 
				inserted.EncounterKey						,
				deleted.LastUpdated							,
				inserted.ClinicalDataOriginKey
		INTO	@EncounterSurrogateKeyAudit(
				NaturalKey								
				,DatabaseKey							
				,[DeletedLastUpdated]
				,ClinicalDataOriginKey
				)
		FROM	@EncounterHolder holder INNER JOIN 
				[dbo].[Encounter] realTable
			/* use the unique-constraint here */
		ON		realTable.PatientKey				= holder.DatabaseValuePatientKey 
		AND		realTable.EncounterUniqueIdentifier = holder.EncounterUniqueIdentifier;

		SELECT @EncounterUpdateCount = @@ROWCOUNT

		INSERT INTO [dbo].[Encounter] (
			[PatientKey]
			,[EncounterUniqueIdentifier]
			,ClinicalDataOriginKey
			,[InsertDate]
			,[InsertedBy]
			,[LastUpdated]
			,[LastUpdatedBy]
			)
		OUTPUT inserted.EncounterUniqueIdentifier , inserted.EncounterKey,Inserted.ClinicalDataOriginKey 
		INTO @EncounterSurrogateKeyAudit(NaturalKey,DatabaseKey,ClinicalDataOriginKey ) 
		SELECT
			 holder.[DatabaseValuePatientKey]
			,holder.[EncounterUniqueIdentifier]
			,holder.ClinicalDataOriginKey
			,[InsertDate]		= ISNULL(holder.[InsertDate], CURRENT_TIMESTAMP)
			,[InsertedBy]		= ISNULL(holder.[InsertedBy], SUSER_SNAME())
			,[LastUpdated]		= ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
			,[LastUpdatedBy]	= ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())
			
		FROM @EncounterHolder holder
		WHERE NOT EXISTS (
							SELECT	NULL
							FROM	[dbo].[Encounter] realTable
							WHERE	realTable.PatientKey				= holder.DatabaseValuePatientKey 
							AND		realTable.EncounterUniqueIdentifier = holder.EncounterUniqueIdentifier
						);

		SELECT @EncounterInsertCount = @@ROWCOUNT

		/* --------------------------------------------------------------------------------------------------------------------------------- */

		UPDATE	[dbo].[ChaseRequestGroup]
		SET		[InsertDate]		= ISNULL(holder.[InsertDate], realTable.InsertDate) /* use the original InsertDate if no InsertDate is specified */
				,[InsertedBy]		= ISNULL(holder.[InsertedBy], realTable.InsertedBy) /* use the original InsertedBy if no InsertedBy is specified */
				,[LastUpdated]		= ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
				,[LastUpdatedBy]	= ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())
		OUTPUT	inserted.ChaseRequestGroupUniqueIdentifier , inserted.ChaseRequestGroupKey ,Inserted.ClinicalDataOriginKey
		INTO	@ChaseRequestGroupSurrogateKeyAudit(NaturalKey , DatabaseKey,ClinicalDataOriginKey )
		FROM	@ChaseRequestGroupHolder holder		INNER JOIN 
				[dbo].[ChaseRequestGroup] realTable
		ON		realTable.ChaseRequestGroupKey  = holder.XmlInputChaseRequestGroupKey
		
		SELECT @ChaseRequestGroupUpdateCount = @@ROWCOUNT


		INSERT INTO [dbo].[ChaseRequestGroup] (
			ChaseRequestGroupUniqueIdentifier
			,[InsertDate]
			,[InsertedBy]
			,[LastUpdated]
			,[LastUpdatedBy]
			,[ClinicalDataOriginKey]
			)
		OUTPUT	inserted.ChaseRequestGroupUniqueIdentifier , inserted.ChaseRequestGroupKey,inserted.ClinicalDataOriginKey 
		INTO	@ChaseRequestGroupSurrogateKeyAudit(NaturalKey , DatabaseKey,ClinicalDataOriginKey)
		SELECT
			holder.ChaseRequestGroupUniqueIdentifier
			,[InsertDate]		= ISNULL(holder.[InsertDate], CURRENT_TIMESTAMP)
			,[InsertedBy]		= ISNULL(holder.[InsertedBy], SUSER_SNAME())
			,[LastUpdated]		= ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
			,[LastUpdatedBy]	= ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())
			,holder.ClinicalDataOriginKey
		FROM @ChaseRequestGroupHolder holder
		WHERE NOT EXISTS (
							SELECT NULL
							FROM [dbo].[ChaseRequestGroup] realTable
							WHERE	realTable.ChaseRequestGroupKey =	holder.XmlInputChaseRequestGroupKey
						 );

		SELECT @ChaseRequestGroupInsertCount = @@ROWCOUNT

		/* "fix" the ChaseRequestGroupUniqueIdentifier since we allow that to be created in this procedure */ --09/07
		UPDATE	@ChaseRequestGroupHolder
		SET		ChaseRequestGroupUniqueIdentifier	= auditTable.NaturalKey
		FROM	@ChaseRequestGroupSurrogateKeyAudit auditTable JOIN 
				@ChaseRequestGroupHolder holder
		ON		auditTable.DatabaseKey				= holder.XmlInputChaseRequestGroupKey

		/* update @ChaseRequestHolder true database surrogate key ([DatabaseValueChaseRequestGroupKey]) */

		/* update (child) @variableTable to have the true database surrogate key */

		
		UPDATE	@ChaseRequestHolder
		SET		[DatabaseValueChaseRequestGroupKey] = auditTable.DatabaseKey
		FROM 	@ChaseRequestGroupSurrogateKeyAudit auditTable											INNER JOIN 
				@ChaseRequestGroupHolder parentHolder
		ON		parentHolder.ChaseRequestGroupUniqueIdentifier = auditTable.NaturalKey
		AND		parentHolder.ClinicalDataOriginKey			   = auditTable.ClinicalDataOriginKey		
																										INNER JOIN 
				@ChaseRequestHolder holder
		ON		holder.XmlInputChaseRequestGroupKey = parentHolder.XmlInputChaseRequestGroupKey
		AND		holder.ClinicalDataOriginKey		= parentHolder.ClinicalDataOriginKey

		
		UPDATE	@ChaseRequestGroupHistoryHolder
		SET		[DatabaseValueChaseRequestGroupKey] = auditTable.DatabaseKey
		FROM 	@ChaseRequestGroupSurrogateKeyAudit auditTable											INNER JOIN 
				@ChaseRequestGroupHolder parentHolder
		ON		parentHolder.ChaseRequestGroupUniqueIdentifier = auditTable.NaturalKey
		AND		parentHolder.ClinicalDataOriginKey = auditTable.ClinicalDataOriginKey 					INNER JOIN 
				@ChaseRequestGroupHistoryHolder holder
		ON		holder.XmlInputChaseRequestGroupKey = parentHolder.XmlInputChaseRequestGroupKey
		AND		holder.ClinicalDataOriginKey		= parentHolder.ClinicalDataOriginKey

		
		/* update @ChaseRequestHolder true database surrogate key ([DatabaseValueEncounterKey]) */

		UPDATE	@ChaseRequestHolder
		SET		[DatabaseValueEncounterKey] = auditTable.DatabaseKey
		FROM 	@EncounterSurrogateKeyAudit auditTable		INNER JOIN 
				@EncounterHolder parentHolder
		ON		parentHolder.EncounterUniqueIdentifier = auditTable.NaturalKey
		AND		parentHolder.ClinicalDataOriginKey     = auditTable.ClinicalDataOriginKey	
															INNER JOIN 
				@ChaseRequestHolder holder
		ON		holder.XmlInputEncounterKey		= parentHolder.XmlInputEncounterKey
		AND		holder.ClinicalDataOriginKey	= parentHolder.ClinicalDataOriginKey

		/* ------------------------------- */

		UPDATE [dbo].[ChaseRequestGroupHistory]
		SET	 --[ChaseRequestGroupKey] = holder.[DatabaseValueChaseRequestGroupKey]
			 [MacroStatusKey]		= holder.[MacroStatusKey]
			,[MicroStatusKey]		= holder.[MicroStatusKey]
			,[InsertDate]			= ISNULL(holder.[InsertDate], realTable.InsertDate) /* use the original InsertDate if no InsertDate is specified */
			,[InsertedBy]			= ISNULL(holder.[InsertedBy], realTable.InsertedBy) /* use the original InsertedBy if no InsertedBy is specified */
			,[LastUpdated]			= ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
			,[LastUpdatedBy]		= ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())
		FROM @ChaseRequestGroupHistoryHolder holder			INNER JOIN 
			[dbo].[ChaseRequestGroupHistory] realTable
		ON	realTable.ChaseRequestGroupHistoryKey = holder.[XmlInputChaseRequestGroupHistoryKey];

		SELECT @ChaseRequestGroupHistoryUpdateCount = @@ROWCOUNT

		
		INSERT INTO [dbo].[ChaseRequestGroupHistory] (
			 --[ChaseRequestGroupHistoryKey]
			[ChaseRequestGroupKey]
			,[MacroStatusKey]
			,[MicroStatusKey]
			,[InsertDate]
			,[InsertedBy]
			,[LastUpdated]
			,[LastUpdatedBy]
			,[ClinicalDataOriginKey]
			)
		SELECT
			 --holder.[DatabaseValueChaseRequestGroupHistoryKey]
			holder.[DatabaseValueChaseRequestGroupKey]
			,holder.[MacroStatusKey]
			,holder.[MicroStatusKey]
			,[InsertDate]		= ISNULL(holder.[InsertDate], CURRENT_TIMESTAMP)
			,[InsertedBy]		= ISNULL(holder.[InsertedBy], SUSER_SNAME())
			,[LastUpdated]		= ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
			,[LastUpdatedBy]	= ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())
			,ClinicalDataOriginKey
		FROM @ChaseRequestGroupHistoryHolder holder
		WHERE NOT EXISTS (
							SELECT	NULL
							FROM	[dbo].[ChaseRequestGroupHistory] realTable
							--WHERE	realTable.ChaseRequestGroupHistoryKey = holder.DatabaseValueChaseRequestGroupHistoryKey
							WHERE	realTable.ChaseRequestGroupHistoryKey = holder.XmlInputChaseRequestGroupHistoryKey  -- Modified 9.12
						 );

		SELECT @ChaseRequestGroupHistoryInsertCount = @@ROWCOUNT

		/* ------------------------------- */

		UPDATE	[dbo].[ChaseRequest]
		SET		--[ChaseRequestGroupKey]	= holder.[DatabaseValueChaseRequestGroupKey]
				-- [EncounterKey]			= holder.[DatabaseValueEncounterKey]
				 [InsertDate]			= ISNULL(holder.[InsertDate], realTable.InsertDate) /* use the original InsertDate if no InsertDate is specified */
				,[InsertedBy]			= ISNULL(holder.[InsertedBy], realTable.InsertedBy) /* use the original InsertedBy if no InsertedBy is specified */
				,[LastUpdated]			= ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
				,[LastUpdatedBy]		= ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())
		OUTPUT	inserted.ChaseRequestGroupKey, inserted.EncounterKey , inserted.ChaseRequestKey,inserted.ClinicalDataOriginKey 
		INTO	@ChaseRequestSurrogateKeyAudit (NaturalKey1,NaturalKey2,DatabaseKey,ClinicalDataOriginKey)/* NaturalKey1 = [ChaseRequestGroupKey], NaturalKey2= [EncounterKey] */
		FROM	@ChaseRequestHolder holder 	INNER JOIN 
				[dbo].[ChaseRequest] realTable
		--ON		realTable.ChaseRequestKey = holder.DatabaseValueChaseRequestKey;
		ON		realTable.ChaseRequestKey = holder.XmlInputChaseRequestKey

		SELECT @ChaseRequestUpdateCount = @@ROWCOUNT


		INSERT INTO [dbo].[ChaseRequest] (
			 --[ChaseRequestKey]
			[ChaseRequestGroupKey]
			,[EncounterKey]
			,[InsertDate]
			,[InsertedBy]
			,[LastUpdated]
			,[LastUpdatedBy]
			,[ClinicalDataOriginKey]
			)
		OUTPUT inserted.ChaseRequestGroupKey, inserted.EncounterKey , inserted.ChaseRequestKey,inserted.ClinicalDataOriginKey
		INTO	@ChaseRequestSurrogateKeyAudit(NaturalKey1,NaturalKey2,DatabaseKey,ClinicalDataOriginKey) /* NaturalKey1 = [ChaseRequestGroupKey], NaturalKey2= [EncounterKey] */
		SELECT
			 --holder.[DatabaseValueChaseRequestKey]
			holder.[DatabaseValueChaseRequestGroupKey]
			,holder.[DatabaseValueEncounterKey]
			,[InsertDate]		= ISNULL(holder.[InsertDate], CURRENT_TIMESTAMP)
			,[InsertedBy]		= ISNULL(holder.[InsertedBy], SUSER_SNAME())
			,[LastUpdated]		= ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
			,[LastUpdatedBy]	= ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())
			,ClinicalDataOriginKey
		FROM @ChaseRequestHolder holder
		WHERE NOT EXISTS (
							SELECT NULL
							FROM [dbo].[ChaseRequest] realTable
							--WHERE realTable.ChaseRequestKey = holder.DatabaseValueChaseRequestKey
							WHERE realTable.ChaseRequestKey   = holder.XmlInputChaseRequestKey
						);

		SELECT @ChaseRequestInsertCount = @@ROWCOUNT

	UPDATE	@ChaseRequestHolder
	SET		--[DatabaseValueChaseRequestGroupKey] = auditTable.DatabaseKey
			[DatabaseValueChaseRequestKey] = auditTable.DatabaseKey
	FROM 	@ChaseRequestSurrogateKeyAudit auditTable INNER JOIN 
			@ChaseRequestHolder holder
			/* NaturalKey1 = [ChaseRequestGroupKey], NaturalKey2= [EncounterKey] */
	ON		holder.XmlInputChaseRequestGroupKey = auditTable.NaturalKey1 
	AND		holder.XmlInputEncounterKey = auditTable.NaturalKey2

	
	UPDATE 	@ChaseRequestHistoryHolder
	SET		[DatabaseValueChaseRequestKey] = auditTable.DatabaseKey
	FROM	@ChaseRequestSurrogateKeyAudit auditTable			INNER JOIN 
			@ChaseRequestHolder parentHolder
	ON		parentHolder.DatabaseValueChaseRequestGroupKey	= auditTable.NaturalKey1
	AND		parentHolder.DatabaseValueEncounterKey			= auditTable.NaturalKey2 	INNER JOIN 
			@ChaseRequestHistoryHolder holder			
	ON		holder.XmlInputChaseRequestKey = parentHolder.XmlInputChaseRequestKey
	AND		holder.ClinicalDataOriginKey   = parentHolder.ClinicalDataOriginKey


	/* ------------------------------- */

	UPDATE	[dbo].[ChaseRequestHistory]
	SET		--[ChaseRequestKey] = holder.[DatabaseValueChaseRequestKey]
			[MacroStatusKey] = holder.[MacroStatusKey]
			,[MicroStatusKey] = holder.[MicroStatusKey]
			,[InsertDate]	  = ISNULL(holder.[InsertDate], realTable.InsertDate) /* use the original InsertDate if no InsertDate is specified */
			,[InsertedBy]     = ISNULL(holder.[InsertedBy], realTable.InsertedBy) /* use the original InsertedBy if no InsertedBy is specified */
			,[LastUpdated]    = ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
			,[LastUpdatedBy]  = ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())
	FROM	@ChaseRequestHistoryHolder holder		INNER JOIN 
			[dbo].[ChaseRequestHistory] realTable
	--ON		realTable.ChaseRequestHistoryKey = holder.DatabaseValueChaseRequestHistoryKey;
	ON		realTable.ChaseRequestHistoryKey = holder.XmlInputChaseRequestHistoryKey

	SELECT @ChaseRequestHistoryUpdateCount = @@ROWCOUNT


		INSERT INTO [dbo].[ChaseRequestHistory] (
			 --[ChaseRequestHistoryKey]
			[ChaseRequestKey]
			,[MacroStatusKey]
			,[MicroStatusKey]
			,[InsertDate]
			,[InsertedBy]
			,[LastUpdated]
			,[LastUpdatedBy]
			,[ClinicalDataOriginKey]
			)
		SELECT
			 --holder.[DatabaseValueChaseRequestHistoryKey]
			CASE WHEN holder.XmlInputChaseRequestKey > 0 THEN holder.XmlInputChaseRequestKey ELSE [DatabaseValueChaseRequestKey]  END
			,holder.[MacroStatusKey]
			,holder.[MicroStatusKey]
			,[InsertDate]		= ISNULL(holder.[InsertDate], CURRENT_TIMESTAMP)
			,[InsertedBy]		= ISNULL(holder.[InsertedBy], SUSER_SNAME())
			,[LastUpdated]		= ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
			,[LastUpdatedBy]	= ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())
			,ClinicalDataOriginKey
		FROM @ChaseRequestHistoryHolder holder
		WHERE NOT EXISTS (
							SELECT NULL
							FROM [dbo].[ChaseRequestHistory] realTable
							WHERE realTable.ChaseRequestHistoryKey = XmlInputChaseRequestHistoryKey--holder.DatabaseValueChaseRequestHistoryKey
						);

		SELECT @ChaseRequestHistoryInsertCount = @@ROWCOUNT

		SELECT  
			alias.[ChaseRequestGroupKey]
			, alias.[ChaseRequestGroupUniqueIdentifier]
			, alias.[InsertDate]
			, alias.[InsertedBy]
			, alias.[LastUpdated]
			, alias.[LastUpdatedBy] 
			, alias.ClinicalDataOriginKey
		FROM 
			dbo.[ChaseRequestGroup] alias
			JOIN @ChaseRequestGroupSurrogateKeyAudit auditHolder
			ON alias.ChaseRequestGroupKey = auditHolder.DatabaseKey


		/* return the update and insert counts.  the dotnet layer could do a data validation */
		SELECT [PatientInsertCount] = @PatientInsertCount
			,[PatientUpdateCount] = @PatientUpdateCount
			,[EncounterInsertCount] = @EncounterInsertCount
			,[EncounterUpdateCount] = @EncounterUpdateCount
			,[ChaseRequestGroupInsertCount] = @ChaseRequestGroupInsertCount
			,[ChaseRequestGroupUpdateCount] = @ChaseRequestGroupUpdateCount
			,[ChaseRequestInsertCount] = @ChaseRequestInsertCount
			,[ChaseRequestUpdateCount] = @ChaseRequestUpdateCount
			,[ChaseRequestGroupHistoryInsertCount] = @ChaseRequestGroupHistoryInsertCount
			,[ChaseRequestGroupHistoryUpdateCount] = @ChaseRequestGroupHistoryUpdateCount
			,[ChaseRequestHistoryInsertCount] = @ChaseRequestHistoryInsertCount
			,[ChaseRequestHistoryUpdateCount]= @ChaseRequestHistoryUpdateCount

	END TRY

	BEGIN CATCH

		SELECT @ErrorNumber = ERROR_NUMBER()
			, @ErrorSeverity = ERROR_SEVERITY()
			, @ErrorState = ERROR_STATE()
			, @ErrorProcedure = ERROR_PROCEDURE()
			, @ErrorLine = ERROR_LINE()
			, @ErrorMessage = ERROR_MESSAGE();


		IF @@TRANCOUNT > 0
		BEGIN
			ROLLBACK TRANSACTION;
		END


		EXEC [logging].[uspSqlErrorInsertSingle] @ErrorNumber , @ErrorSeverity , @ErrorState , @ErrorProcedure , @ErrorLine , @ErrorMessage;


		THROW; /* Bubble the Exception to Calling Layer */
	END CATCH;

	IF @@TRANCOUNT > 0
		COMMIT TRANSACTION;

	SET NOCOUNT OFF

END