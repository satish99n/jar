﻿ALTER TABLE [dbo].[Encounter]
	ADD CONSTRAINT [FK_EncounterToClinicalDataOrigin]
	FOREIGN KEY (ClinicalDataOriginKey)
	REFERENCES [ClinicalDataOrigin] (ClinicalDataOriginKey)
