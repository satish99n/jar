﻿ALTER TABLE [dbo].[HistoricPullDefinition]
	ADD CONSTRAINT [FK_HistoricPullDefinitionToClinicalDataOrigin]
	FOREIGN KEY (ClinicalDataOriginKey)
	REFERENCES [dbo].[ClinicalDataOrigin] (ClinicalDataOriginKey)
