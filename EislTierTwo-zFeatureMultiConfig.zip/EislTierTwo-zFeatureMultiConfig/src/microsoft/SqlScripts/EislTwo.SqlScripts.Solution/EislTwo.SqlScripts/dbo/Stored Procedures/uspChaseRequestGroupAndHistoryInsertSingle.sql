﻿CREATE PROCEDURE [dbo].[uspChaseRequestGroupAndHistoryInsertSingle]
         @ChaseRequestGroupUniqueIdentifier VARCHAR(64)
       , @InsertChildHistoryRow BIT
       , @ChaseRequestGroupHistoryMacroStatusKey SMALLINT
       , @ChaseRequestGroupHistoryMicroStatusKey SMALLINT
	   , @ClinicalDataOriginKey	INT
AS

BEGIN

		/*
		The java workflow needs to create a Single [ChaseRequestGroup] and a single [ChaseRequestGroupHistory], 
		so combine into one database call to minimize trips for a very utlized workflow 
		*/

		/*

		--Example useage
		DECLARE @ChaseRequestGroupUniqueIdentifier VARCHAR(64) = CONVERT(VARCHAR(64), NEWID())
		EXEC [dbo].[uspChaseRequestGroupAndHistoryInsertSingle] @ChaseRequestGroupUniqueIdentifier, 0, 0, 0,10001

		SELECT @ChaseRequestGroupUniqueIdentifier = CONVERT(VARCHAR(64), NEWID())
		EXEC [dbo].[uspChaseRequestGroupAndHistoryInsertSingle] @ChaseRequestGroupUniqueIdentifier, 1, 5, 1005,10001
		*/

	SET NOCOUNT ON

	
    DECLARE @ChaseRequestGroupKeyIdentity			BIGINT 
    DECLARE @ChaseRequestGroupHistoryKeyIdentity	BIGINT 

	INSERT INTO [dbo].[ChaseRequestGroup]
                ([ChaseRequestGroupUniqueIdentifier],
				 [ClinicalDataOriginKey]
				)
    VALUES
                (
                  ISNULL(@ChaseRequestGroupUniqueIdentifier, CONVERT(VARCHAR(64), NEWID())),
				  @ClinicalDataOriginKey
                 )

    SELECT @ChaseRequestGroupKeyIdentity = IDENT_CURRENT('[dbo].[ChaseRequestGroup]') -- Get the Identity Column generated

    IF ( @InsertChildHistoryRow != 0 )
	BEGIN

        INSERT INTO [dbo].[ChaseRequestGroupHistory]
                        ([ChaseRequestGroupKey]
                        ,[MacroStatusKey]
                        ,[MicroStatusKey]
						,ClinicalDataOriginKey
						)
            VALUES
                        (
                            @ChaseRequestGroupKeyIdentity
                            , @ChaseRequestGroupHistoryMacroStatusKey
                            , @ChaseRequestGroupHistoryMicroStatusKey
							, @ClinicalDataOriginKey
                            )

	SELECT @ChaseRequestGroupHistoryKeyIdentity = IDENT_CURRENT('[dbo].[ChaseRequestGroupHistory]')

    END

              /* result 1 */
    SELECT  
            alias.[ChaseRequestGroupKey]
            , alias.[ChaseRequestGroupUniqueIdentifier]
            , alias.[InsertDate]
            , alias.[InsertedBy]
            , alias.[LastUpdated]
            , alias.[LastUpdatedBy] 
			, alias.[ClinicalDataOriginKey]
    FROM 
            [ChaseRequestGroup] alias
    WHERE
            alias.[ChaseRequestGroupKey] = @ChaseRequestGroupKeyIdentity

    IF ( @InsertChildHistoryRow != 0 )
	BEGIN
                /* optional result 2 */
                SELECT  
                        alias.[ChaseRequestGroupHistoryKey]
                        , alias.[ChaseRequestGroupKey]
                        , alias.[MacroStatusKey]
                        , alias.[MicroStatusKey]
                        , alias.[InsertDate]
                        , alias.[InsertedBy]
                        , alias.[LastUpdated]
                        , alias.[LastUpdatedBy] 
						, alias.[ClinicalDataOriginKey]
                FROM 
                        dbo.[ChaseRequestGroupHistory] alias
                WHERE
                        alias.ChaseRequestGroupHistoryKey = @ChaseRequestGroupHistoryKeyIdentity
    END


	SET NOCOUNT OFF

END