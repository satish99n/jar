﻿ALTER TABLE [dbo].[Encounter]
	ADD CONSTRAINT [PK_Encounter]
	PRIMARY KEY (EncounterKey)
