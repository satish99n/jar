﻿ALTER TABLE [dbo].[Encounter]
	ADD CONSTRAINT [FK_EncounterToPatient]
	FOREIGN KEY (PatientKey)
	REFERENCES [Patient] (PatientKey)
