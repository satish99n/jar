﻿ALTER TABLE [dbo].[ChaseRequestGroupHistory]
	ADD CONSTRAINT [FK_ChaseRequestGroupHistoryToClinicalDataOrigin]
	FOREIGN KEY (ClinicalDataOriginKey)
	REFERENCES [ClinicalDataOrigin] (ClinicalDataOriginKey)
