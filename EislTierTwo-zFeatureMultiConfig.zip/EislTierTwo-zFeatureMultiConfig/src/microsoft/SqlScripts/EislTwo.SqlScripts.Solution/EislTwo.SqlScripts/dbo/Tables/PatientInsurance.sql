﻿CREATE TABLE [dbo].[PatientInsurance]
(
       [PatientInsuranceKey]			BIGINT              NOT NULL IDENTITY(1, 1)	, -- This will be the primary key
	   [ClinicalDataOriginKey]			INT					NOT NULL				,
       [PatientKey]						BIGINT              NOT NULL				, -- This will be the foreign key to the Encounter table
       [InsuranceIdentifierType]		SMALLINT            NULL					, -- eg ( 1= Primary,2=Secondary,3-Third,4-Fourth etc)
       [InsuranceIdentifier]			VARCHAR(256) NULL							, 
	   [InsertDate]						DATETIME			CONSTRAINT [DF_PatientInsurance_InsertDate]		DEFAULT CURRENT_TIMESTAMP NOT NULL,
       [InsertedBy]						NVARCHAR(64)		CONSTRAINT [DF_PatientInsurance_InsertedBy]		DEFAULT SUSER_SNAME() NOT NULL,
       [LastUpdated]					DATETIME			CONSTRAINT [DF_PatientInsurance_LastUpdated]		DEFAULT CURRENT_TIMESTAMP NOT NULL,
       [LastUpdatedBy]                  NVARCHAR(64)		CONSTRAINT [DF_PatientInsurance_LastUpdatedBy]     DEFAULT SUSER_SNAME() NOT NULL,
	   CONSTRAINT [UC_PatientInsurance_EncounterKey_InsuranceIdentifierType] UNIQUE (PatientKey , InsuranceIdentifierType)
)

