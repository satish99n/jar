﻿CREATE PROCEDURE [dbo].[uspPatientGetSingleByKey]
    @PatientKey BIGINT
AS
BEGIN

	SET NOCOUNT ON

	SELECT  
		alias.[PatientKey]
		, alias.[PatientUniqueIdentifier] 
		, alias.[InsertDate]	
		, alias.[InsertedBy]		
		, alias.[LastUpdated]		
		, alias.[LastUpdatedBy]		
	FROM 
		[Patient] alias
	WHERE
		alias.PatientKey = @PatientKey

	SET NOCOUNT OFF


END