﻿ALTER TABLE [dbo].[Patient]
	ADD CONSTRAINT [FK_PatientToClinicalDataOrigin]
	FOREIGN KEY (ClinicalDataOriginKey)
	REFERENCES [ClinicalDataOrigin] (ClinicalDataOriginKey)
