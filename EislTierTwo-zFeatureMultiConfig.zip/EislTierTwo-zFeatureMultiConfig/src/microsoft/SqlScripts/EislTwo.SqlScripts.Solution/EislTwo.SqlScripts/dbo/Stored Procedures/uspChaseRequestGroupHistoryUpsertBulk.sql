﻿CREATE PROCEDURE [dbo].[uspChaseRequestGroupHistoryUpsertBulk] 
@ParameterXml XML
AS

BEGIN

/*

EXAMPLE USAGE :


EXEC [dbo].[uspChaseRequestGroupHistoryUpsertBulk] '
<root>
<ChaseRequestHistorys>
	<ChaseRequestHistory ChaseRequestHistoryKey="-2" ChaseRequestKey="1" MacroStatusKey="1" MicroStatusKey="1001" ClinicalDataOriginKey="10001"/>
</ChaseRequestHistorys>
</root>
 '
 SELECT * from dbo.ChaseRequestHistory
 SELECT * from dbo.ChaseRequest
 
*/

	SET NOCOUNT ON

	/* values for tcy/catch */
	DECLARE @ErrorNumber							INT,  
			@ErrorSeverity							INT , 
			@ErrorState								INT ,  
			@ErrorProcedure							NVARCHAR(4000) ,  
			@ErrorLine								INT , 
			@ErrorMessage							NVARCHAR(4000)


	/* variables to return all insert/update counts */
	DECLARE 
			@ChaseRequestHistoryInsertCount			INT = 0, 
			@ChaseRequestHistoryUpdateCount			INT = 0

	/********************************************* Table Variable Declaration***********************************/
	
	DECLARE @ChaseRequestHistoryHolder TABLE (
		[XmlInputChaseRequestHistoryKey]			BIGINT	NOT NULL
		, [XmlInputChaseRequestKey]					BIGINT	NOT NULL
		,[ClinicalDataOriginKey]					INT		NOT NULL	
		,[MicroStatusKey]							INT		NOT NULL
		,[MacroStatusKey]							INT		NOT NULL
		,[InsertDate]								DATETIME
		,[InsertedBy]								NVARCHAR(128)
		,[LastUpdated]								DATETIME
		,[LastUpdatedBy]							NVARCHAR(128)
		);

		DECLARE @ChaseRequestHistoryAudit TABLE (
		[ChaseRequestHistoryKey]					BIGINT	NOT NULL
		);
	
	/* shred the ChaseRequestHistory xml */
	INSERT INTO @ChaseRequestHistoryHolder (
		[XmlInputChaseRequestHistoryKey]
		,[XmlInputChaseRequestKey]
		,[ClinicalDataOriginKey]		
		,[MacroStatusKey]
		,[MicroStatusKey]
		,[InsertDate]
		,[InsertedBy]
		,[LastUpdated]
		,[LastUpdatedBy]
		)
	SELECT T.MyEntity.value('@ChaseRequestHistoryKey', 'INT')				AS ChaseRequestHistoryKey
		,T.MyEntity.value('@ChaseRequestKey', 'INT')						AS ChaseRequestKey
		,T.MyEntity.value('@ClinicalDataOriginKey', 'INT')					AS [ClinicalDataOriginKey]
		,T.MyEntity.value('@MacroStatusKey', 'INT')							AS MacroStatusKey
		,T.MyEntity.value('@MicroStatusKey', 'INT')							AS MicroStatusKey
		,T.MyEntity.value('@InsertDate', 'DATETIME')						AS InsertDate
		,T.MyEntity.value('@InsertedBy', 'NVARCHAR(50)')					AS InsertedBy
		,T.MyEntity.value('@LastUpdated', 'DATETIME')						AS LastUpdated
		,T.MyEntity.value('@LastUpdatedBy', 'NVARCHAR(50)')					AS LastUpdatedBy 
	FROM @ParameterXml.nodes('root/ChaseRequestHistorys/ChaseRequestHistory') AS T(MyEntity);


	/* post shred checks */

	BEGIN TRY

		IF EXISTS (	SELECT NULL FROM @ChaseRequestHistoryHolder holder 
					WHERE NOT EXISTS (	SELECT 1 
										FROM  dbo.ChaseRequest parentHolder 
										WHERE parentHolder.ChaseRequestKey = holder.XmlInputChaseRequestKey
										AND   parentHolder.ClinicalDataOriginKey = holder.ClinicalDataOriginKey
										)
				  )
		BEGIN
			;THROW 51000, 'ChaseRequestKey is not valid and doesn''t exist', 1;
		END

		/* Because of the "MAX" trick to write the surrogate keys, start the TRAN here */
		BEGIN TRANSACTION;

	/* ------------------------------- */

		UPDATE	[dbo].[ChaseRequestHistory]
		SET		[MacroStatusKey]  = holder.[MacroStatusKey]
				,[MicroStatusKey] = holder.[MicroStatusKey]
				,[InsertDate]	  = ISNULL(holder.[InsertDate], realTable.InsertDate) /* use the original InsertDate if no InsertDate is specified */
				,[InsertedBy]     = ISNULL(holder.[InsertedBy], realTable.InsertedBy) /* use the original InsertedBy if no InsertedBy is specified */
				,[LastUpdated]    = ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
				,[LastUpdatedBy]  = ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())

		OUTPUT	inserted.[ChaseRequestHistoryKey]
		INTO	@ChaseRequestHistoryAudit([ChaseRequestHistoryKey])

		FROM	@ChaseRequestHistoryHolder holder		INNER JOIN 
				[dbo].[ChaseRequestHistory] realTable
		ON		realTable.ChaseRequestHistoryKey = holder.XmlInputChaseRequestHistoryKey

		SELECT @ChaseRequestHistoryUpdateCount = @@ROWCOUNT


		INSERT INTO [dbo].[ChaseRequestHistory] (
			 --[ChaseRequestHistoryKey]
			[ChaseRequestKey]
			,[MacroStatusKey]
			,[MicroStatusKey]
			,[InsertDate]
			,[InsertedBy]
			,[LastUpdated]
			,[LastUpdatedBy]
			,[ClinicalDataOriginKey]
			)
		OUTPUT	inserted.[ChaseRequestHistoryKey]
		INTO	@ChaseRequestHistoryAudit([ChaseRequestHistoryKey])
		SELECT
			 --holder.[DatabaseValueChaseRequestHistoryKey]
			holder.[XmlInputChaseRequestKey]
			,holder.[MacroStatusKey]
			,holder.[MicroStatusKey]
			,[InsertDate]		= ISNULL(holder.[InsertDate], CURRENT_TIMESTAMP)
			,[InsertedBy]		= ISNULL(holder.[InsertedBy], SUSER_SNAME())
			,[LastUpdated]		= ISNULL(holder.[LastUpdated], CURRENT_TIMESTAMP)
			,[LastUpdatedBy]	= ISNULL(holder.[LastUpdatedBy], SUSER_SNAME())
			,ClinicalDataOriginKey

		FROM @ChaseRequestHistoryHolder holder
		WHERE NOT EXISTS (
							SELECT NULL
							FROM [dbo].[ChaseRequestHistory] realTable
							WHERE realTable.ChaseRequestHistoryKey = XmlInputChaseRequestHistoryKey--holder.DatabaseValueChaseRequestHistoryKey
						);

		SELECT @ChaseRequestHistoryInsertCount = @@ROWCOUNT

		SELECT  
			alias.ChaseRequestHistoryKey
			, alias.ChaseRequestKey
			, alias.MicroStatusKey
			, alias.MicroStatusKey
			, alias.[InsertDate]
			, alias.[InsertedBy]
			, alias.[LastUpdated]
			, alias.[LastUpdatedBy] 
			, alias.ClinicalDataOriginKey
		FROM 
			dbo.[ChaseRequestHistory] alias
			JOIN @ChaseRequestHistoryAudit Holder
			ON alias.ChaseRequestHistoryKey =Holder.[ChaseRequestHistoryKey]


		/* return the update and insert counts.  the dotnet layer could do a data validation */
		SELECT	[ChaseRequestGroupHistoryInsertCount]  = @ChaseRequestHistoryInsertCount
				,[ChaseRequestGroupHistoryUpdateCount] = @ChaseRequestHistoryUpdateCount

	END TRY

	BEGIN CATCH

		SELECT @ErrorNumber = ERROR_NUMBER()
			, @ErrorSeverity = ERROR_SEVERITY()
			, @ErrorState = ERROR_STATE()
			, @ErrorProcedure = ERROR_PROCEDURE()
			, @ErrorLine = ERROR_LINE()
			, @ErrorMessage = ERROR_MESSAGE();


		IF @@TRANCOUNT > 0
		BEGIN
			ROLLBACK TRANSACTION;
		END


		EXEC [logging].[uspSqlErrorInsertSingle] @ErrorNumber , @ErrorSeverity , @ErrorState , @ErrorProcedure , @ErrorLine , @ErrorMessage;


		THROW; /* Bubble the Exception to Calling Layer */
	END CATCH;

	IF @@TRANCOUNT > 0
		COMMIT TRANSACTION;

	SET NOCOUNT OFF

END