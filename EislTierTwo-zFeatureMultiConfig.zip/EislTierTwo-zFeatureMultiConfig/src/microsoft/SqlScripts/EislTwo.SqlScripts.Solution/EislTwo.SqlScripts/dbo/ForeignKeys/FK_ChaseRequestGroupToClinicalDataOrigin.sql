﻿ALTER TABLE [dbo].[ChaseRequestGroup]
	ADD CONSTRAINT [FK_ChaseRequestGroupToClinicalDataOrigin]
	FOREIGN KEY (ClinicalDataOriginKey)
	REFERENCES [ClinicalDataOrigin] (ClinicalDataOriginKey)
