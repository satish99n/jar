﻿ALTER TABLE [dbo].[ChaseRequestHistory]
	ADD CONSTRAINT [PK_ChaseRequestHistory]
	PRIMARY KEY (ChaseRequestHistoryKey)
