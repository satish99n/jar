ALTER TABLE [dbo].[EncounterInsurance] ADD CONSTRAINT PK_EncounterInsurance PRIMARY KEY (EncounterInsuranceKey)
