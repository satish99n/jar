﻿ALTER TABLE	[dbo].[ClinicalDataOrigin]	ADD CONSTRAINT FK_ClinicalDataOriginToEMRSystem FOREIGN KEY(EMRSystemKey) REFERENCES [lookup].EMRSystem(EMRSystemKey)		
