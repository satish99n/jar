ALTER TABLE [dbo].[EncounterInsurance] ADD CONSTRAINT FK_EncounterInsuranceToEncounter FOREIGN KEY (EncounterKey) REFERENCES
[dbo].[Encounter]([EncounterKey])


