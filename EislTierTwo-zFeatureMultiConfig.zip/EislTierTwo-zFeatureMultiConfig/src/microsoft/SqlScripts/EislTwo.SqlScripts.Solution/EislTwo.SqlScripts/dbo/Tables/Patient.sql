﻿CREATE TABLE [dbo].[Patient]
(
	[PatientKey]							BIGINT			NOT NULL IDENTITY(1, 1),
	[ClinicalDataOriginKey]					INT			NOT NULL,
	[PatientUniqueIdentifier]				VARCHAR(256)	NOT NULL, /* NOT PHI, Surrogate Key */
    [InsertDate]							DATETIME        CONSTRAINT [DF_Patient_InsertDate]	DEFAULT CURRENT_TIMESTAMP NOT NULL,
    [InsertedBy]							NVARCHAR(64)    CONSTRAINT [DF_Patient_InsertedBy]	DEFAULT SUSER_SNAME() NOT NULL,
    [LastUpdated]							DATETIME        CONSTRAINT [DF_Patient_LastUpdated]	DEFAULT CURRENT_TIMESTAMP NOT NULL,
    [LastUpdatedBy]							NVARCHAR(64)    CONSTRAINT [DF_Patient_LastUpdatedBy]DEFAULT SUSER_SNAME() NOT NULL,
	CONSTRAINT [UC_Patient_ClinicalDataOriginKey_PatientUniqueIdentifier] UNIQUE (ClinicalDataOriginKey,PatientUniqueIdentifier)
)