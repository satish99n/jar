﻿CREATE TABLE [archive].[ChaseRequestArchive]
(
	[Id] INT NOT NULL PRIMARY KEY
)
