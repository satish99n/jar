﻿/* archive is to keep the "working tables" small */
/* tables in here should "match" the tables they are trying to archive, but probably one extra surrogate key */
/* evenutually the archive tables can be truncated */
CREATE SCHEMA [archive] AUTHORIZATION [dbo]