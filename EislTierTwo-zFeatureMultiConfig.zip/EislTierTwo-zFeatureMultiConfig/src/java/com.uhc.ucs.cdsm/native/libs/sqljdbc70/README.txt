sqljdbc_auth.dll

Integrated Security talking to a Sql Server database


Originally downloaded from:
https://docs.microsoft.com/en-us/sql/connect/jdbc/building-the-connection-url?view=sql-server-2017#Connectingintegrated


Issue:
JDBC ~is~ available from maven as artifact:
		<dependency>
			<groupId>com.microsoft.sqlserver</groupId>
			<artifactId>mssql-jdbc</artifactId>
			<version>7.0.0.jre8</version>
		</dependency>

HOWEVER, sqljdbc_auth.dll (to enable integrated security) IS NOT in the maven artifact.
	This article explains why.
	https://blogs.msdn.microsoft.com/jdbcteam/2016/11/17/open-source-jdbc-maven/
 


JAVA IDE Developer Notes:
	If you are running something like the 

com.uhc.ucs.cdsm.eisltwo.jobprocessingconsoleentry.StartApplication;

You can edit your "Run Configuration", and add this as a VM argument

	-Djava.library.path="..\..\native\libs\sqljdbc70\x64"



URLs:


https://stackoverflow.com/questions/14471150/loading-dll-file-inside-eclipse-java-project/24439984#24439984
https://stackoverflow.com/questions/17277001/dll-missing-in-jdbc/46437516#46437516

