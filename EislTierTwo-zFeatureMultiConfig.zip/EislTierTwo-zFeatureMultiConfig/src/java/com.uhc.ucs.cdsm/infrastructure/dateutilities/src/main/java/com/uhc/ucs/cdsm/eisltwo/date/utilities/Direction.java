package com.uhc.ucs.cdsm.eisltwo.date.utilities;

public enum Direction {

	FORWARD,BACKWARD
}
