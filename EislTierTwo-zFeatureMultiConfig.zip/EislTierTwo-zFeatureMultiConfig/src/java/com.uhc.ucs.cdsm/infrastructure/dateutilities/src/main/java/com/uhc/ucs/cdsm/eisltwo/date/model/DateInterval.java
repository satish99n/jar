package com.uhc.ucs.cdsm.eisltwo.date.model;

import java.time.LocalDate;

public class DateInterval {

	private LocalDate StartRangeDate;
	private LocalDate EndRangeDate;
	
	public DateInterval(LocalDate startRangeDate, LocalDate endRangeDate) {
		super();
		StartRangeDate = startRangeDate;
		EndRangeDate = endRangeDate;
	}

	public LocalDate getStartRangeDate() {
		return StartRangeDate;
	}

	public LocalDate getEndRangeDate() {
		return EndRangeDate;
	}

	@Override
	public String toString() {
		return "DateInterval [StartRangeDate=" + StartRangeDate + ", EndRangeDate=" + EndRangeDate + "]";
	}

	
}
