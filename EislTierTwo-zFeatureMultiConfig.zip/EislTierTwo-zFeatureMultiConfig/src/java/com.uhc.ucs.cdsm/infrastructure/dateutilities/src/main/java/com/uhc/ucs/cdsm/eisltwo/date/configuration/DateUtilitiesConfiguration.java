package com.uhc.ucs.cdsm.eisltwo.date.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.uhc.ucs.cdsm.eisltwo.date.utilities.NextDateGenerator;

@Configuration
@ComponentScan(basePackageClasses= {NextDateGenerator.class})
public class DateUtilitiesConfiguration {

}
