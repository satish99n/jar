package com.uhc.ucs.cdsm.eisltwo.date.utilities;

import java.time.LocalDate;
import java.util.List;

import com.uhc.ucs.cdsm.eisltwo.date.model.DateInterval;

public interface INextDateGenerator {
	/**
	 * 
	 * Gives a date range from triggerDate (inclusive or exclusive based on keepTriggerDate) to triggerDate + numberOfdays <br/>
	 * 
	 * if {@link Direction} is FORWARD triggerDate must be less than cutoff Date else Assertion will fail and result in {@link IllegalArgumentException} <br/>
	 * if {@link Direction} is BACKWARD triggerDate must be greater than cutoff Date else Assertion will fail and result in {@link IllegalArgumentException}
	 * 
	 * @param triggerDate -- Seed Date
	 * @param keepTriggerDate -- inclusive or exclusive based on keepTriggerDate
	 * @param cutOffDate -- Date Limit than be reached from triggerDate
	 * @param numberOfDays -- Gap between the date Interval generated (system only considers the abs value)
	 * @param direction --  {@link Direction} is FORWARD, BACKWARD
	 * @return start date and end Date wrapped in  {@link DateInterval} Pojo 
	 */
	DateInterval generateSingle(LocalDate  triggerDate, 
			boolean keepTriggerDate,
			LocalDate cutOffDate,
			int numberOfDays,
			Direction direction);
	
	/**
	 * 
	 * Gives a List of all date range from triggerDate (inclusive or exclusive based on keepTriggerDate) to triggerDate + numberOfdays <br/>
	 * 
	 * if {@link Direction} is FORWARD triggerDate must be less than cutoff Date else Assertion will fail and result in {@link IllegalArgumentException} <br/>
	 * if {@link Direction} is BACKWARD triggerDate must be greater than cutoff Date else Assertion will fail and result in {@link IllegalArgumentException}
	 * 
	 * @param triggerDate -- Seed Date
	 * @param keepTriggerDate -- inclusive or exclusive based on keepTriggerDate
	 * @param cutOffDate -- Date Limit than be reached from triggerDate
	 * @param numberOfDays -- Gap between the date Interval generated (system only considers the abs value)
	 * @param direction --  {@link Direction} is FORWARD, BACKWARD
	 * 
	 * @return List of  {@link DateInterval} Pojo wrapping start date and end Date
	 */
	List<DateInterval> generateRange(LocalDate  triggerDate, 
			boolean keepTriggerDate,
			LocalDate cutOffDate,
			int numberOfDays,
			Direction direction);

	
	/**
	 * 
	 * Gives a date range from triggerDate (inclusive or exclusive based on keepTriggerDate) to triggerDate + numberOfdays <br/>
	 * 
	 * if {@link Direction} is FORWARD triggerDate must be less than cutoff Date else Assertion will fail and result in {@link IllegalArgumentException} <br/>
	 * if {@link Direction} is BACKWARD triggerDate must be greater than cutoff Date else Assertion will fail and result in {@link IllegalArgumentException}
	 * 
	 * @param triggerDate -- Seed Date
	 * @param keepTriggerDate -- inclusive or exclusive based on keepTriggerDate
	 * @param cutOffDate -- Date Limit than be reached from triggerDate
	 * @param numberOfDays -- Gap between the date Interval generated (system only considers the abs value)
	 * @param direction --  {@link Direction} is FORWARD, BACKWARD
	 * @return start date and end Date wrapped in  {@link DateInterval} Pojo 
	 */
	
	List<DateInterval> generateRange(LocalDate  triggerDate, 
			boolean keepTriggerDate,
			LocalDate cutOffDate,
			int numberOfDays,
			Direction direction, int limit);
	
}
