package com.uhc.ucs.cdsm.eisltwo.date.utilities;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uhc.ucs.cdsm.eisltwo.date.configuration.DateUtilitiesConfiguration;
import com.uhc.ucs.cdsm.eisltwo.date.model.DateInterval;



@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes= {DateUtilitiesConfiguration.class})
public class NextDateGeneratorTest{
	
	
	@Autowired
	private INextDateGenerator nextDateGenerator;
	
	private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	
	@Test
	public void testSingleDateIntervalForwardKeepTriggerDate() {
		LocalDate triggerDate = LocalDate.parse("2018-09-25", formatter);
		LocalDate cutOffDate = LocalDate.parse("2018-09-30", formatter);
		boolean keepTriggerDate = true;
		int numberOfDays =3;
		Direction direction = Direction.FORWARD;
		DateInterval dateInterval = nextDateGenerator.generateSingle(triggerDate, keepTriggerDate, cutOffDate, numberOfDays, direction);
		Assert.assertEquals(dateInterval.getStartRangeDate(),triggerDate);
		Assert.assertEquals(dateInterval.getEndRangeDate(), LocalDate.parse("2018-09-27", formatter));
	}
	
	@Test
	public void testSingleDateIntervalForwardKeepTriggerDateWithPassedCutOffDate() {
		LocalDate triggerDate = LocalDate.parse("2018-09-25", formatter);
		LocalDate cutOffDate = LocalDate.parse("2018-09-26", formatter);
		boolean keepTriggerDate = true;
		int numberOfDays =3;
		Direction direction = Direction.FORWARD;
		DateInterval dateInterval = nextDateGenerator.generateSingle(triggerDate, keepTriggerDate, cutOffDate, numberOfDays, direction);
		Assert.assertEquals(dateInterval.getStartRangeDate(), triggerDate);
		Assert.assertEquals(dateInterval.getEndRangeDate(), cutOffDate);
	}
	
	
	@Test
	public void testSingleDateIntervalForwardNotKeepTriggerDate() {
		LocalDate triggerDate = LocalDate.parse("2018-09-25", formatter);
		LocalDate cutOffDate = LocalDate.parse("2018-09-30", formatter);
		boolean keepTriggerDate = false;
		int numberOfDays =3;
		Direction direction = Direction.FORWARD;
		DateInterval dateInterval = nextDateGenerator.generateSingle(triggerDate, keepTriggerDate, cutOffDate, numberOfDays, direction);
		Assert.assertEquals(dateInterval.getStartRangeDate(), triggerDate.plusDays(1));
		Assert.assertEquals(dateInterval.getEndRangeDate(), LocalDate.parse("2018-09-28", formatter));
	}
	
	@Test
	public void testSingleDateIntervalForwardNotKeepTriggerDateWithPassedCutOffDate() {
		LocalDate triggerDate = LocalDate.parse("2018-09-25", formatter);
		LocalDate cutOffDate = LocalDate.parse("2018-09-27", formatter);
		boolean keepTriggerDate = false;
		int numberOfDays =3;
		Direction direction = Direction.FORWARD;
		DateInterval dateInterval = nextDateGenerator.generateSingle(triggerDate, keepTriggerDate, cutOffDate, numberOfDays, direction);
		Assert.assertEquals(dateInterval.getStartRangeDate(), triggerDate.plusDays(1));
		Assert.assertEquals(dateInterval.getEndRangeDate(), cutOffDate);
	}
	
	@Test
	public void testSingleDateIntervalBackwardKeepTriggerDate() {
		LocalDate triggerDate = LocalDate.parse("2018-09-30", formatter);
		LocalDate cutOffDate = 	LocalDate.parse("2018-09-25", formatter);
		boolean keepTriggerDate = true;
		int numberOfDays =3;
		Direction direction = Direction.BACKWARD;
		DateInterval dateInterval = nextDateGenerator.generateSingle(triggerDate, keepTriggerDate, cutOffDate, numberOfDays, direction);
		Assert.assertEquals(dateInterval.getStartRangeDate(), LocalDate.parse("2018-09-28", formatter));
		Assert.assertEquals(dateInterval.getEndRangeDate(), triggerDate);
	}
	
	@Test
	public void testSingleDateIntervalBackwardKeepTriggerDateWithPassedCutOffDate() {
		LocalDate triggerDate = LocalDate.parse("2018-09-30", formatter);
		LocalDate cutOffDate = LocalDate.parse("2018-09-29", formatter);
		boolean keepTriggerDate = true;
		int numberOfDays =3;
		Direction direction = Direction.BACKWARD;
		DateInterval dateInterval = nextDateGenerator.generateSingle(triggerDate, keepTriggerDate, cutOffDate, numberOfDays, direction);
		Assert.assertEquals(dateInterval.getStartRangeDate(),cutOffDate);
		Assert.assertEquals(dateInterval.getEndRangeDate(), triggerDate);
	}
	
	
	@Test
	public void testSingleDateIntervalBackwardNotKeepTriggerDate() {
		LocalDate triggerDate = LocalDate.parse("2018-09-30", formatter);
		LocalDate cutOffDate = 	LocalDate.parse("2018-09-25", formatter);
		boolean keepTriggerDate = false;
		int numberOfDays =3;
		Direction direction = Direction.BACKWARD;
		DateInterval dateInterval = nextDateGenerator.generateSingle(triggerDate, keepTriggerDate, cutOffDate, numberOfDays, direction);
		Assert.assertEquals(dateInterval.getStartRangeDate(),LocalDate.parse("2018-09-27", formatter));
		Assert.assertEquals(dateInterval.getEndRangeDate(), triggerDate.minusDays(1));
	}
	
	@Test
	public void testSingleDateIntervalBackwardNotKeepTriggerDateWithPassedCutOffDate() {
		LocalDate triggerDate = LocalDate.parse("2018-09-30", formatter);
		LocalDate cutOffDate = 	LocalDate.parse("2018-09-27", formatter);
		boolean keepTriggerDate = false;
		int numberOfDays =3;
		Direction direction = Direction.BACKWARD;
		DateInterval dateInterval = nextDateGenerator.generateSingle(triggerDate, keepTriggerDate, cutOffDate, numberOfDays, direction);
		Assert.assertEquals(dateInterval.getStartRangeDate(), cutOffDate);
		Assert.assertEquals(dateInterval.getEndRangeDate(), triggerDate.minusDays(1));
	}
	
	@Test
	public void testRangeDateIntervalForward() {
		LocalDate triggerDate = LocalDate.parse("2018-10-01", formatter);
		LocalDate cutOffDate = 	LocalDate.parse("2018-10-30", formatter);
		boolean keepTriggerDate = true;
		int numberOfDays =7;
		Direction direction = Direction.FORWARD;
		List<DateInterval> dateIntervals = nextDateGenerator.generateRange(triggerDate, keepTriggerDate, cutOffDate, numberOfDays, direction);
		Assert.assertEquals(dateIntervals.size(), 5);
	}
	
	@Test
	public void testRangeDateIntervalBackward() {
		LocalDate triggerDate = LocalDate.parse("2018-10-30", formatter);
		LocalDate cutOffDate = 	LocalDate.parse("2018-10-01", formatter);
		boolean keepTriggerDate = true;
		int numberOfDays =7;
		Direction direction = Direction.BACKWARD;
		List<DateInterval> dateIntervals = nextDateGenerator.generateRange(triggerDate, keepTriggerDate, cutOffDate, numberOfDays, direction);
		Assert.assertEquals(dateIntervals.size(), 5);
	}
	
	@Test
	public void testRangeDateIntervalForwardLimit() {
		LocalDate triggerDate = LocalDate.parse("2018-10-01", formatter);
		LocalDate cutOffDate = 	LocalDate.parse("2018-10-30", formatter);
		boolean keepTriggerDate = true;
		int numberOfDays =7;
		Direction direction = Direction.FORWARD;
		List<DateInterval> dateIntervals = nextDateGenerator.generateRange(triggerDate, keepTriggerDate, cutOffDate, numberOfDays, direction,3);
		Assert.assertEquals(dateIntervals.size(), 3);
	}
	
	@Test
	public void testRangeDateIntervalBackwardLimit() {
		LocalDate triggerDate = LocalDate.parse("2018-10-30", formatter);
		LocalDate cutOffDate = 	LocalDate.parse("2018-10-01", formatter);
		boolean keepTriggerDate = true;
		int numberOfDays =7;
		Direction direction = Direction.BACKWARD;
		List<DateInterval> dateIntervals = nextDateGenerator.generateRange(triggerDate, keepTriggerDate, cutOffDate, numberOfDays, direction,3);
		Assert.assertEquals(dateIntervals.size(), 5);
	}

}
