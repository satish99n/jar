package com.uhc.ucs.cdsm.eisltwo.date.utilities;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import com.uhc.ucs.cdsm.eisltwo.date.model.DateInterval;

@Component
public class NextDateGenerator implements INextDateGenerator{

	@Override
	public DateInterval generateSingle(LocalDate triggerDate, boolean keepTriggerDate, LocalDate cutOffDate,
			int numberOfDays, Direction direction) {
		
		numberOfDays = Math.abs(numberOfDays);
		if(direction==Direction.FORWARD) {
			return getDatePeriodForward(triggerDate, keepTriggerDate, cutOffDate, numberOfDays);
		}
		
		if(direction==Direction.BACKWARD) {
			return getDatePeriodBackward(triggerDate, keepTriggerDate, cutOffDate, numberOfDays);
		}
		
		throw new IllegalArgumentException("Invalid Direction");
	}

	@Override
	public List<DateInterval> generateRange(LocalDate triggerDate, boolean keepTriggerDate, LocalDate cutOffDate,
			int numberOfDays, Direction direction) {
		return generateRange(triggerDate, keepTriggerDate, cutOffDate, numberOfDays, direction, Integer.MAX_VALUE);
	}

	@Override
	public List<DateInterval> generateRange(LocalDate triggerDate, boolean keepTriggerDate, LocalDate cutOffDate,
			int numberOfDays, Direction direction, int limit) {
		List<DateInterval> dateIntervals = new LinkedList<>();
		if(direction==Direction.FORWARD) {
			while(triggerDate.compareTo(cutOffDate)<0 && limit>0) {
				DateInterval dateInterval = getDatePeriodForward(triggerDate, keepTriggerDate, cutOffDate, numberOfDays);
				dateIntervals.add(dateInterval);
				triggerDate = dateInterval.getEndRangeDate();
				keepTriggerDate=false;
				limit--;
			}
		}
		if(direction==Direction.BACKWARD) {
			while(triggerDate.compareTo(cutOffDate)>0) {
				DateInterval dateInterval = getDatePeriodBackward(triggerDate, keepTriggerDate, cutOffDate, numberOfDays);
				dateIntervals.add(dateInterval);
				triggerDate = dateInterval.getStartRangeDate();
				keepTriggerDate=false;
				limit--;
			}
		}
		return dateIntervals;
	}
	
	private DateInterval getDatePeriodBackward(LocalDate triggerDate, boolean keepTriggerDate,
			LocalDate cutOffDate, int numberOfDays) {
		LocalDate endDate = keepTriggerDate?triggerDate:triggerDate.minusDays(1);
		Assert.isTrue(endDate.compareTo(cutOffDate)>=0, "triggerDate cannot be less than equal to cutOffDate if moving backward in time");
		LocalDate startDate = endDate.minusDays(numberOfDays-1);
		if(startDate.compareTo(cutOffDate)<0) {
			startDate = cutOffDate;
		}
		return new DateInterval(startDate, endDate);
	}

	private DateInterval getDatePeriodForward(LocalDate triggerDate, boolean keepTriggerDate,
			LocalDate cutOffDate, int numberOfDays) {
		LocalDate startDate = keepTriggerDate?triggerDate:triggerDate.plusDays(1);
		Assert.isTrue(startDate.compareTo(cutOffDate)<=0, "triggerDate cannot be greater than equal to cutOffDate if moving forward in time");
		
		LocalDate endDate = startDate.plusDays(numberOfDays-1);
		if(endDate.compareTo(cutOffDate)>0) {
			endDate = cutOffDate;
		}
		return new DateInterval(startDate, endDate);
	}


}
