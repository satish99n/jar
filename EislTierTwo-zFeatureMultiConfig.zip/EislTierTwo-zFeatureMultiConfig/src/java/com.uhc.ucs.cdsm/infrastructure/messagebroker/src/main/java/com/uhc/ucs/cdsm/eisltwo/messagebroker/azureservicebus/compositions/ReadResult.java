package com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.compositions;

public class ReadResult<T> {

	public ReadResult() {
		this.successfulItems = new java.util.ArrayList<T>();
	}

	java.util.Collection<T> successfulItems;

	public java.util.Collection<T> getSuccessfulItems() {
		return successfulItems;
	}

	public void setSuccessfulItems(java.util.Collection<T> successfulItems) {
		this.successfulItems = successfulItems;
	}

}
