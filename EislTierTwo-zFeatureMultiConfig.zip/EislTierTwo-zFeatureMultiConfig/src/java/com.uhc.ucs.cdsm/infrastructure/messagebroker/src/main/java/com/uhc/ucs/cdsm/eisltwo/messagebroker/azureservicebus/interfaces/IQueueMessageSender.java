package com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.interfaces;

import com.microsoft.windowsazure.exception.ServiceException;

public interface IQueueMessageSender<T> {
	public void sendMessage(String connectionString, String queueName, String payload) throws ServiceException;
}
