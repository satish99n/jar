package com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus;

import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.arguments.QueueMessageReadArgs;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.compositions.ReadResult;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.interfaces.IQueueMessageReader;

import com.microsoft.windowsazure.Configuration;
import com.microsoft.windowsazure.services.servicebus.ServiceBusConfiguration;
import com.microsoft.windowsazure.services.servicebus.ServiceBusContract;
import com.microsoft.windowsazure.services.servicebus.ServiceBusService;
import com.microsoft.windowsazure.services.servicebus.models.BrokeredMessage;
import com.microsoft.windowsazure.services.servicebus.models.ReceiveMessageOptions;
import com.microsoft.windowsazure.services.servicebus.models.ReceiveMode;
import com.microsoft.windowsazure.services.servicebus.models.ReceiveQueueMessageResult;

import org.apache.commons.logging.Log;

//Include the following imports to use Service Bus APIs
import java.util.function.Function;
import javax.xml.datatype.*;

public class QueueMessageReader implements IQueueMessageReader<String> {

	private final Log logger;

	public QueueMessageReader(Log lgr) {

		if (null == lgr) {
			throw new IllegalArgumentException("Log is null");
		}

		this.logger = lgr;
	}

	public ReadResult<String> readMessage(QueueMessageReadArgs args,
			Function<BrokeredMessage, BrokeredMessage> handleMessageFunction) throws Exception {

		ReadResult<String> returnItem = new ReadResult<String>();

		try {
			Configuration config = new Configuration();
			ServiceBusConfiguration.configureWithConnectionString(null, config, args.getConnectionString());
			ServiceBusContract service = ServiceBusService.create(config);
			ReceiveMessageOptions opts = ReceiveMessageOptions.DEFAULT;
			opts.setReceiveMode(ReceiveMode.PEEK_LOCK);
			int defaultTimeout = 0;
			if (null != opts.getTimeout()) {
				defaultTimeout = opts.getTimeout();
			}
			opts.setTimeout(40); /* in seconds */

			while (true) {

				/*
				 * THESE NEXT TWO CALLS ARE COMING BACK NULL, EVEN WITH MESSAGES STILL ON QUEUE.
				 * These are currently unreliable
				 */
				ReceiveQueueMessageResult resultQM = service.receiveQueueMessage(args.getQueueName(), opts);
				BrokeredMessage message = resultQM.getValue();

				if (null == resultQM || null == message) {
					break;
				}

				if (message != null && message.getMessageId() != null) {
					try {

						this.logger.debug(String.format("About to call handleMessageFunction for the message. (%s)",
								message.getMessageId()));
						BrokeredMessage returnValue = handleMessageFunction.apply(message);
						// Remove message from queue
						this.logger.debug(String.format(
								"About to delete the message because handleMessageFunction ran successfully. (%s)",
								message.getMessageId()));
						service.deleteMessage(message);
						this.logger.debug(String.format(
								"Deleted the message because handleMessageFunction ran successfully. (%s)",
								message.getMessageId()));

						returnItem.getSuccessfulItems().add(returnValue.getMessageId());

					} catch (Exception ex) {
						this.logger.error("Unlockeding the Message because of exception", ex);
						service.unlockMessage(message);
						throw ex;
					}
				}
			}
		} catch (Exception ex) {
			this.logger.error(ex.getMessage(), ex);
			throw ex;
		}

		return returnItem;
	}
}