package com.uhc.ucs.cdsm.eisltwo.infrastructure.cachelibrary;

import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import com.uhc.ucs.cdsm.eisltwo.infrastructure.cachelibrary.interfaces.IGenericCacheAside;

import net.jodah.expiringmap.ExpirationPolicy;
import net.jodah.expiringmap.ExpiringMap;

public class ExpiringMapGenericCacheAside<TEntity> implements IGenericCacheAside<TEntity> {

	public final String CacheKeyPrefix = "GenericCacheAsidePrefix";

	private volatile ExpiringMap<String, TEntity> theCache = ExpiringMap.builder().variableExpiration().build(); /*
																	 * static (for thread safety) not allowed for TEntity :(
																	 * https://docs.oracle.com/javase/tutorial/java/generics/erasure.html
																	 */

	public TEntity GetCacheAsideItem(String uniqueIdentifier, long itemDuration, TimeUnit itemTu,
			final Supplier<TEntity> valueFactory) {
		String cacheKey = this.GetFullCacheKey(uniqueIdentifier);
		TEntity cachedOrFreshItem = this.GetFromCache(cacheKey, itemDuration, itemTu, valueFactory);
		return cachedOrFreshItem;
	}

	public TEntity RemoveCacheAsideItem(String uniqueIdentifier) {
		TEntity removedItem = null;
		String cacheKey = this.GetFullCacheKey(uniqueIdentifier);
		if (this.theCache.containsKey(uniqueIdentifier)) {
			removedItem = this.theCache.remove(cacheKey);
		}

		return removedItem;
	}
	
	public void ClearAll()
	{
		this.theCache.clear();
	}

	private TEntity GetFromCache(String cacheKey, long itemDuration, TimeUnit itemTu,
			final Supplier<TEntity> valueFactory) {

		TEntity cachedOrFreshItem = theCache.get(cacheKey);
		if (cachedOrFreshItem == null) {
			cachedOrFreshItem = valueFactory.get();
			theCache.put(cacheKey, cachedOrFreshItem, ExpirationPolicy.CREATED, itemDuration, itemTu);
		}

		return cachedOrFreshItem;
	}

	private String GetFullCacheKey(String uniqueIdentifier) {
		String returnValue = CacheKeyPrefix + uniqueIdentifier;
		return returnValue;
	}
}
