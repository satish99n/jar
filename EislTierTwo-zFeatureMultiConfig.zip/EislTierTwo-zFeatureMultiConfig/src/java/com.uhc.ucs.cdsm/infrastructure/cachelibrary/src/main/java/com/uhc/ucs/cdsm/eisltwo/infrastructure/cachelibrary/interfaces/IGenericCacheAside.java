package com.uhc.ucs.cdsm.eisltwo.infrastructure.cachelibrary.interfaces;

import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

public interface IGenericCacheAside<TEntity extends Object> {
	TEntity GetCacheAsideItem(String uniqueIdentifier, long itemDuration, TimeUnit itemTu, final Supplier<TEntity> valueFactory);
	
	TEntity RemoveCacheAsideItem(String uniqueIdentifier);
	
	void ClearAll();
}
