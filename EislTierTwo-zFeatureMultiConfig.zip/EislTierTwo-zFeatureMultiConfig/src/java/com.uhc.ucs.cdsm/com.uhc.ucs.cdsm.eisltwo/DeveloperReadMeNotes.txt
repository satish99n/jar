
Things to be done to get the dev environment working.


========================================================
========================================================

In the file:

\src\java\com.uhc.ucs.cdsm\com.uhc.ucs.cdsm.eisltwo\pom.xml

FIND THIS:

<!-- comment resources while running application from eclipse -->
<resources>
	<resource>
		<directory>src/main/resources</directory>
		<excludes>
			<exclude>**/*.properties</exclude>
			<exclude>**/*.xml</exclude>
		</excludes>
	</resource>
</resources>

AND COMMENT OUT LIKE THIS:

		<!-- comment resources while running application from eclipse -->
		<!-- 
		<resources>
			<resource>
				<directory>src/main/resources</directory>
				<excludes>
					<exclude>**/*.properties</exclude>
					<exclude>**/*.xml</exclude>
				</excludes>
			</resource>
		</resources>
		-->



========================================================
========================================================

Sql-Server "Integrated Security" Notes:

Full explanation:  \src\java\com.uhc.ucs.cdsm\native\libs\sqljdbc70\README.txt

Developer Setup

These files are checked in to github.

\src\java\com.uhc.ucs.cdsm\native\libs\sqljdbc70\x86\sqljdbc_auth.dll
\src\java\com.uhc.ucs.cdsm\native\libs\sqljdbc70\x64\sqljdbc_auth.dll


To get eclipse to work.
Edit a �Run Configuration�.
Add the below as a VM argument
-Djava.library.path="..\..\native\libs\sqljdbc70\x64"

This will allow sqljdbc_auth.dll to be found so that integrated security will work.

========================================================
========================================================

To resolve the long file path issue,
Add the below two lines in .gitconfig file. This file will be available in C:\Users\<<msid>> path.

[core]
  longpaths = true

========================================================
========================================================