package com.uhc.ucs.cdsm.eisltwo.exportservices.interfaces;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
