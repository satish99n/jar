package com.uhc.ucs.cdsm.eisltwo.exportservices.models;

import java.util.Collection;
import java.util.Date;

import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;

public class DocumentDetailsWrapper {
    private String encounterID;
    private String patientFullName;
    private Date documentCreationTime;
    private byte[] document;
    private Collection<ClinicalDataOriginSetting> originSettings;

    public Collection<ClinicalDataOriginSetting> getOriginSettings() {
        return originSettings;
    }

    public void setOriginSettings(Collection<ClinicalDataOriginSetting> originSettings) {
        this.originSettings = originSettings;
    }

    public byte[] getDocument() {
        return document;
    }

    public void setDocument(byte[] document) {
        this.document = document;
    }

    public String getEncounterID() {
        return encounterID;
    }

    public void setEncounterID(String encounterID) {
        this.encounterID = encounterID;
    }

    public String getPatientFullName() {
        return patientFullName;
    }

    public void setPatientFullName(String patientFullName) {
        this.patientFullName = patientFullName;
    }

    public Date getDocumentCreationTime() {
        return documentCreationTime;
    }

    public void setDocumentCreationTime(Date documentCreationTime) {
        this.documentCreationTime = documentCreationTime;
    }

}
