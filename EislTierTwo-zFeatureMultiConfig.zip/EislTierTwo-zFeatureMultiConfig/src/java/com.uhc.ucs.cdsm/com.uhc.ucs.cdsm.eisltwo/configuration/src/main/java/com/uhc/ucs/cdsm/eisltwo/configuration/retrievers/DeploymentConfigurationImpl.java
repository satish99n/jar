package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers;

import org.springframework.beans.factory.annotation.Value;

import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.IDeploymentConfiguration;

public class DeploymentConfigurationImpl implements IDeploymentConfiguration {

    @Value("${deployment.instance.uuid}")
    private String deploymentInstanceUUID;

    @Override
    public String getDeploymentInstanceUUID() {
        return deploymentInstanceUUID;
    }

    public void setDeploymentInstanceUUID(String deploymentInstanceUUID) {
        this.deploymentInstanceUUID = deploymentInstanceUUID;
    }

}
