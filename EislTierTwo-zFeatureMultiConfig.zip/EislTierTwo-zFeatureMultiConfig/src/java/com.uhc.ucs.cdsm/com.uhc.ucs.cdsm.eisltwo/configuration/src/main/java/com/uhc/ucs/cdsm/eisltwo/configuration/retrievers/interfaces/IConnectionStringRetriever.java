package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces;

public interface IConnectionStringRetriever {
	public String retrievePrimaryDatabaseConnectionString();
	
	public String retrieveMessageBrokerListenConnectionString();
	
	public String retrieveMessageBrokerSendConnectionString();
}
