package com.uhc.ucs.cdsm.eisltwo.configuration.consts;

public class EnvironmentVariableNameConstants {
	public static final String PrimaryDatabaseConnectionString = new String("PrimaryDatabaseConnectionString");
	public static final String MessageBrokerListenConnectionString = new String("MessageBrokerListenConnectionString");
	
	public static final String MessageBrokerSendConnectionString = new String("MessageBrokerSendConnectionString");
	
	public static final String JobProcessingBetweenRunsSleepMilliseconds = new String("JobProcessingBetweenRunsSleepMilliseconds");
}