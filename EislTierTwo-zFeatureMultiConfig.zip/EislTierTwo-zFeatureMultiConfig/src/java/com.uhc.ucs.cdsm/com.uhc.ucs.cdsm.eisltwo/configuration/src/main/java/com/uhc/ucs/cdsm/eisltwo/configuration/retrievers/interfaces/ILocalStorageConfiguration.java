package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces;

public interface ILocalStorageConfiguration {

    public String getLocalStoragePath();
}
