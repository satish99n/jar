package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;

import com.uhc.ucs.cdsm.domain.dictionaries.ClinicalDataOriginSettingTypeDictionary;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;
import com.uhc.ucs.cdsm.eisltwo.configuration.originsettingstoconfiguration.ConfigurationUtil;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;

public class ConfigurationUtilTest {


    @Test
    public void createTWConfigurtionTest() {
        Collection<ClinicalDataOriginSetting> originSettings = getOriginSettings();
        ITWConfiguration twconfigurationReturned = ConfigurationUtil.createTWConfigurtion(originSettings);
        assertNotNull(twconfigurationReturned);
        assertNotEquals("a",twconfigurationReturned.getApiEndpoint());
    }

    @Test
    public void createTWConfigurationTestifNull() {
         ITWConfiguration twconfigurationReturned = ConfigurationUtil.createTWConfigurtion(null);
         assertNull(twconfigurationReturned.getApiEndpoint());
    }

    private Collection<ClinicalDataOriginSetting> getOriginSettings() {
        Collection<ClinicalDataOriginSetting> originSettings = new ArrayList<ClinicalDataOriginSetting>();

        ClinicalDataOriginSetting fhirEndpoint = new ClinicalDataOriginSetting();
        fhirEndpoint.setClinicalDataOriginSettingKeyName(ClinicalDataOriginSettingTypeDictionary.UnityProgramFhirEndpoint.getClinicalDataOriginSettingTypeName());
        fhirEndpoint.setClinicalDataOriginSettingKeyValue("test");
        fhirEndpoint.setClinicalDataOriginSettingTypeKey((short)201);
        originSettings.add(fhirEndpoint);

        ClinicalDataOriginSetting unityEndpoint = new ClinicalDataOriginSetting();
        unityEndpoint.setClinicalDataOriginSettingKeyName(ClinicalDataOriginSettingTypeDictionary.UnityProgramUnityEndpoint.getClinicalDataOriginSettingTypeName());
        unityEndpoint.setClinicalDataOriginSettingKeyValue("test");
        unityEndpoint.setClinicalDataOriginSettingTypeKey((short)202);
        originSettings.add(unityEndpoint);

        ClinicalDataOriginSetting unityUser = new ClinicalDataOriginSetting();
        unityUser.setClinicalDataOriginSettingKeyName(ClinicalDataOriginSettingTypeDictionary.UnityProgramUnityUser.getClinicalDataOriginSettingTypeName());
        unityUser.setClinicalDataOriginSettingKeyValue("test");
        unityUser.setClinicalDataOriginSettingTypeKey((short)203);
        originSettings.add(unityUser);

        ClinicalDataOriginSetting unityPassword = new ClinicalDataOriginSetting();
        unityPassword.setClinicalDataOriginSettingKeyName(ClinicalDataOriginSettingTypeDictionary.UnityProgramUnityPassword.getClinicalDataOriginSettingTypeName());
        unityPassword.setClinicalDataOriginSettingKeyValue("test");
        unityPassword.setClinicalDataOriginSettingTypeKey((short)204);
        originSettings.add(unityPassword);

        ClinicalDataOriginSetting svcUser = new ClinicalDataOriginSetting();
        svcUser.setClinicalDataOriginSettingKeyName(ClinicalDataOriginSettingTypeDictionary.UnityProgramSvcUser.getClinicalDataOriginSettingTypeName());
        svcUser.setClinicalDataOriginSettingKeyValue("test");
        svcUser.setClinicalDataOriginSettingTypeKey((short)205);
        originSettings.add(svcUser);

        ClinicalDataOriginSetting svcPassword = new ClinicalDataOriginSetting();
        svcPassword.setClinicalDataOriginSettingKeyName(ClinicalDataOriginSettingTypeDictionary.UnityProgramSvcPassword.getClinicalDataOriginSettingTypeName());
        svcPassword.setClinicalDataOriginSettingKeyValue("test");
        svcPassword.setClinicalDataOriginSettingTypeKey((short)206);
        originSettings.add(svcPassword);

        ClinicalDataOriginSetting unityAppname = new ClinicalDataOriginSetting();
        unityAppname.setClinicalDataOriginSettingKeyName(ClinicalDataOriginSettingTypeDictionary.UnityProgramUnityAppname.getClinicalDataOriginSettingTypeName());
        unityAppname.setClinicalDataOriginSettingKeyValue("test");
        unityAppname.setClinicalDataOriginSettingTypeKey((short)207);
        originSettings.add(unityAppname);

        ClinicalDataOriginSetting providerGroupID = new ClinicalDataOriginSetting();
        providerGroupID.setClinicalDataOriginSettingKeyName(ClinicalDataOriginSettingTypeDictionary.ProviderGroupId.getClinicalDataOriginSettingTypeName());
        providerGroupID.setClinicalDataOriginSettingKeyValue("test");
        providerGroupID.setClinicalDataOriginSettingTypeKey((short)111);
        originSettings.add(providerGroupID);

        ClinicalDataOriginSetting emrStandardCode = new ClinicalDataOriginSetting();
        emrStandardCode.setClinicalDataOriginSettingKeyName(ClinicalDataOriginSettingTypeDictionary.EmrStandardCode.getClinicalDataOriginSettingTypeName());
        emrStandardCode.setClinicalDataOriginSettingKeyValue("test");
        emrStandardCode.setClinicalDataOriginSettingTypeKey((short)122);
        originSettings.add(emrStandardCode);

        ClinicalDataOriginSetting transportProtocol = new ClinicalDataOriginSetting();
        transportProtocol.setClinicalDataOriginSettingKeyName(ClinicalDataOriginSettingTypeDictionary.TransportProtocol.getClinicalDataOriginSettingTypeName());
        transportProtocol.setClinicalDataOriginSettingKeyValue("test");
        transportProtocol.setClinicalDataOriginSettingTypeKey((short)133);
        originSettings.add(transportProtocol);

        return originSettings;

    }
}
