package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.eisltwo.configuration.consts.EnvironmentVariableNameConstants;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.IConnectionStringRetriever;

public class ConnectionStringRetrieverNoEncryption implements IConnectionStringRetriever {


    private final Log logger;
	private Properties props = new Properties();
	private String propertyFilePath = "connectionNoEncryption.properties";
	
	public ConnectionStringRetrieverNoEncryption(Log lgr) throws IOException {

		if (null == lgr) {
			throw new IllegalArgumentException("Log is null");
		}

		this.logger = lgr;
		loadProperties();
	}
	
	public ConnectionStringRetrieverNoEncryption() throws IOException {
		this.logger = LogFactory.getLog(ConnectionStringRetrieverNoEncryption.class);
		loadProperties();
	}
	
	public void loadProperties() throws IOException {
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		try(InputStream resourceStream = loader.getResourceAsStream(propertyFilePath)) {
		    props.load(resourceStream);
		}
	}

	public String retrievePrimaryDatabaseConnectionString() {
		String returnValue = props.getProperty(EnvironmentVariableNameConstants.PrimaryDatabaseConnectionString);
		return returnValue;
	}

	public String retrieveMessageBrokerListenConnectionString() {
		String returnValue = props.getProperty(EnvironmentVariableNameConstants.MessageBrokerListenConnectionString);
		return returnValue;
	}

	public String retrieveMessageBrokerSendConnectionString() {
		String returnValue = props.getProperty(EnvironmentVariableNameConstants.MessageBrokerSendConnectionString);
		return returnValue;
	}
}
