package com.uhc.ucs.cdsm.eisltwo.configuration.originsettingstoconfiguration;

import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;

public class TWConfigurationImpl implements ITWConfiguration {

    private String apiEndpoint;
    private String tWUnityEndpoint;
    private String tWUnityUser;
    private String tWUnityPassword;
    private String tWUnitySvcUser;
    private String tWUnitySvcPassword;
    private String tWUnityAppname;
    private String providerGroupId;
    private String emrStandardCode;
    private String transportProtocol;
    private int clinicalDataOriginKey;

    @Override
    public int getClinicalDataOriginKey() {
        return clinicalDataOriginKey;
    }

    public void setClinicalDataOriginKey(int clinicalDataOriginKey) {
        this.clinicalDataOriginKey = clinicalDataOriginKey;
    }

    public TWConfigurationImpl() {
    }

    public void settWUnityEndpoint(String tWUnityEndpoint) {
        this.tWUnityEndpoint = tWUnityEndpoint;
    }

    public void settWUnityUser(String tWUnityUser) {
        this.tWUnityUser = tWUnityUser;
    }

    public void settWUnityPassword(String tWUnityPassword) {
        this.tWUnityPassword = tWUnityPassword;
    }

    public void settWUnitySvcUser(String tWUnitySvcUser) {
        this.tWUnitySvcUser = tWUnitySvcUser;
    }

    public void settWUnitySvcPassword(String tWUnitySvcPassword) {
        this.tWUnitySvcPassword = tWUnitySvcPassword;
    }

    public void settWUnityAppname(String tWUnityAppname) {
        this.tWUnityAppname = tWUnityAppname;
    }

    public void setApiEndpoint(String apiEndpoint) {
        this.apiEndpoint = apiEndpoint;
    }

    public void setProviderGroupId(String providerGroupId) {
        this.providerGroupId = providerGroupId;
    }

    public void setEmrStandardCode(String emrStandardCode) {
        this.emrStandardCode = emrStandardCode;
    }

    public void setTransportProtocol(String transportProtocol) {
        this.transportProtocol = transportProtocol;
    }

    @Override
    public String getApiEndpoint() {
        return apiEndpoint;
    }

    @Override
    public String getTWUnityEndpoint() {
        return tWUnityEndpoint;
    }

    @Override
    public String getTWUnityUser() {
        return tWUnityUser;
    }

    @Override
    public String getTWUnityPassword() {
        return tWUnityPassword;
    }

    @Override
    public String getTWUnitySvcUser() {
        return tWUnitySvcUser;
    }

    @Override
    public String getTWUnitySvcPassword() {
        return tWUnitySvcPassword;
    }

    @Override
    public String getTWUnityAppname() {
        return tWUnityAppname;
    }

    @Override
    public String getProviderGroupId() {
        return providerGroupId;
    }

    @Override
    public String getEmrStandardCode() {
        return emrStandardCode;
    }

    @Override
    public String getTransportProtocol() {
        return transportProtocol;
    }

}
