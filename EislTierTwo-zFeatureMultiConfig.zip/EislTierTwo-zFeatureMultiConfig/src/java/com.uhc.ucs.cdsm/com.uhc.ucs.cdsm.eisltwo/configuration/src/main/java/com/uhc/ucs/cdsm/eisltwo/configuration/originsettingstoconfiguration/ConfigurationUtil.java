package com.uhc.ucs.cdsm.eisltwo.configuration.originsettingstoconfiguration;

import java.util.Collection;

import com.uhc.ucs.cdsm.domain.dictionaries.ClinicalDataOriginSettingTypeDictionary;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;

public class ConfigurationUtil {

    private final static String settingKeyNameNotFound = "Setting key name %s not found";

    private ConfigurationUtil() {
    }

    public static ITWConfiguration createTWConfigurtion(Collection<ClinicalDataOriginSetting> originSettings) {
        TWConfigurationImpl config = new TWConfigurationImpl();

        if (originSettings != null) {
            ClinicalDataOriginSetting apiEndpoint = originSettings.stream().filter(x -> x
                    .getClinicalDataOriginSettingTypeKey() == ClinicalDataOriginSettingTypeDictionary.UnityProgramFhirEndpoint
                            .getClinicalDataOriginSettingTypeKey())
                    .findFirst().orElse(null);
            if (apiEndpoint != null) {
                config.setApiEndpoint(apiEndpoint.getClinicalDataOriginSettingKeyValue());
                config.setClinicalDataOriginKey(apiEndpoint.getClinicalDataOriginKey());
            } else {
                String msg = String.format(settingKeyNameNotFound,
                        ClinicalDataOriginSettingTypeDictionary.UnityProgramFhirEndpoint
                                .getClinicalDataOriginSettingTypeName());
                throw new IllegalArgumentException(msg);
            }

            ClinicalDataOriginSetting unityEndpoint = originSettings.stream().filter(x -> x
                    .getClinicalDataOriginSettingTypeKey() == ClinicalDataOriginSettingTypeDictionary.UnityProgramUnityEndpoint
                            .getClinicalDataOriginSettingTypeKey())
                    .findFirst().orElse(null);
            if (unityEndpoint != null) {
                config.settWUnityEndpoint(unityEndpoint.getClinicalDataOriginSettingKeyValue());
            } else {
                String msg = String.format(settingKeyNameNotFound,
                        ClinicalDataOriginSettingTypeDictionary.UnityProgramUnityEndpoint
                                .getClinicalDataOriginSettingTypeName());
                throw new IllegalArgumentException(msg);
            }
            ClinicalDataOriginSetting unityUser = originSettings.stream().filter(x -> x
                    .getClinicalDataOriginSettingTypeKey() == ClinicalDataOriginSettingTypeDictionary.UnityProgramUnityUser
                            .getClinicalDataOriginSettingTypeKey())
                    .findFirst().orElse(null);
            if (unityUser != null) {
                config.settWUnityUser(unityUser.getClinicalDataOriginSettingKeyValue());
            } else {
                String msg = String.format(settingKeyNameNotFound,
                        ClinicalDataOriginSettingTypeDictionary.UnityProgramUnityUser
                                .getClinicalDataOriginSettingTypeName());
                throw new IllegalArgumentException(msg);
            }
            ClinicalDataOriginSetting unityPassword = originSettings.stream().filter(x -> x
                    .getClinicalDataOriginSettingTypeKey() == ClinicalDataOriginSettingTypeDictionary.UnityProgramUnityPassword
                            .getClinicalDataOriginSettingTypeKey())
                    .findFirst().orElse(null);
            if (unityPassword != null) {
                config.settWUnityPassword(unityPassword.getClinicalDataOriginSettingKeyValue());
            } else {
                String msg = String.format(settingKeyNameNotFound,
                        ClinicalDataOriginSettingTypeDictionary.UnityProgramUnityPassword
                                .getClinicalDataOriginSettingTypeName());
                throw new IllegalArgumentException(msg);
            }

            ClinicalDataOriginSetting svcUser = originSettings.stream().filter(x -> x
                    .getClinicalDataOriginSettingTypeKey() == ClinicalDataOriginSettingTypeDictionary.UnityProgramSvcUser
                            .getClinicalDataOriginSettingTypeKey())
                    .findFirst().orElse(null);
            if (svcUser != null) {
                config.settWUnitySvcUser(svcUser.getClinicalDataOriginSettingKeyValue());
            } else {
                String msg = String.format(settingKeyNameNotFound,
                        ClinicalDataOriginSettingTypeDictionary.UnityProgramSvcUser
                                .getClinicalDataOriginSettingTypeName());
                throw new IllegalArgumentException(msg);
            }

            ClinicalDataOriginSetting svcPassword = originSettings.stream().filter(x -> x
                    .getClinicalDataOriginSettingTypeKey() == ClinicalDataOriginSettingTypeDictionary.UnityProgramSvcPassword
                            .getClinicalDataOriginSettingTypeKey())
                    .findFirst().orElse(null);
            if (svcPassword != null) {
                config.settWUnitySvcPassword(svcPassword.getClinicalDataOriginSettingKeyValue());
            } else {
                String msg = String.format(settingKeyNameNotFound,
                        ClinicalDataOriginSettingTypeDictionary.UnityProgramSvcPassword
                                .getClinicalDataOriginSettingTypeName());
                throw new IllegalArgumentException(msg);
            }

            ClinicalDataOriginSetting unityAppname = originSettings.stream().filter(x -> x
                    .getClinicalDataOriginSettingTypeKey() == ClinicalDataOriginSettingTypeDictionary.UnityProgramUnityAppname
                            .getClinicalDataOriginSettingTypeKey())
                    .findFirst().orElse(null);
            if (unityAppname != null) {
                config.settWUnityAppname(unityAppname.getClinicalDataOriginSettingKeyValue());
            } else {
                String msg = String.format(settingKeyNameNotFound,
                        ClinicalDataOriginSettingTypeDictionary.UnityProgramUnityAppname
                                .getClinicalDataOriginSettingTypeName());
                throw new IllegalArgumentException(msg);
            }

            ClinicalDataOriginSetting providerGroupId = originSettings.stream().filter(x -> x
                    .getClinicalDataOriginSettingTypeKey() == ClinicalDataOriginSettingTypeDictionary.ProviderGroupId
                            .getClinicalDataOriginSettingTypeKey())
                    .findFirst().orElse(null);
            if (providerGroupId != null) {
                config.setProviderGroupId(providerGroupId.getClinicalDataOriginSettingKeyValue());
            } else {
                String msg = String.format(settingKeyNameNotFound,
                        ClinicalDataOriginSettingTypeDictionary.ProviderGroupId.getClinicalDataOriginSettingTypeName());
                throw new IllegalArgumentException(msg);
            }

            ClinicalDataOriginSetting emrStandardCode = originSettings.stream().filter(x -> x
                    .getClinicalDataOriginSettingTypeKey() == ClinicalDataOriginSettingTypeDictionary.EmrStandardCode
                            .getClinicalDataOriginSettingTypeKey())
                    .findFirst().orElse(null);
            if (emrStandardCode != null) {
                config.setEmrStandardCode(emrStandardCode.getClinicalDataOriginSettingKeyValue());
            } else {
                String msg = String.format(settingKeyNameNotFound,
                        ClinicalDataOriginSettingTypeDictionary.EmrStandardCode.getClinicalDataOriginSettingTypeName());
                throw new IllegalArgumentException(msg);
            }

            ClinicalDataOriginSetting transportProtocol = originSettings.stream().filter(x -> x
                    .getClinicalDataOriginSettingTypeKey() == ClinicalDataOriginSettingTypeDictionary.TransportProtocol
                            .getClinicalDataOriginSettingTypeKey())
                    .findFirst().orElse(null);
            if (transportProtocol != null) {
                config.setTransportProtocol(transportProtocol.getClinicalDataOriginSettingKeyValue());
            } else {
                String msg = String.format(settingKeyNameNotFound,
                        ClinicalDataOriginSettingTypeDictionary.TransportProtocol
                                .getClinicalDataOriginSettingTypeName());
                throw new IllegalArgumentException(msg);
            }
        }
        return config;
    }

}
