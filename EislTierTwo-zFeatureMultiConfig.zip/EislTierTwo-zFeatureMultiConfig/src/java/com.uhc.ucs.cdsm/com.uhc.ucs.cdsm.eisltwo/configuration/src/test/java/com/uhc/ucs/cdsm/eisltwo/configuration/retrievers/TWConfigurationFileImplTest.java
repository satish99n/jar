package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:/configuration-spring-beans-test.xml")
public class TWConfigurationFileImplTest {

	@Autowired
	ITWConfiguration twConfiguration;
	
	@Test
	public void testApiEndpoint() {
		Assert.assertNotNull("ApiEndpoint is null", twConfiguration.getApiEndpoint());
		Assert.assertEquals("ApiEndpoint not matching", "https://52.168.182.170/FHIRanon/", twConfiguration.getApiEndpoint());
	}

}
