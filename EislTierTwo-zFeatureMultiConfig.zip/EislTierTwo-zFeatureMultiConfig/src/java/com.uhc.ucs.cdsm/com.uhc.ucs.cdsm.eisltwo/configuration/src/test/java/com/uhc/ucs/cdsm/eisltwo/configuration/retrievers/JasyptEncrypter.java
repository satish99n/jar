package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

public class JasyptEncrypter {
	
	private static String password = "pass1";
	private static String plainText = "text to encrypt";
	
	public static void main(String[] args) {
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword(password);
		encryptor.setAlgorithm("PBEWithMD5AndDES");
		String encryptedText = encryptor.encrypt(plainText);
		System.out.println("plainText= " + plainText);
		System.out.println("encryptedText= ENC(" + encryptedText + ")");
	}

}
