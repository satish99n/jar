package com.uhc.ucs.cdsm.eisltwo.configuration.pbe;

import org.jasypt.encryption.pbe.config.SimplePBEConfig;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.SystemInfoDetails;

public class SystemInfoStringPBEConfig extends SimplePBEConfig {
	
	
	 public SystemInfoStringPBEConfig() {
		super();
	}

	 @Override
	public char[] getPasswordCharArray() {
		 return SystemInfoDetails.getSysInfoDetails();
	}

}
