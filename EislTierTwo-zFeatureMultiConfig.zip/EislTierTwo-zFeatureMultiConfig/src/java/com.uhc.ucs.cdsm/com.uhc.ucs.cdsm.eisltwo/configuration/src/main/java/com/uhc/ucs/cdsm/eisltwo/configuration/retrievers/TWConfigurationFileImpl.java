package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers;

import org.springframework.beans.factory.annotation.Value;

import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;

public class TWConfigurationFileImpl implements ITWConfiguration {

    @Value("${ehr.touchworks.fhir.endpoint}")
    private String apiEndpoint;

    @Value("${ehr.touchworks.unity.endpoint}")
    private String tWUnityEndpoint;

    @Value("${ehr.touchworks.unity.user}")
    private String tWUnityUser;

    @Value("${ehr.touchworks.unity.password}")
    private String tWUnityPassword;

    @Value("${ehr.touchworks.unity.svc.user}")
    private String tWUnitySvcUser;

    @Value("${ehr.touchworks.unity.svc.password}")
    private String tWUnitySvcPassword;

    @Value("${ehr.touchworks.unity.appname}")
    private String tWUnityAppname;

    @Value("${local_storage_location}")
    private String localStoragePath;

    @Value("${tw.ProviderGroupId}")
    private String providerGroupId;

    @Value("${tw.EmrStandardCode}")
    private String emrStandardCode;

    @Value("${tw.TransportProtocol}")
    private String transportProtocol;


    @Override
    public String getApiEndpoint() {
        return apiEndpoint;
    }

    @Override
    public String getTWUnityEndpoint() {
        return tWUnityEndpoint;
    }

    @Override
    public String getTWUnityUser() {
        return tWUnityUser;
    }

    @Override
    public String getTWUnityPassword() {
        return tWUnityPassword;
    }

    @Override
    public String getTWUnitySvcUser() {
        return tWUnitySvcUser;
    }

    @Override
    public String getTWUnitySvcPassword() {
        return tWUnitySvcPassword;
    }

    @Override
    public String getTWUnityAppname() {
        return tWUnityAppname;
    }

    public String getLocalStoragePath() {
        return localStoragePath;
    }

    @Override
    public String getProviderGroupId() {
        return providerGroupId;
    }

    @Override
    public String getEmrStandardCode() {
        return emrStandardCode;
    }

    @Override
    public String getTransportProtocol() {
        return transportProtocol;
    }


    public void setApiEndpoint(String apiEndpoint) {
        this.apiEndpoint = apiEndpoint;
    }

    public void settWUnityEndpoint(String tWUnityEndpoint) {
        this.tWUnityEndpoint = tWUnityEndpoint;
    }

    public void settWUnityUser(String tWUnityUser) {
        this.tWUnityUser = tWUnityUser;
    }

    public void settWUnityPassword(String tWUnityPassword) {
        this.tWUnityPassword = tWUnityPassword;
    }

    public void settWUnitySvcUser(String tWUnitySvcUser) {
        this.tWUnitySvcUser = tWUnitySvcUser;
    }

    public void settWUnitySvcPassword(String tWUnitySvcPassword) {
        this.tWUnitySvcPassword = tWUnitySvcPassword;
    }

    public void settWUnityAppname(String tWUnityAppname) {
        this.tWUnityAppname = tWUnityAppname;
    }

    public void setLocalStoragePath(String localStoragePath) {
        this.localStoragePath = localStoragePath;
    }

    public void setProviderGroupId(String providerGroupId) {
        this.providerGroupId = providerGroupId;
    }

    public void setEmrStandardCode(String emrStandardCode) {
        this.emrStandardCode = emrStandardCode;
    }

    public void setTransportProtocol(String transportProtocol) {
        this.transportProtocol = transportProtocol;
    }

    @Override
    public int getClinicalDataOriginKey() {
        // TODO Auto-generated method stub
        return 0;
    }
}
