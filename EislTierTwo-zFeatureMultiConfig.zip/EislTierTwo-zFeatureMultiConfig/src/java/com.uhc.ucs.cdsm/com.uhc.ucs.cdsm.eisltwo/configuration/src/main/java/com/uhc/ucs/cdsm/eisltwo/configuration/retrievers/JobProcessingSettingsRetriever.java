package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers;

import com.uhc.ucs.cdsm.eisltwo.configuration.consts.EnvironmentVariableNameConstants;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.IJobProcessingSettingsRetriever;

import org.apache.commons.logging.Log;

public class JobProcessingSettingsRetriever implements IJobProcessingSettingsRetriever {

	private final Log logger;

	public JobProcessingSettingsRetriever(Log lgr) {

		if (null == lgr) {
			throw new IllegalArgumentException("Log is null");
		}

		this.logger = lgr;
	}
	
	@Override
	public int getBetweenRunsSleepMilliseconds() {
		String configValue = System.getProperty(EnvironmentVariableNameConstants.JobProcessingBetweenRunsSleepMilliseconds);
		if (null == configValue)
		{
			configValue = "10000"; /* set default value if the env variable does not exist */
		}
		int returnValue = Integer.parseInt(configValue);	
		return returnValue;
	}
}
