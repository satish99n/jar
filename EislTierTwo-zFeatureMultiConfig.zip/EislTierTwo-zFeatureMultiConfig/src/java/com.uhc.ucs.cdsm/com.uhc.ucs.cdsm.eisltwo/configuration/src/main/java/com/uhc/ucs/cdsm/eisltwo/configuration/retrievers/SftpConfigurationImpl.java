package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers;


import org.springframework.beans.factory.annotation.Value;

import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ISFTPConfiguration;

public class SftpConfigurationImpl  implements ISFTPConfiguration{
	
	@Value("${sftp.FileDestination}")
	private String fileDestination;
	
	@Value("${sftp.HostName}")
	private String hostName;
	
	@Value("${sftp.Username}")
	private String username;
	
	@Value("${sftp.Password}")
	private String password;
	
	@Value("${sftp.FilePattern}")
	private String filePattern;
	
	@Value("${sftp.Port}")
	private String port;
	
	public String getFileDestination() {
		return fileDestination;
	}
	public void setFileDestination(String fileDestination) {
		this.fileDestination = fileDestination;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getUsername() {
		return username;
	}
	public void setUserName(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFilePattern() {
		return filePattern;
	}
	public void setFilePattern(String filePattern) {
		this.filePattern = filePattern;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	

	

	

}
