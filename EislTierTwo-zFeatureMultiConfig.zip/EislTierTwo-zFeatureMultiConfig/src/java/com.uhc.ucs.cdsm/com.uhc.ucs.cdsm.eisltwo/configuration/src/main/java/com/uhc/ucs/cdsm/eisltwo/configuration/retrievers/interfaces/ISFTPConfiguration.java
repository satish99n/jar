package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces;

public interface ISFTPConfiguration {
	public String getFileDestination();

	public String getHostName();

	public String getUsername();

	public String getPassword();

	public String getPort();

	public String getFilePattern();

}
