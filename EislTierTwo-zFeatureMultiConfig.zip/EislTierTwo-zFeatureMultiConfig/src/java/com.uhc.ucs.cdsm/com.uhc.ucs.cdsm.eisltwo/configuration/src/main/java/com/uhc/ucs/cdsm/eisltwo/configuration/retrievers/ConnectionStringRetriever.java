package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers;

import org.springframework.beans.factory.annotation.Value;

import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.IConnectionStringRetriever;

public class ConnectionStringRetriever implements IConnectionStringRetriever {


	@Value("${PrimaryDatabaseConnectionString}")
	private String primaryDatabaseConnectionString;
	
	@Value("${MessageBrokerListenConnectionString}")
	private String messageBrokerListenConnectionString;
	
	@Value("${MessageBrokerSendConnectionString}")
	private String messageBrokerSendConnectionString;
	
	@Value("${JobProcessingBetweenRunsSleepMilliseconds}")
	private String jobProcessingBetweenRunsSleepMilliseconds;
	
	public String retrievePrimaryDatabaseConnectionString() {
		return primaryDatabaseConnectionString;
	}

	public String retrieveMessageBrokerListenConnectionString() {
		return messageBrokerListenConnectionString;
	}

	public String retrieveMessageBrokerSendConnectionString() {
		return messageBrokerSendConnectionString;
	}
	
	public String retrieveJobProcessingBetweenRunsSleepMilliseconds(){
		return jobProcessingBetweenRunsSleepMilliseconds;
	}

	public void setPrimaryDatabaseConnectionString(String primaryDatabaseConnectionString) {
		this.primaryDatabaseConnectionString = primaryDatabaseConnectionString;
	}

	public void setMessageBrokerListenConnectionString(String messageBrokerListenConnectionString) {
		this.messageBrokerListenConnectionString = messageBrokerListenConnectionString;
	}

	public void setMessageBrokerSendConnectionString(String messageBrokerSendConnectionString) {
		this.messageBrokerSendConnectionString = messageBrokerSendConnectionString;
	}

	public void setJobProcessingBetweenRunsSleepMilliseconds(String jobProcessingBetweenRunsSleepMilliseconds) {
		this.jobProcessingBetweenRunsSleepMilliseconds = jobProcessingBetweenRunsSleepMilliseconds;
	}
}
