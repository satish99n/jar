package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers;

import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ILocalStorageConfiguration;
import org.springframework.beans.factory.annotation.Value;

public class LocalStorageConfiguration implements ILocalStorageConfiguration {

    @Value("${local_storage_location}")
    private String localStoragePath;

    public void setLocalStoragePath(String localStoragePath) {
        this.localStoragePath = localStoragePath;
    }

    @Override
    public String getLocalStoragePath() {
        return localStoragePath;
    }

}
