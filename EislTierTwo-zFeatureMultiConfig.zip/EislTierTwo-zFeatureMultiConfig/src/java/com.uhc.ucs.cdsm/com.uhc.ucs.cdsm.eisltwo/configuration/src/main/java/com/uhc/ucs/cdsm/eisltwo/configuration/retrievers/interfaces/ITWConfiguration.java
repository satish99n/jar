package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces;

public interface ITWConfiguration {

    public String getApiEndpoint();

    public String getTWUnityEndpoint();

    public String getTWUnityUser();

    public String getTWUnityPassword();

    public String getTWUnitySvcUser();

    public String getTWUnitySvcPassword();

    public String getTWUnityAppname();

    public String getProviderGroupId();

    public String getEmrStandardCode();

    public String getTransportProtocol();

    public int getClinicalDataOriginKey();

}
