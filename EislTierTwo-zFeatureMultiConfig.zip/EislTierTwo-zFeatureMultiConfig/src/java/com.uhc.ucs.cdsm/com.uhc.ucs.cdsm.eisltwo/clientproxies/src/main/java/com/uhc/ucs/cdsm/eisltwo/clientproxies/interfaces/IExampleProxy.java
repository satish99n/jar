package com.uhc.ucs.cdsm.eisltwo.clientproxies.interfaces;

public interface IExampleProxy {
	
	public String examplePerformGet();

}
