package com.uhc.ucs.cdsm.eisltwo.clientproxies;

import org.apache.commons.logging.Log;

import com.uhc.ucs.cdsm.eisltwo.clientproxies.interfaces.IExampleProxy;

import java.lang.String;

import reactor.core.publisher.Mono;

import org.apache.commons.logging.Log;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;


public class ExampleProxy implements IExampleProxy {
	
	private final Log logger;

	public ExampleProxy(Log lgr) {

		if (null == lgr) {
			throw new IllegalArgumentException("Log is null");
		}

		this.logger = lgr;
	}
	
	public String examplePerformGet()
	{
		
    	WebClient client = WebClient.create("https://httpbin.org");

    	Mono<ClientResponse> result = client.get()
    			.uri("/get")
    			.accept(MediaType.TEXT_PLAIN)
    			.exchange();

    	String returnValue = result.flatMap(res -> res.bodyToMono(String.class)).block();
		
    	return returnValue;
	}
}