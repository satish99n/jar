package com.uhc.ucs.cdsm.adapters.allscriptsadapter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;
import com.uhc.ucs.cdsm.adapters.adaptersbase.interfaces.IClinicalAdapter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.DocumentWrapper;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Insurance;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Patient;
import com.uhc.ucs.cdsm.adapters.allscriptsadapter.util.ConnectionUtil;
import com.uhc.ucs.cdsm.adapters.allscriptsadapter.util.TokenCacheManager;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;
import com.uhc.ucs.cdsm.eisltwo.configuration.originsettingstoconfiguration.ConfigurationUtil;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;

import ch.qos.logback.core.net.SyslogOutputStream;

public class AllscriptClinicalAdapterTest {

    private ApplicationContext applicationContext;

    private final Log log = LogFactory.getLog(AllscriptClinicalAdapterTest.class);

    public static void main(String[] args) throws Exception {
        AllscriptClinicalAdapterTest adapter = new AllscriptClinicalAdapterTest();
        adapter.applicationContext = new ClassPathXmlApplicationContext("adapters-allscriptsadapter-spring-beans-test.xml");
        ITWConfiguration twConfiguration = ConfigurationUtil.createTWConfigurtion(getOriginSettings());
      //  adapter.testGetToken(twConfiguration);
        adapter.testGetSchedule(twConfiguration);
        adapter.testGetPatientFull(twConfiguration);
        adapter.testGetCCDA();

        /*Map<String,String> checkMap = new ConcurrentHashMap<>();
        checkMap.put("a", "first");
        checkMap.put("b", "second");
        checkMap.put("a", "123");
        System.out.println(checkMap.get("a"));
        System.out.println(checkMap.get("b"));*/
    }

    public void testGetToken(ITWConfiguration twConfiguration) throws Exception{
        ConnectionUtil connectionUtil = (ConnectionUtil) applicationContext.getBean("connectionUtil");
       connectionUtil.getToken(twConfiguration);
    }

    private static Collection<ClinicalDataOriginSetting> getOriginSettings() {
        Collection<ClinicalDataOriginSetting> originSettings = new ArrayList<>();
        originSettings.add(getClinicalDataOriginSetting("Unity.Program.Fhir.Endpoint", "https://52.168.182.170/FHIRanon/", (short) 201));
        originSettings.add(getClinicalDataOriginSetting("Unity.Program.Unity.Endpoint", "http://optumdevtw17pm15.open.allscripts.com/Unity/UnityService.svc/json/", (short) 202));
        originSettings.add(getClinicalDataOriginSetting("Unity.Program.Unity.User", "SMIJOH", (short) 203));
        originSettings.add(getClinicalDataOriginSetting("Unity.Program.Unity.Password", "password01", (short) 204));
        originSettings.add(getClinicalDataOriginSetting("Unity.Program.Svc.User", "Optum-4bed-QuestOnFHI-test", (short) 205));
        originSettings.add(getClinicalDataOriginSetting("Unity.Program.Svc.Password", "!pt1msMfrT!nFe#Rqb%st2nfH2rT%s", (short) 206));
        originSettings.add(getClinicalDataOriginSetting("Unity.Program.Unity.Appname", "OptumSMARTonFHIR.QuestOnFHIR.TestApp", (short) 207));
        originSettings.add(getClinicalDataOriginSetting("ProviderGroupId", "12345", (short) 111));
        originSettings.add(getClinicalDataOriginSetting("EmrStandardCode", "emr1", (short) 122));
        originSettings.add(getClinicalDataOriginSetting("TransportProtocol", "tr1", (short) 133));
        return originSettings;
    }

    private static ClinicalDataOriginSetting getClinicalDataOriginSetting(String key, String value, short typeKey) {
        ClinicalDataOriginSetting originSetting = new ClinicalDataOriginSetting();
        originSetting.setClinicalDataOriginSettingKeyName(key);
        originSetting.setClinicalDataOriginSettingKeyValue(value);
        originSetting.setClinicalDataOriginSettingTypeKey(typeKey);
        originSetting.setClinicalDataOriginKey(10001);
        return originSetting;
    }

    public void testGetSchedule(ITWConfiguration twConfiguration) throws Exception {
        ConnectionUtil connectionUtil = (ConnectionUtil) applicationContext.getBean("connectionUtil");
        //connectionUtil.getToken(twConfiguration);
        final String response = connectionUtil.createAndSendRequest(twConfiguration, "GetSchedule", "", "04/25/2018|05/09/2018");

        final JsonObject obj = (JsonObject) new JsonParser().parse(response).getAsJsonArray().get(0);
        JsonArray objs = obj.get("getscheduleinfo").getAsJsonArray();
        List<Encounter> encounters = new ArrayList<Encounter>();
        for (JsonElement ele : objs) {
            JsonObject eleObj = ele.getAsJsonObject();

            Encounter ent = new Encounter();
            ent.setAppointmentLocation(eleObj.get("Location").toString());
            ent.setAppointmentTime(eleObj.get("ApptTime").toString());
            ent.setApptNumberEXT(eleObj.get("ApptNumberEXT").toString());
            ent.setEncounterId(eleObj.get("Encounterid").toString());
            ent.setEncounterStatus(eleObj.get("Status").toString());
            ent.setOrganizationMRN(eleObj.get("organizationMRN").toString());
            ent.setVisitNumberExt(eleObj.get("VisitNumberExt").toString());

            Patient patient = new Patient();
            patient.setPatientId(eleObj.get("patientID").toString());
            patient.setPatientFirstName(eleObj.get("PatientFirstName").toString());
            patient.setPatientLastName(eleObj.get("PatientLastName").toString());
            ent.setPatient(patient);
            encounters.add(ent);
        }

        for(Encounter encounter : encounters) {
            log.info("encounter id:" + encounter.getEncounterId());
            log.info("encounter id:" + encounter.getPatient().getPatientId());
        }
    }

    public void testGetPatientFull(ITWConfiguration twConfiguration) throws ClinicalDataException, InterruptedException, ExecutionException {
        IClinicalAdapter wfAdapter = (IClinicalAdapter) applicationContext.getBean("iClinicalAdapter");
        Patient patient = wfAdapter.getPatientDetails("140155", getOriginSettings());
        List<Insurance> insuranceList = patient.getInsuranceList();
        for(Insurance insurance : insuranceList) {
            log.info(String.format("Insurance type: %s, name: %s ", insurance.getInsuranceName(), insurance.getType().name()));
        }
    }

    public void testGetCCDA() throws ClinicalDataException, InterruptedException, ExecutionException {
        IClinicalAdapter wfAdapter = (IClinicalAdapter) applicationContext.getBean("iClinicalAdapter");
        DocumentWrapper dw = wfAdapter.getCCDA("140156", "270922", getOriginSettings());
        log.info(String.format("Docuemnt created for encounterId: %s on %s", dw.getEncounterID(), dw.getDocumentCreationTime()));
    }

}
