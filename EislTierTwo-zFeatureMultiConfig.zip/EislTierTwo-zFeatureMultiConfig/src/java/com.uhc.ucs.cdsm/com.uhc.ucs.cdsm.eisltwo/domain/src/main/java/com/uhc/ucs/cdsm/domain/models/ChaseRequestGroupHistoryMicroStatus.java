package com.uhc.ucs.cdsm.domain.models;

import java.util.Date;

public class ChaseRequestGroupHistoryMicroStatus {
	private short chaseRequestGroupHistoryMicroStatusKey;
	private String chaseRequestGroupHistoryMicroStatusName;
	private short chaseRequestGroupHistoryMacroStatusKey;
	private Date insertDate;
	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;
	
	/* Navigation Properties */
	ChaseRequestGroupHistoryMacroStatus parentChaseRequestGroupHistoryMacroStatus;
	
	public ChaseRequestGroupHistoryMacroStatus getParentChaseRequestGroupHistoryMacroStatus() {
		return parentChaseRequestGroupHistoryMacroStatus;
	}

	public void setParentChaseRequestGroupHistoryMacroStatus(
			ChaseRequestGroupHistoryMacroStatus parentChaseRequestGroupHistoryMacroStatus) {
		this.parentChaseRequestGroupHistoryMacroStatus = parentChaseRequestGroupHistoryMacroStatus;
	}

	public short getChaseRequestGroupHistoryMicroStatusKey() {
		return chaseRequestGroupHistoryMicroStatusKey;
	}

	public void setChaseRequestGroupHistoryMicroStatusKey(short chaseRequestGroupHistoryMicroStatusKey) {
		this.chaseRequestGroupHistoryMicroStatusKey = chaseRequestGroupHistoryMicroStatusKey;
	}

	public String getChaseRequestGroupHistoryMicroStatusName() {
		return chaseRequestGroupHistoryMicroStatusName;
	}

	public void setChaseRequestGroupHistoryMicroStatusName(String chaseRequestGroupHistoryMicroStatusName) {
		this.chaseRequestGroupHistoryMicroStatusName = chaseRequestGroupHistoryMicroStatusName;
	}

	public short getChaseRequestGroupHistoryMacroStatusKey() {
		return chaseRequestGroupHistoryMacroStatusKey;
	}

	public void setChaseRequestGroupHistoryMacroStatusKey(short chaseRequestGroupHistoryMacroStatusKey) {
		this.chaseRequestGroupHistoryMacroStatusKey = chaseRequestGroupHistoryMacroStatusKey;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
}
