package com.uhc.ucs.cdsm.domain.models;

import java.util.Date;

public class ClinicalDataOriginSetting {
	
	private int clinicalDataOriginSettingKey;
	private int clinicalDataOriginKey;
	private short clinicalDataOriginSettingTypeKey;
	private String clinicalDataOriginSettingKeyName;
	private String clinicalDataOriginSettingKeyDescription;
	private String clinicalDataOriginSettingKeyValue;
	private Date insertDate;
	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;
	
	/* navigation properties */
	private ClinicalDataOriginSettingType parentClinicalDataOriginSettingType;

	public int getClinicalDataOriginSettingKey() {
		return clinicalDataOriginSettingKey;
	}

	public void setClinicalDataOriginSettingKey(int clinicalDataOriginSettingKey) {
		this.clinicalDataOriginSettingKey = clinicalDataOriginSettingKey;
	}

	public int getClinicalDataOriginKey() {
		return clinicalDataOriginKey;
	}

	public void setClinicalDataOriginKey(int clinicalDataOriginKey) {
		this.clinicalDataOriginKey = clinicalDataOriginKey;
	}

	public short getClinicalDataOriginSettingTypeKey() {
		return clinicalDataOriginSettingTypeKey;
	}

	public void setClinicalDataOriginSettingTypeKey(short clinicalDataOriginSettingTypeKey) {
		this.clinicalDataOriginSettingTypeKey = clinicalDataOriginSettingTypeKey;
	}

	public String getClinicalDataOriginSettingKeyName() {
		return clinicalDataOriginSettingKeyName;
	}

	public void setClinicalDataOriginSettingKeyName(String clinicalDataOriginSettingKeyName) {
		this.clinicalDataOriginSettingKeyName = clinicalDataOriginSettingKeyName;
	}

	public String getClinicalDataOriginSettingKeyDescription() {
		return clinicalDataOriginSettingKeyDescription;
	}

	public void setClinicalDataOriginSettingKeyDescription(String clinicalDataOriginSettingKeyDescription) {
		this.clinicalDataOriginSettingKeyDescription = clinicalDataOriginSettingKeyDescription;
	}

	public String getClinicalDataOriginSettingKeyValue() {
		return clinicalDataOriginSettingKeyValue;
	}

	public void setClinicalDataOriginSettingKeyValue(String clinicalDataOriginSettingKeyValue) {
		this.clinicalDataOriginSettingKeyValue = clinicalDataOriginSettingKeyValue;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public ClinicalDataOriginSettingType getParentClinicalDataOriginSettingType() {
		return parentClinicalDataOriginSettingType;
	}

	public void setParentClinicalDataOriginSettingType(ClinicalDataOriginSettingType parentClinicalDataOriginSettingType) {
		this.parentClinicalDataOriginSettingType = parentClinicalDataOriginSettingType;
	}
	
	
}