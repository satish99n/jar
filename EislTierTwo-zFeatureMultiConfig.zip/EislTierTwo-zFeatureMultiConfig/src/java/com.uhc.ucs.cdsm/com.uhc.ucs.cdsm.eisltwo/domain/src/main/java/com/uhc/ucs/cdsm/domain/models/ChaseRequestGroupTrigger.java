package com.uhc.ucs.cdsm.domain.models;

import java.util.Date;

public class ChaseRequestGroupTrigger {
	private short chaseRequestGroupTriggerKey;
	private String chaseRequestGroupTriggerName;
	private Date insertDate;
	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;

	public short getChaseRequestGroupTriggerKey() {
		return chaseRequestGroupTriggerKey;
	}

	public void setChaseRequestGroupTriggerKey(short chaseRequestGroupTriggerKey) {
		this.chaseRequestGroupTriggerKey = chaseRequestGroupTriggerKey;
	}

	public String getChaseRequestGroupTriggerName() {
		return chaseRequestGroupTriggerName;
	}

	public void setChaseRequestGroupTriggerName(String chaseRequestGroupTriggerName) {
		this.chaseRequestGroupTriggerName = chaseRequestGroupTriggerName;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
}
