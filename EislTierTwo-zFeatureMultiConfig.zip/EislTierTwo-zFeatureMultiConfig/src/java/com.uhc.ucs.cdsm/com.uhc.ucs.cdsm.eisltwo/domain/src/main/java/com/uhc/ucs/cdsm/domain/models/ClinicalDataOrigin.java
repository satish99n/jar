package com.uhc.ucs.cdsm.domain.models;

import java.util.Date;

public class ClinicalDataOrigin
{
private int clinicalDataOriginKey; /* PK */

private String clinicalDataOriginCode;

private String clinicalDataOriginName;

private String clinicalDataOriginDisplayName;

private String clinicalAdapterConcreteName;

private short eMRSystemKey;

private short macroStatusKey;

private Date startDate;

private Date insertDate;

private String createdBy;

private Date updatedDate;

private String updatedBy;

public int getClinicalDataOriginKey() {
    return clinicalDataOriginKey;
}

public void setClinicalDataOriginKey(int clinicalDataOriginKey) {
    this.clinicalDataOriginKey = clinicalDataOriginKey;
}

public String getClinicalDataOriginCode() {
    return clinicalDataOriginCode;
}

public void setClinicalDataOriginCode(String clinicalDataOriginCode) {
    this.clinicalDataOriginCode = clinicalDataOriginCode;
}

public String getClinicalDataOriginName() {
    return clinicalDataOriginName;
}

public void setClinicalDataOriginName(String clinicalDataOriginName) {
    this.clinicalDataOriginName = clinicalDataOriginName;
}

public String getClinicalDataOriginDisplayName() {
    return clinicalDataOriginDisplayName;
}

public void setClinicalDataOriginDisplayName(String clinicalDataOriginDisplayName) {
    this.clinicalDataOriginDisplayName = clinicalDataOriginDisplayName;
}

public String getClinicalAdapterConcreteName() {
    return clinicalAdapterConcreteName;
}

public void setClinicalAdapterConcreteName(String clinicalAdapterConcreteName) {
    this.clinicalAdapterConcreteName = clinicalAdapterConcreteName;
}

public short geteMRSystemKey() {
    return eMRSystemKey;
}

public void seteMRSystemKey(short eMRSystemKey) {
    this.eMRSystemKey = eMRSystemKey;
}

public short getMacroStatusKey() {
    return macroStatusKey;
}

public void setMacroStatusKey(short macroStatusKey) {
    this.macroStatusKey = macroStatusKey;
}

public Date getStartDate() {
    return startDate;
}

public void setStartDate(Date startDate) {
    this.startDate = startDate;
}

public Date getInsertDate() {
    return insertDate;
}

public void setInsertDate(Date insertDate) {
    this.insertDate = insertDate;
}

public String getCreatedBy() {
    return createdBy;
}

public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
}

public Date getUpdatedDate() {
    return updatedDate;
}

public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
}

public String getUpdatedBy() {
    return updatedBy;
}

public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
}

}

