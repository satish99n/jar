package com.uhc.ucs.cdsm.domain.models;

import java.util.Date;

public class DeploymentInstanceToClinicalDataOriginLink
{
private int deploymentInstanceKey;

private int clinicalDataOriginKey;

private short macroStatusKey;

private short priorityOrdinal;

private Date insertDate;

private String createdBy;

private Date updatedDate;

private String updatedBy;

public int getDeploymentInstanceKey() {
    return deploymentInstanceKey;
}

public void setDeploymentInstanceKey(int deploymentInstanceKey) {
    this.deploymentInstanceKey = deploymentInstanceKey;
}

public int getClinicalDataOriginKey() {
    return clinicalDataOriginKey;
}

public void setClinicalDataOriginKey(int clinicalDataOriginKey) {
    this.clinicalDataOriginKey = clinicalDataOriginKey;
}

public short getMacroStatusKey() {
    return macroStatusKey;
}

public void setMacroStatusKey(short macroStatusKey) {
    this.macroStatusKey = macroStatusKey;
}

public short getPriorityOrdinal() {
    return priorityOrdinal;
}

public void setPriorityOrdinal(short priorityOrdinal) {
    this.priorityOrdinal = priorityOrdinal;
}

public Date getInsertDate() {
    return insertDate;
}

public void setInsertDate(Date insertDate) {
    this.insertDate = insertDate;
}

public String getCreatedBy() {
    return createdBy;
}

public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
}

public Date getUpdatedDate() {
    return updatedDate;
}

public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
}

public String getUpdatedBy() {
    return updatedBy;
}

public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
}


}

