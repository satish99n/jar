package com.uhc.ucs.cdsm.domain.dictionaries;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistoryMicroStatus;

public class ChaseRequestGroupHistoryMicroStatusDictionary {

	/*
	Select 
	'
		public static final ChaseRequestGroupHistoryMicroStatus ' + REPLACE(ChaseRequestGroupHistoryMacroStatusName , ' ' , '') + REPLACE(ChaseRequestGroupHistoryMicroStatusName , ' ' , '')  +' = new ChaseRequestGroupHistoryMicroStatus() {{
			setChaseRequestGroupHistoryMicroStatusKey((short)'+convert(varchar(64), ChaseRequestGroupHistoryMicroStatusKey)+');
			setChaseRequestGroupHistoryMacroStatusKey((short)'+convert(varchar(64), mic.ChaseRequestGroupHistoryMacroStatusKey)+');
			setChaseRequestGroupHistoryMicroStatusName("'+ ChaseRequestGroupHistoryMicroStatusName+'");
		}};
	'
	FROM lookup.ChaseRequestGroupHistoryMicroStatus mic
	join lookup.ChaseRequestGroupHistoryMacroStatus mac on mic.ChaseRequestGroupHistoryMacroStatusKey = mac.ChaseRequestGroupHistoryMacroStatusKey	
	*/

	public static final ChaseRequestGroupHistoryMicroStatus NewMicroDefault = new ChaseRequestGroupHistoryMicroStatus() {
		{
			setChaseRequestGroupHistoryMicroStatusKey((short) 1005);
			setChaseRequestGroupHistoryMacroStatusKey((short) 5);
			setChaseRequestGroupHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestGroupHistoryMicroStatus AboutToSendBulkEncounterRequestToSourceDataMicroDefault = new ChaseRequestGroupHistoryMicroStatus() {
		{
			setChaseRequestGroupHistoryMicroStatusKey((short) 1015);
			setChaseRequestGroupHistoryMacroStatusKey((short) 15);
			setChaseRequestGroupHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestGroupHistoryMicroStatus SendBulkEncounterRequestToSourceDataCompletedMicroDefault = new ChaseRequestGroupHistoryMicroStatus() {
		{
			setChaseRequestGroupHistoryMicroStatusKey((short) 1025);
			setChaseRequestGroupHistoryMacroStatusKey((short) 25);
			setChaseRequestGroupHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestGroupHistoryMicroStatus SendBulkEncounterRequestToSourceDataCompletedWithNoEncountersMicroDefault = new ChaseRequestGroupHistoryMicroStatus() {
		{
			setChaseRequestGroupHistoryMicroStatusKey((short) 1027);
			setChaseRequestGroupHistoryMacroStatusKey((short) 25);
			setChaseRequestGroupHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestGroupHistoryMicroStatus SendBulkEncounterRequestToSourceDataFailedMicroDefault = new ChaseRequestGroupHistoryMicroStatus() {
		{
			setChaseRequestGroupHistoryMicroStatusKey((short) 1026);
			setChaseRequestGroupHistoryMacroStatusKey((short) 26);
			setChaseRequestGroupHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestGroupHistoryMicroStatus PartiallyCompleteMicroDefault = new ChaseRequestGroupHistoryMicroStatus() {
		{
			setChaseRequestGroupHistoryMicroStatusKey((short) 1055);
			setChaseRequestGroupHistoryMacroStatusKey((short) 55);
			setChaseRequestGroupHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestGroupHistoryMicroStatus CompletedWithSomeErrorsMicroDefault = new ChaseRequestGroupHistoryMicroStatus() {
		{
			setChaseRequestGroupHistoryMicroStatusKey((short) 1105);
			setChaseRequestGroupHistoryMacroStatusKey((short) 105);
			setChaseRequestGroupHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestGroupHistoryMicroStatus CompletedWithNoErrorsMicroDefault = new ChaseRequestGroupHistoryMicroStatus() {
		{
			setChaseRequestGroupHistoryMicroStatusKey((short) 1155);
			setChaseRequestGroupHistoryMacroStatusKey((short) 155);
			setChaseRequestGroupHistoryMicroStatusName("Micro Default");
		}
	};
}
