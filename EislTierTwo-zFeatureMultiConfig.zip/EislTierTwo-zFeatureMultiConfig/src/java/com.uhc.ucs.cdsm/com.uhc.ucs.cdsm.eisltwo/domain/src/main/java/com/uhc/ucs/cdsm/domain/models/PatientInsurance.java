package com.uhc.ucs.cdsm.domain.models;

import java.util.Date;

public class PatientInsurance {
	private long patientInsuranceKey;
	private int clinicalDataOriginKey;
	private long patientKey;
	private short insuranceIdentifierType;
	private String insuranceIdentifier;
	private Date insertDate;
	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;
	
	/* Navigation properties */
	private Patient parentPatient;

	public long getPatientInsuranceKey() {
		return patientInsuranceKey;
	}

	public void setPatientInsuranceKey(long patientInsuranceKey) {
		this.patientInsuranceKey = patientInsuranceKey;
	}

	public int getClinicalDataOriginKey() {
		return clinicalDataOriginKey;
	}

	public void setClinicalDataOriginKey(int clinicalDataOriginKey) {
		this.clinicalDataOriginKey = clinicalDataOriginKey;
	}

	public long getPatientKey() {
		return patientKey;
	}

	public void setPatientKey(long patientKey) {
		this.patientKey = patientKey;
	}

	public short getInsuranceIdentifierType() {
		return insuranceIdentifierType;
	}

	public void setInsuranceIdentifierType(short insuranceIdentifierType) {
		this.insuranceIdentifierType = insuranceIdentifierType;
	}

	public String getInsuranceIdentifier() {
		return insuranceIdentifier;
	}

	public void setInsuranceIdentifier(String insuranceIdentifier) {
		this.insuranceIdentifier = insuranceIdentifier;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Patient getParentPatient() {
		return parentPatient;
	}

	public void setParentPatient(Patient parentPatient) {
		this.parentPatient = parentPatient;
	}
	
	
}