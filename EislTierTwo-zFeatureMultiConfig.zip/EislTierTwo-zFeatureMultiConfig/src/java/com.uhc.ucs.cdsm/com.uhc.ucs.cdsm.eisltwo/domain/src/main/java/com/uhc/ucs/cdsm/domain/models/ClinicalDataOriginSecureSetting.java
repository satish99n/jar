package com.uhc.ucs.cdsm.domain.models;

import java.util.Date;

public class ClinicalDataOriginSecureSetting
{
private int clinicalDataOriginSecureSettingKey;

private int clinicalDataOriginKey;

private String clinicalDataOriginSecureSettingKeyName;

private String clinicalDataOriginSecureSettingKeyDescription;

private byte[] clinicalDataOriginSecureSettingKeyValue;

private Date insertDate;

private String insertedBy;

private Date lastUpdated;

private String lastUpdatedBy;

public int getClinicalDataOriginSecureSettingKey() {
	return clinicalDataOriginSecureSettingKey;
}

public void setClinicalDataOriginSecureSettingKey(int clinicalDataOriginSecureSettingKey) {
	this.clinicalDataOriginSecureSettingKey = clinicalDataOriginSecureSettingKey;
}

public int getClinicalDataOriginKey() {
	return clinicalDataOriginKey;
}

public void setClinicalDataOriginKey(int clinicalDataOriginKey) {
	this.clinicalDataOriginKey = clinicalDataOriginKey;
}

public String getClinicalDataOriginSecureSettingKeyName() {
	return clinicalDataOriginSecureSettingKeyName;
}

public void setClinicalDataOriginSecureSettingKeyName(String clinicalDataOriginSecureSettingKeyName) {
	this.clinicalDataOriginSecureSettingKeyName = clinicalDataOriginSecureSettingKeyName;
}

public String getClinicalDataOriginSecureSettingKeyDescription() {
	return clinicalDataOriginSecureSettingKeyDescription;
}

public void setClinicalDataOriginSecureSettingKeyDescription(String clinicalDataOriginSecureSettingKeyDescription) {
	this.clinicalDataOriginSecureSettingKeyDescription = clinicalDataOriginSecureSettingKeyDescription;
}

public byte[] getClinicalDataOriginSecureSettingKeyValue() {
	return clinicalDataOriginSecureSettingKeyValue;
}

public void setClinicalDataOriginSecureSettingKeyValue(byte[] clinicalDataOriginSecureSettingKeyValue) {
	this.clinicalDataOriginSecureSettingKeyValue = clinicalDataOriginSecureSettingKeyValue;
}

public Date getInsertDate() {
	return insertDate;
}

public void setInsertDate(Date insertDate) {
	this.insertDate = insertDate;
}

public String getInsertedBy() {
	return insertedBy;
}

public void setInsertedBy(String insertedBy) {
	this.insertedBy = insertedBy;
}

public Date getLastUpdated() {
	return lastUpdated;
}

public void setLastUpdated(Date lastUpdated) {
	this.lastUpdated = lastUpdated;
}

public String getLastUpdatedBy() {
	return lastUpdatedBy;
}

public void setLastUpdatedBy(String lastUpdatedBy) {
	this.lastUpdatedBy = lastUpdatedBy;
}

}

