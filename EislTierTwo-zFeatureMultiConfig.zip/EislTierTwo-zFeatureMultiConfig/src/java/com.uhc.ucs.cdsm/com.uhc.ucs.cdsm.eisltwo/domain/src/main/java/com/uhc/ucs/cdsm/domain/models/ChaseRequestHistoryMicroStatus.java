package com.uhc.ucs.cdsm.domain.models;

import java.util.Date;

public class ChaseRequestHistoryMicroStatus {
	private short chaseRequestHistoryMicroStatusKey;
	private String chaseRequestHistoryMicroStatusName;
	private short chaseRequestHistoryMacroStatusKey;
	private Date insertDate;
	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;
	
	/* Navigation Properties */
	ChaseRequestHistoryMacroStatus parentChaseRequestHistoryMacroStatus;
	
	public ChaseRequestHistoryMacroStatus getParentChaseRequestHistoryMacroStatus() {
		return parentChaseRequestHistoryMacroStatus;
	}

	public void setParentChaseRequestHistoryMacroStatus(
			ChaseRequestHistoryMacroStatus parentChaseRequestHistoryMacroStatus) {
		this.parentChaseRequestHistoryMacroStatus = parentChaseRequestHistoryMacroStatus;
	}

	public short getChaseRequestHistoryMicroStatusKey() {
		return chaseRequestHistoryMicroStatusKey;
	}

	public void setChaseRequestHistoryMicroStatusKey(short chaseRequestHistoryMicroStatusKey) {
		this.chaseRequestHistoryMicroStatusKey = chaseRequestHistoryMicroStatusKey;
	}

	public String getChaseRequestHistoryMicroStatusName() {
		return chaseRequestHistoryMicroStatusName;
	}

	public void setChaseRequestHistoryMicroStatusName(String chaseRequestHistoryMicroStatusName) {
		this.chaseRequestHistoryMicroStatusName = chaseRequestHistoryMicroStatusName;
	}

	public short getChaseRequestHistoryMacroStatusKey() {
		return chaseRequestHistoryMacroStatusKey;
	}

	public void setChaseRequestHistoryMacroStatusKey(short chaseRequestHistoryMacroStatusKey) {
		this.chaseRequestHistoryMacroStatusKey = chaseRequestHistoryMacroStatusKey;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
}
