package com.uhc.ucs.cdsm.domain.dictionaries;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupTrigger;

public class ChaseRequestGroupTriggerDictionary {
	
	/*
	
		Select 
		'
			public static final ChaseRequestGroupTrigger ' +  REPLACE(REPLACE(ChaseRequestGroupTriggerName , ' ' , ''), '.', '')  +' = new ChaseRequestGroupTrigger() {{
				setChaseRequestGroupTriggerKey((short)'+convert(varchar(64), ChaseRequestGroupTriggerKey)+');
				setChaseRequestGroupTriggerName("'+ChaseRequestGroupTriggerName+'");
			}};
		'
		--		Select *
		FROM lookup.ChaseRequestGroupTrigger order by [ChaseRequestGroupTriggerKey]
	
	*/	
		

	public static final ChaseRequestGroupTrigger RecurringJob = new ChaseRequestGroupTrigger() {
		{
			setChaseRequestGroupTriggerKey((short) 55);
			setChaseRequestGroupTriggerName("Recurring Job");
		}
	};

	public static final ChaseRequestGroupTrigger HistoricalPull = new ChaseRequestGroupTrigger() {
		{
			setChaseRequestGroupTriggerKey((short) 77);
			setChaseRequestGroupTriggerName("Historical Pull");
		}
	};

}
