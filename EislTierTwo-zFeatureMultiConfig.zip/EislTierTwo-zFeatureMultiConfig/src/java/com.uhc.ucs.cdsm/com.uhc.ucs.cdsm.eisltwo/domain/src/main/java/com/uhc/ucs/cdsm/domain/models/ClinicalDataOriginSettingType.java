package com.uhc.ucs.cdsm.domain.models;

import java.util.Date;

public class ClinicalDataOriginSettingType {
	private short clinicalDataOriginSettingTypeKey;
	private String clinicalDataOriginSettingTypeName;
	private String clinicalDataOriginSettingTypeDescription;
	private Date insertDate;
	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;

	public short getClinicalDataOriginSettingTypeKey() {
		return clinicalDataOriginSettingTypeKey;
	}

	public void setClinicalDataOriginSettingTypeKey(short clinicalDataOriginSettingTypeKey) {
		this.clinicalDataOriginSettingTypeKey = clinicalDataOriginSettingTypeKey;
	}

	public String getClinicalDataOriginSettingTypeName() {
		return clinicalDataOriginSettingTypeName;
	}

	public void setClinicalDataOriginSettingTypeName(String clinicalDataOriginSettingTypeName) {
		this.clinicalDataOriginSettingTypeName = clinicalDataOriginSettingTypeName;
	}

	public String getClinicalDataOriginSettingTypeDescription() {
		return clinicalDataOriginSettingTypeDescription;
	}

	public void setClinicalDataOriginSettingTypeDescription(String clinicalDataOriginSettingTypeDescription) {
		this.clinicalDataOriginSettingTypeDescription = clinicalDataOriginSettingTypeDescription;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
}
