package com.uhc.ucs.cdsm.domain.models;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.time.OffsetDateTime;

public class ChaseRequestGroup {
	private long chaseRequestGroupKey;
	private String chaseRequestGroupUniqueIdentifier;
	private OffsetDateTime requestStartDateTime;    
	private OffsetDateTime requestEndDateTime;  	
	private Date insertDate;
	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;
	private int clinicalDataOriginKey;
	/* Navigation Properties */
	private Collection<ChaseRequestGroupHistory> chaseRequestGroupHistories;
	private Collection<ChaseRequest> chaseRequests;

	public ChaseRequestGroup() {
		this.chaseRequestGroupHistories = new ArrayList<>();
		this.chaseRequests = new ArrayList<>();
	}
	
	public Collection<ChaseRequest> getChaseRequests() {
		return chaseRequests;
	}

	public void setChaseRequests(Collection<ChaseRequest> chaseRequests) {
		this.chaseRequests = chaseRequests;
	}

	public Collection<ChaseRequestGroupHistory> getChaseRequestGroupHistories() {
		return chaseRequestGroupHistories;
	}

	public void setChaseRequestGroupHistories(Collection<ChaseRequestGroupHistory> chaseRequestGroupHistories) {
		this.chaseRequestGroupHistories = chaseRequestGroupHistories;
	}	

	public long getChaseRequestGroupKey() {
		return chaseRequestGroupKey;
	}

	public void setChaseRequestGroupKey(long chaseRequestGroupKey) {
		this.chaseRequestGroupKey = chaseRequestGroupKey;
	}

	public String getChaseRequestGroupUniqueIdentifier() {
		return chaseRequestGroupUniqueIdentifier;
	}

	public void setChaseRequestGroupUniqueIdentifier(String chaseRequestGroupUniqueIdentifier) {
		this.chaseRequestGroupUniqueIdentifier = chaseRequestGroupUniqueIdentifier;
	}
	
	public OffsetDateTime getRequestStartDateTime() {
		return requestStartDateTime;
	}

	public void setRequestStartDateTime(OffsetDateTime requestStartDateTime) {
		this.requestStartDateTime = requestStartDateTime;
	}

	public OffsetDateTime getRequestEndDateTime() {
		return requestEndDateTime;
	}

	public void setRequestEndDateTime(OffsetDateTime requestEndDateTime) {
		this.requestEndDateTime = requestEndDateTime;
	}		

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public int getClinicalDataOriginKey() {
		return clinicalDataOriginKey;
	}

	public void setClinicalDataOriginKey(int clinicalDataOriginKey) {
		this.clinicalDataOriginKey = clinicalDataOriginKey;
	}	
	
}
