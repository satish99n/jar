package com.uhc.ucs.cdsm.domain.models;

import java.util.Date;

public class SystemSetting {
	private int systemSettingKey;
	private int systemSettingCategoryKey;
	private String settingKeyName;
	private String settingKeyDisplayName;
	private String settingValue;
	private String settingValueType;
	private Date insertDate;
	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;
	
	/* future note : do not "map" settingDefaultValue with any ORM tools */
	private String settingDefaultValue;

	/* Navigation */
	private SystemSettingCategory parentSystemSettingCategory;

	public SystemSettingCategory getParentSystemSettingCategory() {
		return parentSystemSettingCategory;
	}

	public void setParentSystemSettingCategory(SystemSettingCategory parentSystemSettingCategory) {
		this.parentSystemSettingCategory = parentSystemSettingCategory;
	}

	public int getSystemSettingKey() {
		return systemSettingKey;
	}

	public void setSystemSettingKey(int systemSettingKey) {
		this.systemSettingKey = systemSettingKey;
	}

	public int getSystemSettingCategoryKey() {
		return systemSettingCategoryKey;
	}

	public void setSystemSettingCategoryKey(int systemSettingCategoryKey) {
		this.systemSettingCategoryKey = systemSettingCategoryKey;
	}

	public String getSettingKeyName() {
		return settingKeyName;
	}

	public void setSettingKeyName(String settingKeyName) {
		this.settingKeyName = settingKeyName;
	}

	public String getSettingKeyDisplayName() {
		return settingKeyDisplayName;
	}

	public void setSettingKeyDisplayName(String settingKeyDisplayName) {
		this.settingKeyDisplayName = settingKeyDisplayName;
	}

	public String getSettingValue() {
		return settingValue;
	}

	public void setSettingValue(String settingValue) {
		this.settingValue = settingValue;
	}

	public String getSettingValueType() {
		return settingValueType;
	}

	public void setSettingValueType(String settingValueType) {
		this.settingValueType = settingValueType;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	
	public String getSettingDefaultValue() {
		return this.settingDefaultValue;
	}

	public void setSettingDefaultValue(String settingDefValue) {
		this.settingDefaultValue = settingDefValue;
	}
}
