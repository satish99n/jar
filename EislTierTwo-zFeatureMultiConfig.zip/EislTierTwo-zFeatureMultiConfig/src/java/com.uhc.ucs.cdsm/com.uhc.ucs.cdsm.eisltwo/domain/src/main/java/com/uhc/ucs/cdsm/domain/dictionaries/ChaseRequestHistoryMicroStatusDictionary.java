package com.uhc.ucs.cdsm.domain.dictionaries;

import java.util.Arrays;
import java.util.Collection;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistoryMicroStatus;

public class ChaseRequestHistoryMicroStatusDictionary {

	/*
	  Select 'public static final ChaseRequestHistoryMicroStatus ' +
	  REPLACE(ChaseRequestHistoryMacroStatusName , ' ' , '') +
	  REPLACE(REPLACE(ChaseRequestHistoryMicroStatusName , ' ' , ''), '.', '') +' = new ChaseRequestHistoryMicroStatus() {{setChaseRequestHistoryMicroStatusKey((short)'+convert(varchar(64),
	  ChaseRequestHistoryMicroStatusKey)+');
	  setChaseRequestHistoryMacroStatusKey((short)'+convert(varchar(64), mic.ChaseRequestHistoryMacroStatusKey)+'); setChaseRequestHistoryMicroStatusName("'+ ChaseRequestHistoryMicroStatusName+'"); }};' 
	  FROM lookup.ChaseRequestHistoryMicroStatus mic join
	  lookup.ChaseRequestHistoryMacroStatus mac on
	  mic.ChaseRequestHistoryMacroStatusKey = mac.ChaseRequestHistoryMacroStatusKey	
	 */		
	
	public static final ChaseRequestHistoryMicroStatus NewMicroDefault = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 1001);
			setChaseRequestHistoryMacroStatusKey((short) 1);
			setChaseRequestHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestHistoryMicroStatus AboutToSendPatientDetailRequestToSourceDataMicroDefault = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 1031);
			setChaseRequestHistoryMacroStatusKey((short) 31);
			setChaseRequestHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestHistoryMicroStatus SendPatientDetailRequestToSourceDataCompletedMicroDefault = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 1034);
			setChaseRequestHistoryMacroStatusKey((short) 34);
			setChaseRequestHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestHistoryMicroStatus SendPatientDetailRequestToSourceDataFailedMicroDefault = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 1037);
			setChaseRequestHistoryMacroStatusKey((short) 37);
			setChaseRequestHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestHistoryMicroStatus AboutToSendCcdaRequestToSourceDataMicroDefault = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 1051);
			setChaseRequestHistoryMacroStatusKey((short) 51);
			setChaseRequestHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestHistoryMicroStatus SendCcdaRequestToSourceDataCompletedMicroDefault = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 1054);
			setChaseRequestHistoryMacroStatusKey((short) 54);
			setChaseRequestHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestHistoryMicroStatus SendCcdaRequestToSourceDataCompletedRequestCompletedWithException = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 1055);
			setChaseRequestHistoryMacroStatusKey((short) 54);
			setChaseRequestHistoryMicroStatusName("Request Completed With Exception");
		}
	};
	public static final ChaseRequestHistoryMicroStatus SendCcdaRequestToSourceDataCompletedRequestTimedOut = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 1056);
			setChaseRequestHistoryMacroStatusKey((short) 54);
			setChaseRequestHistoryMicroStatusName("Request Timed Out");
		}
	};
	public static final ChaseRequestHistoryMicroStatus SendCcdaRequestToSourceDataFailedMicroDefault = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 1057);
			setChaseRequestHistoryMacroStatusKey((short) 57);
			setChaseRequestHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestHistoryMicroStatus AboutToSendResultsToDestinationMicroDefault = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 1081);
			setChaseRequestHistoryMacroStatusKey((short) 81);
			setChaseRequestHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestHistoryMicroStatus SendResultsToDestinationCompletedMicroDefault = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 1084);
			setChaseRequestHistoryMacroStatusKey((short) 84);
			setChaseRequestHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestHistoryMicroStatus SendResultsToDestinationFailedMicroDefault = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 1087);
			setChaseRequestHistoryMacroStatusKey((short) 87);
			setChaseRequestHistoryMicroStatusName("Micro Default");
		}
	};
	public static final ChaseRequestHistoryMicroStatus EndedResultDeliveredToDestination = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 9991);
			setChaseRequestHistoryMacroStatusKey((short) 999);
			setChaseRequestHistoryMicroStatusName("Result Delivered To Destination");
		}
	};
	public static final ChaseRequestHistoryMicroStatus EndedInsuranceInformationDidNotMatchEarlyExit = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 9992);
			setChaseRequestHistoryMacroStatusKey((short) 999);
			setChaseRequestHistoryMicroStatusName("Insurance Information Did Not Match. Early Exit.");
		}
	};

	public static final ChaseRequestHistoryMicroStatus EndedEndedWithError = new ChaseRequestHistoryMicroStatus() {
		{
			setChaseRequestHistoryMicroStatusKey((short) 9993);
			setChaseRequestHistoryMacroStatusKey((short) 999);
			setChaseRequestHistoryMicroStatusName("Ended With Error");
		}
	};

	public static final Collection<ChaseRequestHistoryMicroStatus> AllEntries = Arrays.asList(NewMicroDefault,
			AboutToSendPatientDetailRequestToSourceDataMicroDefault,
			SendPatientDetailRequestToSourceDataCompletedMicroDefault,
			SendPatientDetailRequestToSourceDataFailedMicroDefault, AboutToSendCcdaRequestToSourceDataMicroDefault,
			SendCcdaRequestToSourceDataCompletedMicroDefault,
			SendCcdaRequestToSourceDataCompletedRequestCompletedWithException,
			SendCcdaRequestToSourceDataCompletedRequestTimedOut, SendCcdaRequestToSourceDataFailedMicroDefault,
			AboutToSendResultsToDestinationMicroDefault, SendResultsToDestinationCompletedMicroDefault,
			SendResultsToDestinationFailedMicroDefault, EndedResultDeliveredToDestination,
			EndedInsuranceInformationDidNotMatchEarlyExit, EndedEndedWithError);
}
