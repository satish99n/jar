package com.uhc.ucs.cdsm.domain.dictionaries;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistoryMacroStatus;

public class ChaseRequestGroupHistoryMacroStatusDictionary {

	/*
	Select 
	'
		public static final ChaseRequestGroupHistoryMacroStatus ' + REPLACE(ChaseRequestGroupHistoryMacroStatusName , ' ' , '')  +' = new ChaseRequestGroupHistoryMacroStatus() {{
			setChaseRequestGroupHistoryMacroStatusKey((short)'+convert(varchar(64), ChaseRequestGroupHistoryMacroStatusKey)+');
			setChaseRequestGroupHistoryMacroStatusName("'+ChaseRequestGroupHistoryMacroStatusName+'");
		}};
	'
	FROM lookup.ChaseRequestGroupHistoryMacroStatus 	
	*/

	public static final ChaseRequestGroupHistoryMacroStatus New = new ChaseRequestGroupHistoryMacroStatus() {
		{
			setChaseRequestGroupHistoryMacroStatusKey((short) 5);
			setChaseRequestGroupHistoryMacroStatusName("New");
		}
	};
	public static final ChaseRequestGroupHistoryMacroStatus AboutToSendBulkEncounterRequestToSourceData = new ChaseRequestGroupHistoryMacroStatus() {
		{
			setChaseRequestGroupHistoryMacroStatusKey((short) 15);
			setChaseRequestGroupHistoryMacroStatusName("About To Send Bulk Encounter Request To Source Data");
		}
	};
	public static final ChaseRequestGroupHistoryMacroStatus SendBulkEncounterRequestToSourceDataCompleted = new ChaseRequestGroupHistoryMacroStatus() {
		{
			setChaseRequestGroupHistoryMacroStatusKey((short) 25);
			setChaseRequestGroupHistoryMacroStatusName("Send Bulk Encounter Request To Source Data Completed");
		}
	};
	public static final ChaseRequestGroupHistoryMacroStatus SendBulkEncounterRequestToSourceDataFailed = new ChaseRequestGroupHistoryMacroStatus() {
		{
			setChaseRequestGroupHistoryMacroStatusKey((short) 26);
			setChaseRequestGroupHistoryMacroStatusName("Send Bulk Encounter Request To Source Data Failed");
		}
	};
	public static final ChaseRequestGroupHistoryMacroStatus PartiallyComplete = new ChaseRequestGroupHistoryMacroStatus() {
		{
			setChaseRequestGroupHistoryMacroStatusKey((short) 55);
			setChaseRequestGroupHistoryMacroStatusName("Partially Complete");
		}
	};
	public static final ChaseRequestGroupHistoryMacroStatus CompletedWithSomeErrors = new ChaseRequestGroupHistoryMacroStatus() {
		{
			setChaseRequestGroupHistoryMacroStatusKey((short) 105);
			setChaseRequestGroupHistoryMacroStatusName("Completed With Some Errors");
		}
	};
	public static final ChaseRequestGroupHistoryMacroStatus CompletedWithNoErrors = new ChaseRequestGroupHistoryMacroStatus() {
		{
			setChaseRequestGroupHistoryMacroStatusKey((short) 155);
			setChaseRequestGroupHistoryMacroStatusName("Completed With No Errors");
		}
	};
}
