package com.uhc.ucs.cdsm.domain.models;

import com.uhc.ucs.cdsm.domain.models.Encounter;

import java.util.Date;

public class EncounterInsurance {
	private long encounterInsuranceKey; /* PK */ 
	private int clinicalDataOriginKey;
	private long encounterKey;
	private short insuranceIdentifierType;
	private String insuranceIdentifier;
	private Date insertDate;
	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;
	
	/* Navigation properties */
	private Encounter parentEncounter;

	public long getEncounterInsuranceKey() {
		return encounterInsuranceKey;
	}

	public void setEncounterInsuranceKey(long encounterInsuranceKey) {
		this.encounterInsuranceKey = encounterInsuranceKey;
	}

	public int getClinicalDataOriginKey() {
		return clinicalDataOriginKey;
	}

	public void setClinicalDataOriginKey(int clinicalDataOriginKey) {
		this.clinicalDataOriginKey = clinicalDataOriginKey;
	}

	public long getEncounterKey() {
		return encounterKey;
	}

	public void setEncounterKey(long encounterKey) {
		this.encounterKey = encounterKey;
	}

	public short getInsuranceIdentifierType() {
		return insuranceIdentifierType;
	}

	public void setInsuranceIdentifierType(short insuranceIdentifierType) {
		this.insuranceIdentifierType = insuranceIdentifierType;
	}

	public String getInsuranceIdentifier() {
		return insuranceIdentifier;
	}

	public void setInsuranceIdentifier(String insuranceIdentifier) {
		this.insuranceIdentifier = insuranceIdentifier;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Encounter getParentEncounter() {
		return parentEncounter;
	}

	public void setParentEncounter(Encounter parentEncounter) {
		this.parentEncounter = parentEncounter;
	}
}