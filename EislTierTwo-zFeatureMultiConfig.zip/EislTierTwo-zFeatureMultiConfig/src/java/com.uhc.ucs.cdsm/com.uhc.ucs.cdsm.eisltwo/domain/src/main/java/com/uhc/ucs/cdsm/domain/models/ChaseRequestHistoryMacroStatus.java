package com.uhc.ucs.cdsm.domain.models;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

public class ChaseRequestHistoryMacroStatus {
	private short chaseRequestHistoryMacroStatusKey;
	private String chaseRequestHistoryMacroStatusName;
	private Date insertDate;
	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;
	
	private Collection<ChaseRequestHistoryMicroStatus> chaseRequestHistoryMicroStatuses;
	
	public ChaseRequestHistoryMacroStatus() {
		this.chaseRequestHistoryMicroStatuses = new ArrayList<>();
	}	

	public Collection<ChaseRequestHistoryMicroStatus> getChaseRequestHistoryMicroStatuses() {
		return chaseRequestHistoryMicroStatuses;
	}

	public void setChaseRequestHistoryMicroStatuses(
			Collection<ChaseRequestHistoryMicroStatus> chaseRequestHistoryMicroStatuses) {
		this.chaseRequestHistoryMicroStatuses = chaseRequestHistoryMicroStatuses;
	}

	public short getChaseRequestHistoryMacroStatusKey() {
		return chaseRequestHistoryMacroStatusKey;
	}

	public void setChaseRequestHistoryMacroStatusKey(short chaseRequestHistoryMacroStatusKey) {
		this.chaseRequestHistoryMacroStatusKey = chaseRequestHistoryMacroStatusKey;
	}

	public String getChaseRequestHistoryMacroStatusName() {
		return chaseRequestHistoryMacroStatusName;
	}

	public void setChaseRequestHistoryMacroStatusName(String chaseRequestHistoryMacroStatusName) {
		this.chaseRequestHistoryMacroStatusName = chaseRequestHistoryMacroStatusName;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
}
