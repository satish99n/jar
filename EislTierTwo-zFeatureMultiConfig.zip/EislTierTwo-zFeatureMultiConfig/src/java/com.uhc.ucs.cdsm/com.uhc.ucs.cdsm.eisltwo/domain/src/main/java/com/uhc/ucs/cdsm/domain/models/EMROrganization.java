package com.uhc.ucs.cdsm.domain.models;

import java.util.Date;

public class EMROrganization
{
private short eMROrganizationKey; /* PK */

private String eMROrganizationCode;

private String eMROrganizationName;

private Date insertDate;

private String createdBy;

private Date updatedDate;

private String updatedBy;

public short geteMROrganizationKey() {
	return eMROrganizationKey;
}

public void seteMROrganizationKey(short eMROrganizationKey) {
	this.eMROrganizationKey = eMROrganizationKey;
}

public String geteMROrganizationCode() {
	return eMROrganizationCode;
}

public void seteMROrganizationCode(String eMROrganizationCode) {
	this.eMROrganizationCode = eMROrganizationCode;
}

public String geteMROrganizationName() {
	return eMROrganizationName;
}

public void seteMROrganizationName(String eMROrganizationName) {
	this.eMROrganizationName = eMROrganizationName;
}

public Date getInsertDate() {
	return insertDate;
}

public void setInsertDate(Date insertDate) {
	this.insertDate = insertDate;
}

public String getCreatedBy() {
	return createdBy;
}

public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
}

public Date getUpdatedDate() {
	return updatedDate;
}

public void setUpdatedDate(Date updatedDate) {
	this.updatedDate = updatedDate;
}

public String getUpdatedBy() {
	return updatedBy;
}

public void setUpdatedBy(String updatedBy) {
	this.updatedBy = updatedBy;
}

}

