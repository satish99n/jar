package com.uhc.ucs.cdsm.domain.dictionaries;

import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSettingType;

public class ClinicalDataOriginSettingTypeDictionary {

	/*
		Select 
		'
			public static final ClinicalDataOriginSettingType ' +  REPLACE(REPLACE(ClinicalDataOriginSettingTypeName , ' ' , ''), '.', '')  +' = new ClinicalDataOriginSettingType() {{
				setClinicalDataOriginSettingTypeKey((short)'+convert(varchar(64), ClinicalDataOriginSettingTypeKey)+');
				setClinicalDataOriginSettingTypeName("'+ClinicalDataOriginSettingTypeName+'");
				setClinicalDataOriginSettingTypeDescription("'+ClinicalDataOriginSettingTypeDescription+'");
			}};
		'
		--		Select *
		FROM lookup.ClinicalDataOriginSettingType order by [ClinicalDataOriginSettingTypeKey]
	 */

	public static final ClinicalDataOriginSettingType ProviderGroupId = new ClinicalDataOriginSettingType() {
		{
			setClinicalDataOriginSettingTypeKey((short) 111);
			setClinicalDataOriginSettingTypeName("ProviderGroupId");
			setClinicalDataOriginSettingTypeDescription("Provider Group ID");
		}
	};

	public static final ClinicalDataOriginSettingType EmrStandardCode = new ClinicalDataOriginSettingType() {
		{
			setClinicalDataOriginSettingTypeKey((short) 122);
			setClinicalDataOriginSettingTypeName("EmrStandardCode");
			setClinicalDataOriginSettingTypeDescription("Standard Code for each EMR");
		}
	};

	public static final ClinicalDataOriginSettingType TransportProtocol = new ClinicalDataOriginSettingType() {
		{
			setClinicalDataOriginSettingTypeKey((short) 133);
			setClinicalDataOriginSettingTypeName("TransportProtocol");
			setClinicalDataOriginSettingTypeDescription("");
		}
	};

	public static final ClinicalDataOriginSettingType UnityProgramFhirEndpoint = new ClinicalDataOriginSettingType() {
		{
			setClinicalDataOriginSettingTypeKey((short) 201);
			setClinicalDataOriginSettingTypeName("Unity.Program.Fhir.Endpoint");
			setClinicalDataOriginSettingTypeDescription("Unity Program Fhir Endpoint");
		}
	};

	public static final ClinicalDataOriginSettingType UnityProgramUnityEndpoint = new ClinicalDataOriginSettingType() {
		{
			setClinicalDataOriginSettingTypeKey((short) 202);
			setClinicalDataOriginSettingTypeName("Unity.Program.Unity.Endpoint");
			setClinicalDataOriginSettingTypeDescription("Unity Program Unity Endpoint");
		}
	};

	public static final ClinicalDataOriginSettingType UnityProgramUnityUser = new ClinicalDataOriginSettingType() {
		{
			setClinicalDataOriginSettingTypeKey((short) 203);
			setClinicalDataOriginSettingTypeName("Unity.Program.Unity.User");
			setClinicalDataOriginSettingTypeDescription("Unity Program Unity User");
		}
	};

	public static final ClinicalDataOriginSettingType UnityProgramUnityPassword = new ClinicalDataOriginSettingType() {
		{
			setClinicalDataOriginSettingTypeKey((short) 204);
			setClinicalDataOriginSettingTypeName("Unity.Program.Unity.Password");
			setClinicalDataOriginSettingTypeDescription("Unity Program Unity Password");
		}
	};

	public static final ClinicalDataOriginSettingType UnityProgramSvcUser = new ClinicalDataOriginSettingType() {
		{
			setClinicalDataOriginSettingTypeKey((short) 205);
			setClinicalDataOriginSettingTypeName("Unity.Program.Svc.User");
			setClinicalDataOriginSettingTypeDescription("Unity Program Svc User");
		}
	};

	public static final ClinicalDataOriginSettingType UnityProgramSvcPassword = new ClinicalDataOriginSettingType() {
		{
			setClinicalDataOriginSettingTypeKey((short) 206);
			setClinicalDataOriginSettingTypeName("Unity.Program.Svc.Password");
			setClinicalDataOriginSettingTypeDescription("Unity Program Svc Password");
		}
	};

	public static final ClinicalDataOriginSettingType UnityProgramUnityAppname = new ClinicalDataOriginSettingType() {
		{
			setClinicalDataOriginSettingTypeKey((short) 207);
			setClinicalDataOriginSettingTypeName("Unity.Program.Unity.Appname");
			setClinicalDataOriginSettingTypeDescription("Unity Program Unity Appname");
		}
	};
}
