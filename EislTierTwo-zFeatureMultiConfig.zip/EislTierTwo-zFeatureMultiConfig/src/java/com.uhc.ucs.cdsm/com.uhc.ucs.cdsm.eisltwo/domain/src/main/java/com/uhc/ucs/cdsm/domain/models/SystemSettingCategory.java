package com.uhc.ucs.cdsm.domain.models;

import java.util.ArrayList;
import java.util.Collection;

public class SystemSettingCategory {
	
	private int systemSettingCategoryKey;
	private String systemSettingCategoryName;
	
	/* Navigation */
	private Collection<SystemSetting> systemSettings;
	
	public SystemSettingCategory()
	{
		this.systemSettings = new ArrayList<SystemSetting>();
	}
	

	public int getSystemSettingCategoryKey() {
		return systemSettingCategoryKey;
	}

	public void setSystemSettingCategoryKey(int systemSettingCategoryKey) {
		this.systemSettingCategoryKey = systemSettingCategoryKey;
	}

	public String getSystemSettingCategoryName() {
		return systemSettingCategoryName;
	}

	public void setSystemSettingCategoryName(String systemSettingCategoryName) {
		this.systemSettingCategoryName = systemSettingCategoryName;
	}
}
