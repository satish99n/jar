package com.uhc.ucs.cdsm.domain.models;

import java.util.Date;

public class EMRSystem
{
private short eMRSystemKey; /* PK */

private String eMRSystemCode;

private String eMRSystemName;

private short eMROrganizationKey;

private String eMRStandardCode;

private Date insertDate;

private String createdBy;

private Date updatedDate;

private String updatedBy;

public short geteMRSystemKey() {
	return eMRSystemKey;
}

public void seteMRSystemKey(short eMRSystemKey) {
	this.eMRSystemKey = eMRSystemKey;
}

public String geteMRSystemCode() {
	return eMRSystemCode;
}

public void seteMRSystemCode(String eMRSystemCode) {
	this.eMRSystemCode = eMRSystemCode;
}

public String geteMRSystemName() {
	return eMRSystemName;
}

public void seteMRSystemName(String eMRSystemName) {
	this.eMRSystemName = eMRSystemName;
}

public short geteMROrganizationKey() {
	return eMROrganizationKey;
}

public void seteMROrganizationKey(short eMROrganizationKey) {
	this.eMROrganizationKey = eMROrganizationKey;
}

public String geteMRStandardCode() {
	return eMRStandardCode;
}

public void seteMRStandardCode(String eMRStandardCode) {
	this.eMRStandardCode = eMRStandardCode;
}

public Date getInsertDate() {
	return insertDate;
}

public void setInsertDate(Date insertDate) {
	this.insertDate = insertDate;
}

public String getCreatedBy() {
	return createdBy;
}

public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
}

public Date getUpdatedDate() {
	return updatedDate;
}

public void setUpdatedDate(Date updatedDate) {
	this.updatedDate = updatedDate;
}

public String getUpdatedBy() {
	return updatedBy;
}

public void setUpdatedBy(String updatedBy) {
	this.updatedBy = updatedBy;
}

}

