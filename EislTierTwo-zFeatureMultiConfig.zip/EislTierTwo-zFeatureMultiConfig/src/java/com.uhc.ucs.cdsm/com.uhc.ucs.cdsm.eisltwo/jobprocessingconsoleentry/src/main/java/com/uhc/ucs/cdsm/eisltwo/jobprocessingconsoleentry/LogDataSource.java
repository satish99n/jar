package com.uhc.ucs.cdsm.eisltwo.jobprocessingconsoleentry;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class LogDataSource {
    
	 private static LogDataSource logDataSource = null;
	 public static final String ENVIRONMENT = "environment";
	 private Properties prop;
	 public  String environment;
	 
	 public static LogDataSource getInstance() {
        if (logDataSource == null) logDataSource = new LogDataSource();
        return logDataSource;
    }
	
	 public LogDataSource() {
		 environment = System.getProperty(ENVIRONMENT);
	}
	 
    public static Connection getConnection() throws SQLException,IOException {
	
    	String url = LogDataSource.getInstance().getProperty("LogDatabaseConnectionString");
		return DriverManager.getConnection(url);
		
    }
    
    public String getProperty(String key) throws IOException {
    	
    	if(prop==null) {
    		prop = new Properties();
    		prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("connection.properties"));
    	}
    	String value = ((environment==null || environment=="")?prop.getProperty(key):prop.getProperty(environment + "." + key));
		return value;
	}
}
