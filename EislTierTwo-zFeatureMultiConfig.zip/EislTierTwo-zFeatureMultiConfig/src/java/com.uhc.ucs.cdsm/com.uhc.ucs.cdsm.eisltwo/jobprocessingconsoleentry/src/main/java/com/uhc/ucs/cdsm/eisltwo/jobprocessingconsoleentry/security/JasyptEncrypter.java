package com.uhc.ucs.cdsm.eisltwo.jobprocessingconsoleentry.security;

import org.apache.commons.lang3.StringUtils;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

import com.uhc.ucs.cdsm.eisltwo.configuration.pbe.SystemInfoStringPBEConfig;

public class JasyptEncrypter {
	
	public static void main(String[] args) {
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		SystemInfoStringPBEConfig pk_generator = new SystemInfoStringPBEConfig();
		encryptor.setAlgorithm("PBEWithMD5AndDES");
		if(args.length < 1 || StringUtils.isAllBlank(args)) {
			System.out.println("Please pass text to encrypt");
			return;
		}
		
		String plainText = args[0];
		encryptor.setPasswordCharArray(pk_generator.getPasswordCharArray());
		String encryptedText = encryptor.encrypt(plainText);
		
		System.out.println("Input Text= " + plainText);
		System.out.println("encryptedText= ENC(" + encryptedText + ")");
	}

}
