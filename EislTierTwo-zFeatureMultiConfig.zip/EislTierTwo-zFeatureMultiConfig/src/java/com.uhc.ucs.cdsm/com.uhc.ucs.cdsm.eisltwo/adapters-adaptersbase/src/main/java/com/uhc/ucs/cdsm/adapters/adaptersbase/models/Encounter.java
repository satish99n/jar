package com.uhc.ucs.cdsm.adapters.adaptersbase.models;

//@JsonIgnoreProperties(ignoreUnknown = true)
public class Encounter {

    private String visitNumberExt;
    
    private String apptNumberEXT;

    private String encounterId;

    private String encounterStatus;
    
    private String appointmentTime;
    
    private String AppointmentLocation;

    private String organizationMRN;
    
    private Patient patient;
   
    public String getVisitNumberExt() {
        return visitNumberExt;
    }

    public void setVisitNumberExt(String visitNumberExt) {
        this.visitNumberExt = visitNumberExt;
    }

    public String getEncounterId() {
        return encounterId;
    }

    public void setEncounterId(String encounterId) {
        this.encounterId = encounterId;
    }

    public String getOrganizationMRN() {
        return organizationMRN;
    }

    public void setOrganizationMRN(String organizationMRN) {
        this.organizationMRN = organizationMRN;
    }

    public String getApptNumberEXT() {
        return apptNumberEXT;
    }

    public void setApptNumberEXT(String apptNumberEXT) {
        this.apptNumberEXT = apptNumberEXT;
    }


    public String getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public String getEncounterStatus() {
        return encounterStatus;
    }

    public void setEncounterStatus(String status) {
        this.encounterStatus = status;
    }

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public String getAppointmentLocation() {
		return AppointmentLocation;
	}

	public void setAppointmentLocation(String appointmentLocation) {
		AppointmentLocation = appointmentLocation;
	}

	   
}
