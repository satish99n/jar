package com.uhc.ucs.cdsm.adapters.adaptersbase.interfaces;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.DocumentWrapper;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Patient;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;

public interface IClinicalAdapter {

    List<Encounter> getEncounters(Date fromDate, Date toDate, Collection<ClinicalDataOriginSetting> originSettings) throws ClinicalDataException;

    Patient getPatientDetails(String patientID, Collection<ClinicalDataOriginSetting> originSettings) throws ClinicalDataException;

    DocumentWrapper getCCDA(String patientID, String encounterID, Collection<ClinicalDataOriginSetting> originSettings) throws ClinicalDataException;
}
