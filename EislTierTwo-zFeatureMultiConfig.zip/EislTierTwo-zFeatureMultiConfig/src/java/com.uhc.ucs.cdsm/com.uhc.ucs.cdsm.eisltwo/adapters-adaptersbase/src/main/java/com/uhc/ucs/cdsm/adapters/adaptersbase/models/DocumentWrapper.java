package com.uhc.ucs.cdsm.adapters.adaptersbase.models;

import java.util.Date;

public class DocumentWrapper {

	 private byte[] document;
	 private String encounterID;
	 private Date documentCreationTime;

	public Date getDocumentCreationTime() {
		return documentCreationTime;
	}

	public void setDocumentCreationTime(Date documentCreationTime) {
		this.documentCreationTime = documentCreationTime;
	}

	public String getEncounterID() {
		return encounterID;
	}

	public void setEncounterID(String encounterID) {
		this.encounterID = encounterID;
	}

	public byte[] getDocument() {
		return document;
	}

	public void setDocument(byte[] document) {
		this.document = document;
	}
}
