package com.uhc.ucs.cdsm.eisltwo.exportservices.sftpexportservice;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ftpserver.ftplet.FtpException;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class SFTPService {
	
	private Log logger = null;
	
	public SFTPService() {
		this.logger = LogFactory.getLog(SFTPService.class);
	}
	
	public SFTPService(Log lgr)
	{
		this.logger = lgr;
	}	
	
	/**
	 * Method used to make SFTP connection and then write to file in remote
	 * directory
	 * 
	 * @param ftp
	 * @throws SftpException
	 * @throws IOException
	 * @throws JSchException
	 * @throws FTPException
	 */
	public void writeViaSFTP(FTPInformation ftp) throws SftpException, JSchException, FtpException, IOException {

		InputStream stream = null;
		try {
			Session session = createSession(ftp);
			ChannelSftp sftpChannel = createChannel(session, ftp.getFileDestination());
			sftpChannel.cd(ftp.getFileDestination());
			stream = ftp.getInputStream();
			// local file,destination fileName
			sftpChannel.put(stream, ftp.getFilePattern());
			sftpChannel.exit();
			session.disconnect();
		} finally {
			if (stream != null)
					stream.close();
		}
	}

	/**
	 * Validate the FTP information provided and then create the session
	 * 
	 * @param ftp
	 * @return
	 * @throws JSchException
	 * @throws FTPException
	 */
	public Session createSession(FTPInformation ftp) throws JSchException, FtpException {
		if ((ftp.getHostName() == null || ftp.getHostName().isEmpty())
				|| (ftp.getUsername() == null || ftp.getUsername().isEmpty())
				|| (ftp.getPassword() == null || ftp.getPassword().isEmpty())) {
			
			String lgrMsg = String.format("Missing information to connect to host. (HostName='%1s', Username='%2s', Password.LENGTH='%3s'')", ftp.getHostName(), ftp.getUsername(), ftp.getPassword().length());
			this.logger.error(lgrMsg);
			throw new FtpException(lgrMsg);
		}
		
		JSch jsch = new JSch();
		Session session = jsch.getSession(ftp.getUsername(), ftp.getHostName(), ftp.getPort());
		// Session session =
		// jsch.getSession(ftp.getUsername(),ftp.getHostName(),ftp.getPort());
		session.setConfig("StrictHostKeyChecking", "no");
		session.setPassword(ftp.getPassword());
		session.connect();
		return session;
	}

	/**
	 * create SFTP channel and validate remote location
	 * 
	 * @param session
	 * @param remoteDir
	 * @return
	 * @throws JSchException
	 * @throws SftpException
	 * @throws FTPException
	 */
	public ChannelSftp createChannel(Session session, String remoteDir)
			throws JSchException, SftpException, FtpException {
		Channel channel = session.openChannel("sftp");
		ChannelSftp sftpChannel = (ChannelSftp) channel;
		sftpChannel.connect();
		try {

			sftpChannel.stat(remoteDir);

		} catch (SftpException e) {
			/*
			 * sftpChannel.mkdir("c:\\temp"); sftpChannel.cd("sftpnew");
			 */
			String lgrMsg = String.format("Remote directory doesn't exist. (RemoteDir='%1s')", remoteDir);
			this.logger.error(lgrMsg);
			throw new FtpException(lgrMsg, e);
		}
		return sftpChannel;
	}

}
