package com.uhc.ucs.cdsm.eisltwo.webclient.console;

import com.microsoft.windowsazure.exception.ServiceException;

import com.uhc.ucs.cdsm.eisltwo.clientproxies.interfaces.IExampleProxy;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.QueueMessageSender;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.interfaces.IQueueMessageSender;
import com.uhc.ucs.cdsm.eisltwo.clientproxies.ExampleProxy;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class App {

	private static Log log = LogFactory.getLog(App.class);

	public static void main(String[] args) {
		log.info("Hello World!");

		try {
			//RunExampleProxy(log);
			RunServiceBusSample(log);
		} catch (Exception ex) {
			Throwable thr = ex;
			while (null != thr) {
				System.out.println(ex.getMessage());
				thr = thr.getCause();
			}
		}
	}

	private static void RunServiceBusSample(Log log) {
		try {
			String connectionString = "Endpoint=sb://shh001-servicebus-name.servicebus.windows.net/;SharedAccessKeyName=sendrule;SharedAccessKey=ZyHLzotvSZkyOEGE1mUfOhIAw5oAQJp/KqjPtFvocD0=;EntityPath=queueone";
			String queueName = "queueone";
			String payload = "hello" + new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss", Locale.US).format(new Date());
			;

			IQueueMessageSender<String> qms = new QueueMessageSender(log);
			qms.sendMessage(connectionString, queueName, payload);
		} catch (ServiceException ex) {
			Throwable thr = ex;
			while (null != thr) {
				System.out.println(ex.getMessage());
				thr = thr.getCause();
			}
		}
	}

	private static void RunExampleProxy(Log log) {
		IExampleProxy ep = new ExampleProxy(log);
		String result = ep.examplePerformGet();
		System.out.println(result);
	}
}
