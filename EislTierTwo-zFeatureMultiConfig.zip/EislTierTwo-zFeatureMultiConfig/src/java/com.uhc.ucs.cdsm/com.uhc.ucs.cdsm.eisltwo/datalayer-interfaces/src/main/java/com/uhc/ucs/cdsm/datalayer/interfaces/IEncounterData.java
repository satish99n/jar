package com.uhc.ucs.cdsm.datalayer.interfaces;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.function.Function;

import com.uhc.ucs.cdsm.domain.models.Encounter;

public interface IEncounterData {
    Encounter updateSingle(Encounter pojo, Function<ResultSet, Encounter> handleResultSetFunction) throws SQLException;

    void insertInsuranceHistoryDistinct(String primaryInsuranceIdentifier, String secondaryInsuranceIdentifier,
            String tertiaryInsuranceIdentifier, String quartaneryInsuranceIdentifier, String quinaryInsuranceIdentifier,int clinicalDataOriginKey,Function<ResultSet, Encounter> handleResultSetFunction)
            throws SQLException;

}
