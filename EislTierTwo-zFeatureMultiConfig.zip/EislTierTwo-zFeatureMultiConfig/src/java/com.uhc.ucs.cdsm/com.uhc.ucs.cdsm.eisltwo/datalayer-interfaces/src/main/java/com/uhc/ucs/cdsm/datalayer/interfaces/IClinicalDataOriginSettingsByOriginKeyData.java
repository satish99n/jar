package com.uhc.ucs.cdsm.datalayer.interfaces;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.function.Function;

import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;

public interface IClinicalDataOriginSettingsByOriginKeyData {

    Collection<ClinicalDataOriginSetting> getClinicalDataOriginSecureSettings(int clinicalDataOriginKey,
            Function<ResultSet, Collection<ClinicalDataOriginSetting>> handleResultSetFunction) throws SQLException;

}
