package com.uhc.ucs.cdsm.datalayer.interfaces;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.UUID;

import com.uhc.ucs.cdsm.domain.models.ClinicalDataOrigin;

public interface IInstanceToDataOriginLinkData {

    Collection<ClinicalDataOrigin> getClinicalDataOriginLinks(UUID deploymentInstanceUuid,
            TwoParameterFunction<CallableStatement, ResultSet, Collection<ClinicalDataOrigin>> handleResultSetFunction) throws SQLException;

}
