package com.uhc.ucs.cdsm.datalayer.interfaces;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.function.Function;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistory;

public interface IChaseRequestGroupHistoryData {
	ChaseRequestGroupHistory InsertSingle(ChaseRequestGroupHistory pojo, Function<ResultSet, ChaseRequestGroupHistory> handleResultSetFunction) throws SQLException;
}
