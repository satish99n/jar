package com.uhc.ucs.cdsm.datalayer.interfaces;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.function.Function;

import com.uhc.ucs.cdsm.domain.models.SystemSetting;

public interface ISystemSettingData {
	Collection<SystemSetting> GetSystemSettingByCategoryKey(int systemSettingCategoryKey, Function<ResultSet, Collection<SystemSetting>> handleResultSetFunction)
			throws SQLException;
}
