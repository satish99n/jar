package com.uhc.ucs.cdsm.datalayer.interfaces;

@FunctionalInterface
public interface TwoParameterFunction<T, U, R> {
    public R apply(T t, U u);
}
