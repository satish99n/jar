package com.uhc.ucs.cdsm.datalayer.interfaces;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.function.Function;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistory;

public interface IChaseRequestHistoryData {
    ChaseRequestHistory InsertSingle(ChaseRequestHistory pojo,
            Function<ResultSet, ChaseRequestHistory> handleResultSetFunction) throws SQLException;

    Collection<ChaseRequestGroup> insertMultiple(Collection<ChaseRequestHistory> crhs,
            Function<ResultSet, Collection<ChaseRequestGroup>> handleResultSetFunction) throws SQLException;
}
