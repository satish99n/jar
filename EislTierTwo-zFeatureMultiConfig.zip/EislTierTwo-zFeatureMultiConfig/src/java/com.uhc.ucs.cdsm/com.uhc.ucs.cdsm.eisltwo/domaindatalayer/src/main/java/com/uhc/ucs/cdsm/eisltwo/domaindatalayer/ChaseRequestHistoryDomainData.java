package com.uhc.ucs.cdsm.eisltwo.domaindatalayer;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.datalayer.interfaces.IChaseRequestHistoryData;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistory;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IChaseRequestHistoryDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.chaserequestgroupserializers.ChaseRequestGroupDefaultSerializer;

public class ChaseRequestHistoryDomainData implements IChaseRequestHistoryDomainData {

    private final Log logger;
    private final IChaseRequestHistoryData chaseRequestHistoryData;

    public ChaseRequestHistoryDomainData(Log lgr, IChaseRequestHistoryData icrhd) {

        if (null == lgr) {
            throw new IllegalArgumentException("Log is null");
        }

        if (null == icrhd) {
            throw new IllegalArgumentException("IChaseRequestHistoryData");
        }

        this.logger = lgr;
        this.chaseRequestHistoryData = icrhd;
    }

    public ChaseRequestHistoryDomainData(IChaseRequestHistoryData icrhd) {

        if (null == icrhd) {
            throw new IllegalArgumentException("IChaseRequestHistoryData");
        }

        this.logger = LogFactory.getLog(ChaseRequestHistoryDomainData.class);;
        this.chaseRequestHistoryData = icrhd;
    }

    public void InsertChaseRequestHistory(ChaseRequestHistory pojo) throws Exception {
        this.chaseRequestHistoryData.InsertSingle(pojo, null);
    }

    @Override
    public Collection<ChaseRequestGroup> insertBulkChaseRequest(Collection<ChaseRequestHistory> crhs) throws Exception {
        Collection<ChaseRequestGroup> returnItems = this.chaseRequestHistoryData.insertMultiple(crhs, this::HandleBulkChaseRequestHistoryInserts);
        return returnItems;
    }

    private Collection<ChaseRequestGroup> HandleBulkChaseRequestHistoryInserts(ResultSet rs){
        Collection<ChaseRequestGroup> returnItem = null;
        try {
            returnItem = new ChaseRequestGroupDefaultSerializer().serializeCollection(rs);
        } catch (SQLException e) {
            this.logger.error(e.getMessage(), e);
            throw new RuntimeException(e);
        }

        return returnItem;
    }

}
