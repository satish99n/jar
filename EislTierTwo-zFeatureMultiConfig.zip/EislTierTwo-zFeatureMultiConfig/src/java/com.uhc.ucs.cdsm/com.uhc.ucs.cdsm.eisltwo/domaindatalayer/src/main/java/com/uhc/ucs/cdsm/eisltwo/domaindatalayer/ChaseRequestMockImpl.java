package com.uhc.ucs.cdsm.eisltwo.domaindatalayer;

import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.datalayer.interfaces.IChaseRequestHistoryData;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistory;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IChaseRequestHistoryDomainData;

public class ChaseRequestMockImpl implements IChaseRequestHistoryDomainData {

    private final Log logger;
    private final IChaseRequestHistoryData chaseRequestHistoryData;

    public ChaseRequestMockImpl(Log lgr, IChaseRequestHistoryData icrhd) {
        if (null == lgr) {
            throw new IllegalArgumentException("Log is null");
        }

        if (null == icrhd) {
            throw new IllegalArgumentException("IChaseRequestHistoryData");
        }

        this.logger = lgr;
        this.chaseRequestHistoryData = icrhd;
    }
    public ChaseRequestMockImpl(IChaseRequestHistoryData icrhd) {

        if (null == icrhd) {
            throw new IllegalArgumentException("IChaseRequestHistoryData");
        }
        logger = LogFactory.getLog(ChaseRequestMockImpl.class);
        this.chaseRequestHistoryData = icrhd;
    }

    @Override
    public void InsertChaseRequestHistory(ChaseRequestHistory pojo) throws Exception {
        logger.debug("received ChaseRequest "+pojo.toString());
    }
    @Override
    public Collection<ChaseRequestGroup> insertBulkChaseRequest(Collection<ChaseRequestHistory> crhs) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

}
