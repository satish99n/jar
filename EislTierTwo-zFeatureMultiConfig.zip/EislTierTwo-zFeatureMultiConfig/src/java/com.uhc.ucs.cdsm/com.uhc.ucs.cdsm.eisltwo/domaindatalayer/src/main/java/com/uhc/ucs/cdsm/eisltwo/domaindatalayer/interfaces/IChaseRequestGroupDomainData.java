package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;

public interface IChaseRequestGroupDomainData {
	ChaseRequestGroup upsertSingle(ChaseRequestGroup pojo) throws Exception;
	ChaseRequestGroup retrieveSingle(long chaseRequestGroupKey) throws Exception;
}
