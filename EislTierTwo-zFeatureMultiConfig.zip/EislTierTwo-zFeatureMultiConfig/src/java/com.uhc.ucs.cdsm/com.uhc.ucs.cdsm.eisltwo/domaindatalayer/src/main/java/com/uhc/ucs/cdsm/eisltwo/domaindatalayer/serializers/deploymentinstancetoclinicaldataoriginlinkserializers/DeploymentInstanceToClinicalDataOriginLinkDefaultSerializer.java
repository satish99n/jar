package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.deploymentinstancetoclinicaldataoriginlinkserializers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.ucs.cdsm.domain.models.DeploymentInstanceToClinicalDataOriginLink;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.deploymentinstancetoclinicaldataoriginlinklayouts.DeploymentInstanceToClinicalDataOriginLinkDefaultLayout;

// .serializers.deploymentinstancetoclinicaldataoriginlinkserializers
public class DeploymentInstanceToClinicalDataOriginLinkDefaultSerializer{
public DeploymentInstanceToClinicalDataOriginLink serializeSingle(ResultSet rs) throws SQLException
{
List<DeploymentInstanceToClinicalDataOriginLink> items = this.serializeCollection(rs);
DeploymentInstanceToClinicalDataOriginLink returnItem = items.stream().findFirst().orElse(null);
return returnItem;
}

public List <DeploymentInstanceToClinicalDataOriginLink> serializeCollection(ResultSet rs) throws SQLException {
DeploymentInstanceToClinicalDataOriginLink item;
List<DeploymentInstanceToClinicalDataOriginLink> returnCollection = new ArrayList<DeploymentInstanceToClinicalDataOriginLink>();
if (null != rs) {
while (rs.next()) {
item = new DeploymentInstanceToClinicalDataOriginLink();
item.setDeploymentInstanceKey(rs.getInt(DeploymentInstanceToClinicalDataOriginLinkDefaultLayout.DeploymentInstanceKey));

item.setClinicalDataOriginKey(rs.getInt(DeploymentInstanceToClinicalDataOriginLinkDefaultLayout.ClinicalDataOriginKey));

item.setInsertDate(rs.getDate(DeploymentInstanceToClinicalDataOriginLinkDefaultLayout.InsertDate));

item.setCreatedBy(rs.getString(DeploymentInstanceToClinicalDataOriginLinkDefaultLayout.CreatedBy));

item.setUpdatedDate(rs.getDate(DeploymentInstanceToClinicalDataOriginLinkDefaultLayout.UpdatedDate));

item.setUpdatedBy(rs.getString(DeploymentInstanceToClinicalDataOriginLinkDefaultLayout.UpdatedBy));

item.setMacroStatusKey(rs.getShort(DeploymentInstanceToClinicalDataOriginLinkDefaultLayout.MacroStatusKey));

item.setPriorityOrdinal(rs.getShort(DeploymentInstanceToClinicalDataOriginLinkDefaultLayout.PriorityOrdinal));

returnCollection.add(item);
}
}

return returnCollection;
}
}

