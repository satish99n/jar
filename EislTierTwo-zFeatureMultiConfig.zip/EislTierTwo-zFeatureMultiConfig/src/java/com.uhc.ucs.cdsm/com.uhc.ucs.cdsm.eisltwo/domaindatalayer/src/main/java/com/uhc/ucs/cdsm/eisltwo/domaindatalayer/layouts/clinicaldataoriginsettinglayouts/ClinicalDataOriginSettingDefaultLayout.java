package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.clinicaldataoriginsettinglayouts;

//.layouts.clinicaldataoriginsettinglayouts
public final class ClinicalDataOriginSettingDefaultLayout {
    // public static final int ClinicalDataOriginSettingKey = 1;
    public static final int ClinicalDataOriginKey = 1;
    public static final int ClinicalDataOriginSettingTypeKey = 2;
    public static final int ClinicalDataOriginSettingTypeName = 3;
    // public static final int ClinicalDataOriginSettingKeyDescription = 4;
    public static final int ClinicalDataOriginSettingValue = 4;
    /*
     * public static final int InsertDate = 6; public static final int InsertedBy =
     * 7; public static final int LastUpdated = 8; public static final int
     * LastUpdatedBy = 9;
     */
}
