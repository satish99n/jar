package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.emrorganizationlayouts;

//.layouts.emrorganizationlayouts
public final class EMROrganizationDefaultLayout
{
public static final int EMROrganizationKey = 1;
public static final int EMROrganizationCode = 2;
public static final int EMROrganizationName = 3;
public static final int InsertDate = 4;
public static final int CreatedBy = 5;
public static final int UpdatedDate = 6;
public static final int UpdatedBy = 7;
}

