package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.clinicaldataoriginlayouts;

//.layouts.clinicaldataoriginlayouts
public final class ClinicalDataOriginDefaultLayout
{
public static final int ClinicalDataOriginKey = 1;
public static final int ClinicalDataOriginCode = 2;
public static final int ClinicalDataOriginName = 3;
public static final int ClinicalDataOriginDisplayName = 4;
public static final int ClinicalAdapterConcreteName = 5;
public static final int EMRSystemKey = 6;
public static final int MacroStatus = 7;
public static final int StartDate = 8;
public static final int InsertDate = 9;
public static final int CreatedBy = 10;
public static final int UpdatedDate = 11;
public static final int UpdatedBy = 12;
}

