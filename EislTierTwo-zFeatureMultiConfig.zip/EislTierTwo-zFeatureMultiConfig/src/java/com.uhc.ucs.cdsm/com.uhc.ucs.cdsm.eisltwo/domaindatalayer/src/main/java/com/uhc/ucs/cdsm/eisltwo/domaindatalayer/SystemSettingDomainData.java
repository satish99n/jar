package com.uhc.ucs.cdsm.eisltwo.domaindatalayer;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.datalayer.interfaces.ISystemSettingData;
import com.uhc.ucs.cdsm.domain.models.SystemSetting;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.ISystemSettingDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.systemsettingserializers.SystemSettingDefaultSerializer;

public class SystemSettingDomainData implements ISystemSettingDomainData {

	private final Log logger;
	private final ISystemSettingData systemSettingData;

	public SystemSettingDomainData(Log lgr, ISystemSettingData issd) {

		if (null == lgr) {
			throw new IllegalArgumentException("Log is null");
		}

		if (null == issd) {
			throw new IllegalArgumentException("ISystemSettingData");
		}

		this.logger = lgr;
		this.systemSettingData = issd;
	}
	
	public SystemSettingDomainData(ISystemSettingData issd) {

		if (null == issd) {
			throw new IllegalArgumentException("ISystemSettingData");
		}

		this.logger = LogFactory.getLog(SystemSettingDomainData.class);
		this.systemSettingData = issd;
	}

	public Collection<SystemSetting> GetSystemSettingByCategoryKey(int systemSettingCategoryKey) throws Exception {
		Collection<SystemSetting> returnItems = null;
		returnItems = this.systemSettingData.GetSystemSettingByCategoryKey(systemSettingCategoryKey,
				this::HandleSystemSettingResultSet);
		return returnItems;
	}

	private Collection<SystemSetting> HandleSystemSettingResultSet(ResultSet rs) {
		Collection<SystemSetting> returnItems = null;
		try {
			returnItems = new SystemSettingDefaultSerializer().serializeCollection(rs);
		} catch (SQLException e) {
			this.logger.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}

		return returnItems;
	}

}
