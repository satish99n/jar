package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.deploymentinstanceserializers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.uhc.ucs.cdsm.domain.models.DeploymentInstance;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.deploymentinstancelayouts.DeploymentInstanceDefaultLayout;

// .serializers.deploymentinstanceserializers
public class DeploymentInstanceDefaultSerializer
{
public DeploymentInstance serializeSingle(ResultSet rs) throws SQLException
{
List<DeploymentInstance> items = this.serializeCollection(rs);
DeploymentInstance returnItem = items.stream().findFirst().orElse(null);
return returnItem;
}

public List <DeploymentInstance> serializeCollection(ResultSet rs) throws SQLException {
DeploymentInstance item;
List<DeploymentInstance> returnCollection = new ArrayList<DeploymentInstance>();
if (null != rs) {
while (rs.next()) {
item = new DeploymentInstance();
item.setDeploymentInstanceKey(rs.getInt(DeploymentInstanceDefaultLayout.DeploymentInstanceKey));

item.setDeploymentInstanceUuid( UUID.fromString(rs.getString(DeploymentInstanceDefaultLayout.DeploymentInstanceUuID)));

item.setMachineName(rs.getString(DeploymentInstanceDefaultLayout.MachineName));

item.setInstanceName(rs.getString(DeploymentInstanceDefaultLayout.InstanceName));

item.setMacroStatusKey(rs.getShort(DeploymentInstanceDefaultLayout.MacroStatus));

item.setInsertDate(rs.getDate(DeploymentInstanceDefaultLayout.InsertDate));

item.setCreatedBy(rs.getString(DeploymentInstanceDefaultLayout.CreatedBy));

item.setUpdatedDate(rs.getDate(DeploymentInstanceDefaultLayout.UpdatedDate));

item.setUpdatedBy(rs.getString(DeploymentInstanceDefaultLayout.UpdatedBy));

returnCollection.add(item);
}
}

return returnCollection;
}
}
