package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces;

import java.util.Collection;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistory;

public interface IChaseRequestHistoryDomainData {

    void InsertChaseRequestHistory(ChaseRequestHistory pojo) throws Exception;
    Collection<ChaseRequestGroup> insertBulkChaseRequest(Collection<ChaseRequestHistory> crhs) throws Exception;

}
