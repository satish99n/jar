package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces;

import java.util.Collection;

import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;

public interface IClinicalDataOriginSettingsByOriginKeyDomainData {
    Collection<ClinicalDataOriginSetting> getClinicalDataOriginSecureSettings(int clinicalDataOriginKey)
            throws Exception;
}
