package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.chaserequestserializers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.ucs.cdsm.domain.models.ChaseRequest;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.chaserequestlayouts.ChaseRequestDefaultLayout;

public class ChaseRequestDefaultSerializer {
	public ChaseRequest serializeSingle(ResultSet rs) throws SQLException {
		List<ChaseRequest> items = this.serializeCollection(rs);
		ChaseRequest returnItem = items.stream().findFirst().orElse(null);
		return returnItem;
	}

	public List<ChaseRequest> serializeCollection(ResultSet rs) throws SQLException {
		ChaseRequest item;
		List<ChaseRequest> returnCollection = new ArrayList<ChaseRequest>();
		if (null != rs) {
			while (rs.next()) {
				item = new ChaseRequest();
				item.setChaseRequestKey(rs.getLong(ChaseRequestDefaultLayout.ChaseRequestKey));
				item.setChaseRequestGroupKey(rs.getLong(ChaseRequestDefaultLayout.ChaseRequestGroupKey));
				item.setEncounterKey(rs.getLong(ChaseRequestDefaultLayout.EncounterKey));
				item.setInsertDate(rs.getDate(ChaseRequestDefaultLayout.InsertDate));
				item.setInsertedBy(rs.getString(ChaseRequestDefaultLayout.InsertedBy));
				item.setLastUpdated(rs.getDate(ChaseRequestDefaultLayout.LastUpdated));
				item.setLastUpdatedBy(rs.getString(ChaseRequestDefaultLayout.LastUpdatedBy));
				item.setClinicalDataOriginKey(rs.getInt(ChaseRequestDefaultLayout.ChaseRequestGroupKey));
				returnCollection.add(item);
			}
		}
		return returnCollection;
	}
}