package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.clinicaldataoriginsecuresettingserializers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSecureSetting;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.clinicaldataoriginsecuresettinglayouts.ClinicalDataOriginSecureSettingDefaultLayout;

// .serializers.clinicaldataoriginsecuresettingserializers
public class ClinicalDataOriginSecureSettingDefaultSerializer
{
public ClinicalDataOriginSecureSetting serializeSingle(ResultSet rs) throws SQLException
{
List<ClinicalDataOriginSecureSetting> items = this.serializeCollection(rs);
ClinicalDataOriginSecureSetting returnItem = items.stream().findFirst().orElse(null);
return returnItem;
}

public List <ClinicalDataOriginSecureSetting> serializeCollection(ResultSet rs) throws SQLException {
ClinicalDataOriginSecureSetting item;
List<ClinicalDataOriginSecureSetting> returnCollection = new ArrayList<ClinicalDataOriginSecureSetting>();
if (null != rs) {
while (rs.next()) {
item = new ClinicalDataOriginSecureSetting();
item.setClinicalDataOriginSecureSettingKey(rs.getInt(ClinicalDataOriginSecureSettingDefaultLayout.ClinicalDataOriginSecureSettingKey));

item.setClinicalDataOriginKey(rs.getInt(ClinicalDataOriginSecureSettingDefaultLayout.ClinicalDataOriginKey));

item.setClinicalDataOriginSecureSettingKeyName(rs.getString(ClinicalDataOriginSecureSettingDefaultLayout.ClinicalDataOriginSecureSettingKeyName));

item.setClinicalDataOriginSecureSettingKeyDescription(rs.getString(ClinicalDataOriginSecureSettingDefaultLayout.ClinicalDataOriginSecureSettingKeyDescription));

item.setClinicalDataOriginSecureSettingKeyValue(rs.getBytes(ClinicalDataOriginSecureSettingDefaultLayout.ClinicalDataOriginSecureSettingKeyValue));

item.setInsertDate(rs.getDate(ClinicalDataOriginSecureSettingDefaultLayout.InsertDate));

item.setInsertedBy(rs.getString(ClinicalDataOriginSecureSettingDefaultLayout.InsertedBy));

item.setLastUpdated(rs.getDate(ClinicalDataOriginSecureSettingDefaultLayout.LastUpdated));

item.setLastUpdatedBy(rs.getString(ClinicalDataOriginSecureSettingDefaultLayout.LastUpdatedBy));

returnCollection.add(item);
}
}

return returnCollection;
}
}

