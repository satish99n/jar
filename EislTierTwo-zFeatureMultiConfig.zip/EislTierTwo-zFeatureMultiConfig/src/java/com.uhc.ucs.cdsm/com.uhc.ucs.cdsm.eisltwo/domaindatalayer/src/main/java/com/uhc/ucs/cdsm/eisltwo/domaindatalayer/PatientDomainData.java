package com.uhc.ucs.cdsm.eisltwo.domaindatalayer;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.datalayer.interfaces.IPatientData;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.Patient;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IPatientDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.chaserequestgroupserializers.ChaseRequestGroupDefaultSerializer;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.patientserializers.PatientDefaultSerializer;

public class PatientDomainData implements IPatientDomainData {

	private final Log logger;
	private final IPatientData patientData;

	public PatientDomainData(Log lgr, IPatientData ipd) {

		if (null == lgr) {
			throw new IllegalArgumentException("Log is null");
		}

		if (null == ipd) {
			throw new IllegalArgumentException("IPatientAdapter");
		}

		this.logger = lgr;
		this.patientData = ipd;
	}
	
	public PatientDomainData(IPatientData ipd) {
		if (null == ipd) {
			throw new IllegalArgumentException("IPatientAdapter");
		}

		this.logger = LogFactory.getLog(PatientDomainData.class);
		this.patientData = ipd;
	}

	@Override
	public Patient GetPatientByKey(long patientKey) throws Exception {
		Patient returnItem = null;
		returnItem = this.patientData.GetSinglePatientByKey(patientKey, this::HandlePatientResultSet);
		return returnItem;
	}

	private Patient HandlePatientResultSet(ResultSet rs) {
		Patient returnItem = null;
		try {
			returnItem = new PatientDefaultSerializer().serializeSingle(rs);
		} catch (SQLException e) {
			this.logger.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}

		return returnItem;
	}

	@Override
	public Collection<ChaseRequestGroup> UpsertPatientsAndEncounters(Collection<Patient> patients) throws Exception {

		Collection<ChaseRequestGroup> returnItems = null;

		try {
			returnItems = this.patientData.UpsertPatientsAndEncounters(patients, this::HandleUpsertPatientsAndEncountersResultSet);
		} catch (SQLException e) {
			this.logger.error(e.getMessage(), e);
			throw new Exception(e);
		}
		
		return returnItems;

	}
	
	private Collection<ChaseRequestGroup> HandleUpsertPatientsAndEncountersResultSet(ResultSet rs) {
		Collection<ChaseRequestGroup> returnItem = null;
		try {
			returnItem = new ChaseRequestGroupDefaultSerializer().serializeCollection(rs);
		} catch (SQLException e) {
			this.logger.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}

		return returnItem;
	}
	
	
}
