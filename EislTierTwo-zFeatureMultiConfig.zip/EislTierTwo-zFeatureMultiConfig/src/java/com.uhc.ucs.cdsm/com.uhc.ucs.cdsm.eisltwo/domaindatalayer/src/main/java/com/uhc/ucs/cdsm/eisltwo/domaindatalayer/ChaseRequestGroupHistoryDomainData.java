package com.uhc.ucs.cdsm.eisltwo.domaindatalayer;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.datalayer.interfaces.IChaseRequestGroupHistoryData;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistory;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IChaseRequestGroupHistoryDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.chaserequestgrouphistoryserializers.ChaseRequestGroupHistoryDefaultSerializer;

public class ChaseRequestGroupHistoryDomainData implements IChaseRequestGroupHistoryDomainData {
	private final Log logger;
	private final IChaseRequestGroupHistoryData chaseRequestGroupHistoryData;

	public ChaseRequestGroupHistoryDomainData(Log lgr, IChaseRequestGroupHistoryData icrghd) {

		if (null == lgr) {
			throw new IllegalArgumentException("Log is null");
		}

		if (null == icrghd) {
			throw new IllegalArgumentException("IChaseRequestGroupHistoryData");
		}

		this.logger = lgr;
		this.chaseRequestGroupHistoryData = icrghd;
	}
	
	public ChaseRequestGroupHistoryDomainData(IChaseRequestGroupHistoryData icrghd) {
		this.chaseRequestGroupHistoryData = icrghd;
		this.logger = LogFactory.getLog(ChaseRequestGroupHistoryDomainData.class);
	}
	
	@Override
	public ChaseRequestGroupHistory UpsertSingle(ChaseRequestGroupHistory pojo) throws Exception {

		ChaseRequestGroupHistory returnItem = null;

		try {
			returnItem = this.chaseRequestGroupHistoryData.InsertSingle(pojo, this::HandleUpsertPatientsAndEncountersResultSet);
		} catch (SQLException e) {
			this.logger.error(e.getMessage(), e);
			throw new Exception(e);
		}
		
		return returnItem;

	}
	
	private ChaseRequestGroupHistory HandleUpsertPatientsAndEncountersResultSet(ResultSet rs) {
		ChaseRequestGroupHistory returnItem = null;
		try {
			returnItem = new ChaseRequestGroupHistoryDefaultSerializer().serializeSingle(rs);
		} catch (SQLException e) {
			this.logger.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}

		return returnItem;
	}	
}
