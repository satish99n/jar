package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces;

import java.util.Collection;

import com.uhc.ucs.cdsm.domain.models.SystemSetting;

public interface ISystemSettingDomainData {
	public Collection<SystemSetting> GetSystemSettingByCategoryKey(int systemSettingCategoryKey) throws Exception;
}
