package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.deploymentinstancelayouts;

public final class DeploymentInstanceDefaultLayout
{
public static final int DeploymentInstanceKey = 1;
public static final int DeploymentInstanceUuID = 2;
public static final int MachineName = 3;
public static final int InstanceName = 4;
public static final int MacroStatus = 5;
public static final int InsertDate = 6;
public static final int CreatedBy = 7;
public static final int UpdatedDate = 8;
public static final int UpdatedBy = 9;
}
