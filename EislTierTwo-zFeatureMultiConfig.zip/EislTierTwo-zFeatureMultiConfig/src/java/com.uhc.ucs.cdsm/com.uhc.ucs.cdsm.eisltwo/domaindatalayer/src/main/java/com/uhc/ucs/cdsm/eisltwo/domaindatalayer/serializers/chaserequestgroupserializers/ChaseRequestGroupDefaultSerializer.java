package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.chaserequestgroupserializers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.chaserequestgrouplayouts.ChaseRequestGroupDefaultLayout;

public class ChaseRequestGroupDefaultSerializer {
	public ChaseRequestGroup serializeSingle(ResultSet rs) throws SQLException {
		ChaseRequestGroup item = new ChaseRequestGroup();
		if (null != rs) {
			while (rs.next()) {
				item.setChaseRequestGroupKey(rs.getLong(ChaseRequestGroupDefaultLayout.ChaseRequestGroupKey));
				item.setChaseRequestGroupUniqueIdentifier(
						rs.getString(ChaseRequestGroupDefaultLayout.ChaseRequestGroupUniqueIdentifier));
				if (null != rs.getDate(ChaseRequestGroupDefaultLayout.InsertDate)) {
					item.setInsertDate(rs.getDate(ChaseRequestGroupDefaultLayout.InsertDate));
				}
				item.setInsertedBy(rs.getString(ChaseRequestGroupDefaultLayout.InsertedBy));
				if (null != rs.getDate(ChaseRequestGroupDefaultLayout.LastUpdated)) {
					item.setLastUpdated(rs.getDate(ChaseRequestGroupDefaultLayout.LastUpdated));
				}
				item.setLastUpdatedBy(rs.getString(ChaseRequestGroupDefaultLayout.LastUpdatedBy));
				item.setClinicalDataOriginKey(rs.getInt(ChaseRequestGroupDefaultLayout.ClinicalDataOriginKey));
			}
		}
		return item;
	}

	public List<ChaseRequestGroup> serializeCollection(ResultSet rs) throws SQLException {
		ChaseRequestGroup item;
		List<ChaseRequestGroup> returnCollection = new ArrayList<ChaseRequestGroup>();
		if (null != rs) {
			while (rs.next()) {
				item = new ChaseRequestGroup();
				item.setChaseRequestGroupKey(rs.getLong(ChaseRequestGroupDefaultLayout.ChaseRequestGroupKey));
				item.setChaseRequestGroupUniqueIdentifier(
						rs.getString(ChaseRequestGroupDefaultLayout.ChaseRequestGroupUniqueIdentifier));
				if (null != rs.getDate(ChaseRequestGroupDefaultLayout.InsertDate)) {
					item.setInsertDate(rs.getDate(ChaseRequestGroupDefaultLayout.InsertDate));
				}
				item.setInsertedBy(rs.getString(ChaseRequestGroupDefaultLayout.InsertedBy));
				if (null != rs.getDate(ChaseRequestGroupDefaultLayout.LastUpdated)) {
					item.setLastUpdated(rs.getDate(ChaseRequestGroupDefaultLayout.LastUpdated));
				}
				item.setLastUpdatedBy(rs.getString(ChaseRequestGroupDefaultLayout.LastUpdatedBy));
				item.setClinicalDataOriginKey(rs.getInt(ChaseRequestGroupDefaultLayout.ClinicalDataOriginKey));
				returnCollection.add(item);
			}
		}

		return returnCollection;
	}

}