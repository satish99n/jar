package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.deploymentinstancetoclinicaldataoriginlinklayouts;

//.layouts.deploymentinstancetoclinicaldataoriginlinklayouts
public final class DeploymentInstanceToClinicalDataOriginLinkDefaultLayout
{
public static final int DeploymentInstanceKey = 1;
public static final int ClinicalDataOriginKey = 2;
public static final int InsertDate = 3;
public static final int CreatedBy = 4;
public static final int UpdatedDate = 5;
public static final int UpdatedBy = 6;
public static final int MacroStatusKey = 7;
public static final int PriorityOrdinal = 8;
}

