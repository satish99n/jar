package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.chaserequestlayouts;

public final class ChaseRequestDefaultLayout {
	public static final int ChaseRequestKey = 1;
	public static final int ChaseRequestGroupKey = 2;
	public static final int EncounterKey = 3;
	public static final int InsertDate = 4;
	public static final int InsertedBy = 5;
	public static final int LastUpdated = 6;
	public static final int LastUpdatedBy = 7;
	public static final int ClinicalDataOriginKey = 8;
}