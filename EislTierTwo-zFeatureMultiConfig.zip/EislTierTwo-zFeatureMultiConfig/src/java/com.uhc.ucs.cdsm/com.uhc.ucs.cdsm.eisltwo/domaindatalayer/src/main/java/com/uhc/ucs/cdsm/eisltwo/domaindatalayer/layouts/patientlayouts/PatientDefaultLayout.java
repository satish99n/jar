package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.patientlayouts;

public final class PatientDefaultLayout {
	/* java ResultSet is 1 based index */
	public static final int PatientKey = 1;
	public static final int PatientUniqueIdentifier = 2;
	public static final int InsertDate = 3;
	public static final int InsertedBy = 4;
	public static final int LastUpdated = 5;
	public static final int LastUpdatedBy = 6;
	public static final int ClinicalDataOriginKey = 7;
}
