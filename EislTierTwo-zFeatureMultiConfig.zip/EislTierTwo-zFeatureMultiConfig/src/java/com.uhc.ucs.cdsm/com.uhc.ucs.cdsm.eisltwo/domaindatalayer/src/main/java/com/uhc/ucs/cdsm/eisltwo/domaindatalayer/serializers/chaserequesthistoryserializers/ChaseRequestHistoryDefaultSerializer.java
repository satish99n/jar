package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.chaserequesthistoryserializers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistory;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.chaserequesthistorylayouts.ChaseRequestHistoryDefaultLayout;

public class ChaseRequestHistoryDefaultSerializer {
	public ChaseRequestHistory serializeSingle(ResultSet rs) throws SQLException {
		List<ChaseRequestHistory> items = this.serializeCollection(rs);
		ChaseRequestHistory returnItem = items.stream().findFirst().orElse(null);
		return returnItem;
	}

	public List<ChaseRequestHistory> serializeCollection(ResultSet rs) throws SQLException {
		ChaseRequestHistory item;
		List<ChaseRequestHistory> returnCollection = new ArrayList<ChaseRequestHistory>();
		if (null != rs) {
			while (rs.next()) {
				item = new ChaseRequestHistory();
				item.setChaseRequestHistoryKey(rs.getLong(ChaseRequestHistoryDefaultLayout.ChaseRequestHistoryKey));
				item.setChaseRequestKey(rs.getLong(ChaseRequestHistoryDefaultLayout.ChaseRequestKey));
				item.setMacroStatusKey(rs.getShort(ChaseRequestHistoryDefaultLayout.MacroStatusKey));
				item.setMicroStatusKey(rs.getShort(ChaseRequestHistoryDefaultLayout.MicroStatusKey));
				item.setInsertDate(rs.getDate(ChaseRequestHistoryDefaultLayout.InsertDate));
				item.setInsertedBy(rs.getString(ChaseRequestHistoryDefaultLayout.InsertedBy));
				item.setLastUpdated(rs.getDate(ChaseRequestHistoryDefaultLayout.LastUpdated));
				item.setLastUpdatedBy(rs.getString(ChaseRequestHistoryDefaultLayout.LastUpdatedBy));
				item.setClinicalDataOriginKey(rs.getInt(ChaseRequestHistoryDefaultLayout.ClinicalDataOriginKey));
				returnCollection.add(item);
			}
		}
		return returnCollection;
	}
}