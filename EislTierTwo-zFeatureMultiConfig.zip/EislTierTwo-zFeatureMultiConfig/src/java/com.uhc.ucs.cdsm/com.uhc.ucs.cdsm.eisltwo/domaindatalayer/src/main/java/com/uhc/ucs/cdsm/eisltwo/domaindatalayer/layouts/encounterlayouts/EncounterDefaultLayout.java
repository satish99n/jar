package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.encounterlayouts;

public final class EncounterDefaultLayout {
	public static final int EncounterKey = 1;
	public static final int EncounterUniqueIdentifier = 2;
	public static final int PatientKey = 3;
	public static final int InsertDate = 4;
	public static final int InsertedBy = 5;
	public static final int LastUpdated = 6;
	public static final int LastUpdatedBy = 7;
	public static final int PrimaryInsuranceIdentifier = 8;
	public static final int SecondaryInsuranceIdentifier = 9;
	public static final int TertiaryInsuranceIdentifier = 10;
	public static final int QuartaneryInsuranceIdentifier = 11;
	public static final int QuinaryInsuranceIdentifier = 12;
	public static final int ClinicalDataOriginKey = 13;
}