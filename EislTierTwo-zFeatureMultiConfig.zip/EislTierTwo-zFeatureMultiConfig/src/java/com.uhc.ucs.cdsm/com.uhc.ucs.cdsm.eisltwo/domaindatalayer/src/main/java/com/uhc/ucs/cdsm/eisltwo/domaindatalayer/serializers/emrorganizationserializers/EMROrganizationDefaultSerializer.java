package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.emrorganizationserializers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.ucs.cdsm.domain.models.EMROrganization;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.emrorganizationlayouts.EMROrganizationDefaultLayout;

// .serializers.emrorganizationserializers
public class EMROrganizationDefaultSerializer{
public EMROrganization serializeSingle(ResultSet rs) throws SQLException
{
List<EMROrganization> items = this.serializeCollection(rs);
EMROrganization returnItem = items.stream().findFirst().orElse(null);
return returnItem;
}

public List <EMROrganization> serializeCollection(ResultSet rs) throws SQLException {
EMROrganization item;
List<EMROrganization> returnCollection = new ArrayList<EMROrganization>();
if (null != rs) {
while (rs.next()) {
item = new EMROrganization();
item.seteMROrganizationKey(rs.getShort(EMROrganizationDefaultLayout.EMROrganizationKey));

item.seteMROrganizationCode(rs.getString(EMROrganizationDefaultLayout.EMROrganizationCode));

item.seteMROrganizationName(rs.getString(EMROrganizationDefaultLayout.EMROrganizationName));

item.setInsertDate(rs.getDate(EMROrganizationDefaultLayout.InsertDate));

item.setCreatedBy(rs.getString(EMROrganizationDefaultLayout.CreatedBy));

item.setUpdatedDate(rs.getDate(EMROrganizationDefaultLayout.UpdatedDate));

item.setUpdatedBy(rs.getString(EMROrganizationDefaultLayout.UpdatedBy));

returnCollection.add(item);
}
}

return returnCollection;
}
}

