package com.uhc.ucs.cdsm.eisltwo.domaindatalayer;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.datalayer.interfaces.IClinicalDataOriginSettingsByOriginKeyData;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IClinicalDataOriginSettingsByOriginKeyDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.clinicaldataoriginsettingserializers.ClinicalDataOriginSettingDefaultSerializer;

public class ClinicalDataOriginSettingsByOriginKeyDomainData
        implements IClinicalDataOriginSettingsByOriginKeyDomainData {

    private final Log logger;
    private final IClinicalDataOriginSettingsByOriginKeyData clinicalDataOriginSettingsByOriginKeyData;

    public ClinicalDataOriginSettingsByOriginKeyDomainData(Log lgr,
            IClinicalDataOriginSettingsByOriginKeyData clinicalDataOriginSettingsByOriginKeyData) {
        if (null == lgr) {
            throw new IllegalArgumentException("Log is null");
        }
        if (null == clinicalDataOriginSettingsByOriginKeyData) {
            throw new IllegalArgumentException("IClinicalDataOriginSettingsByOriginKeyData");
        }
        this.logger = lgr;
        this.clinicalDataOriginSettingsByOriginKeyData = clinicalDataOriginSettingsByOriginKeyData;
    }

    public ClinicalDataOriginSettingsByOriginKeyDomainData(
            IClinicalDataOriginSettingsByOriginKeyData clinicalDataOriginSettingsByOriginKeyData) {
        if (null == clinicalDataOriginSettingsByOriginKeyData) {
            throw new IllegalArgumentException("IClinicalDataOriginSettingsByOriginKeyData");
        }
        this.logger = LogFactory.getLog(ClinicalDataOriginSettingsByOriginKeyDomainData.class);
        this.clinicalDataOriginSettingsByOriginKeyData = clinicalDataOriginSettingsByOriginKeyData;
    }

    @Override
    public Collection<ClinicalDataOriginSetting> getClinicalDataOriginSecureSettings(int clinicalDataOriginKey)
            throws Exception {
        return clinicalDataOriginSettingsByOriginKeyData.getClinicalDataOriginSecureSettings(clinicalDataOriginKey,
                this::handleDataOriginSettingsResultSetFunction);
    }

    private Collection<ClinicalDataOriginSetting> handleDataOriginSettingsResultSetFunction(ResultSet rs) {
        Collection<ClinicalDataOriginSetting> clinicalDataOriginSettings = null;
        try {
            clinicalDataOriginSettings = new ClinicalDataOriginSettingDefaultSerializer().serializeCollection(rs);
        } catch (SQLException e) {
            this.logger.error(e.getMessage(), e);
            e.printStackTrace();
        }

        return clinicalDataOriginSettings;
    }

}
