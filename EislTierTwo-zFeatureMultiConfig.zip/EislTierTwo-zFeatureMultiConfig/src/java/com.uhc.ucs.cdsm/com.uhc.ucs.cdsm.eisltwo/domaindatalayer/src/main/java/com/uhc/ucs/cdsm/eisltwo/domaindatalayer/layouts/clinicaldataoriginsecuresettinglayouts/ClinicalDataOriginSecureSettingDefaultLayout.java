package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.clinicaldataoriginsecuresettinglayouts;

//.layouts.clinicaldataoriginsecuresettinglayouts
public final class ClinicalDataOriginSecureSettingDefaultLayout
{
public static final int ClinicalDataOriginSecureSettingKey = 1;
public static final int ClinicalDataOriginKey = 2;
public static final int ClinicalDataOriginSecureSettingKeyName = 3;
public static final int ClinicalDataOriginSecureSettingKeyDescription = 4;
public static final int ClinicalDataOriginSecureSettingKeyValue = 5;
public static final int InsertDate = 6;
public static final int InsertedBy = 7;
public static final int LastUpdated = 8;
public static final int LastUpdatedBy = 9;
}

