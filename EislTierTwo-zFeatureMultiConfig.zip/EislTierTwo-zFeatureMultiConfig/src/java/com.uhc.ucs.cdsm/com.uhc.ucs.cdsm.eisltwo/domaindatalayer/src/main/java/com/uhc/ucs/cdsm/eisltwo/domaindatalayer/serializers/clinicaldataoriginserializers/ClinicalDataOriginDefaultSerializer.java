package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.clinicaldataoriginserializers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.ucs.cdsm.domain.models.ClinicalDataOrigin;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.clinicaldataoriginlayouts.ClinicalDataOriginDefaultLayout;

// .serializers.clinicaldataoriginserializers
public class ClinicalDataOriginDefaultSerializer {
    public ClinicalDataOrigin serializeSingle(ResultSet rs) throws SQLException {
        List<ClinicalDataOrigin> items = this.serializeCollection(rs);
        ClinicalDataOrigin returnItem = items.stream().findFirst().orElse(null);
        return returnItem;
    }

    public List<ClinicalDataOrigin> serializeCollection(ResultSet rs) throws SQLException {
        ClinicalDataOrigin item;
        List<ClinicalDataOrigin> returnCollection = new ArrayList<ClinicalDataOrigin>();
        if (null != rs) {
            while (rs.next()) {
                item = new ClinicalDataOrigin();
                item.setClinicalDataOriginKey(rs.getInt(ClinicalDataOriginDefaultLayout.ClinicalDataOriginKey));

                item.setClinicalDataOriginCode(rs.getString(ClinicalDataOriginDefaultLayout.ClinicalDataOriginCode));

                item.setClinicalDataOriginName(rs.getString(ClinicalDataOriginDefaultLayout.ClinicalDataOriginName));

                item.setClinicalDataOriginDisplayName(
                        rs.getString(ClinicalDataOriginDefaultLayout.ClinicalDataOriginDisplayName));

                item.setClinicalAdapterConcreteName(
                        rs.getString(ClinicalDataOriginDefaultLayout.ClinicalAdapterConcreteName));

                item.seteMRSystemKey(rs.getShort(ClinicalDataOriginDefaultLayout.EMRSystemKey));

                item.setMacroStatusKey(rs.getShort(ClinicalDataOriginDefaultLayout.MacroStatus));

                item.setStartDate(rs.getDate(ClinicalDataOriginDefaultLayout.StartDate));

                item.setInsertDate(rs.getDate(ClinicalDataOriginDefaultLayout.InsertDate));

                item.setCreatedBy(rs.getString(ClinicalDataOriginDefaultLayout.CreatedBy));

                item.setUpdatedDate(rs.getDate(ClinicalDataOriginDefaultLayout.UpdatedDate));

                item.setUpdatedBy(rs.getString(ClinicalDataOriginDefaultLayout.UpdatedBy));

                returnCollection.add(item);
            }
        }

        return returnCollection;
    }
}
