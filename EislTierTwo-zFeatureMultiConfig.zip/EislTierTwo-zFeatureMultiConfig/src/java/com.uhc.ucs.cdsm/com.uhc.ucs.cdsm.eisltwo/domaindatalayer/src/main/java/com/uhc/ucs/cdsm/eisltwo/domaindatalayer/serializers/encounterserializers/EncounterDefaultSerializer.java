package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.encounterserializers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.ucs.cdsm.domain.models.Encounter;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.encounterlayouts.EncounterDefaultLayout;

public class EncounterDefaultSerializer {
	public Encounter serializeSingle(ResultSet rs) throws SQLException {
		List<Encounter> items = this.serializeCollection(rs);
		Encounter returnItem = items.stream().findFirst().orElse(null);
		return returnItem;
	}

	public List<Encounter> serializeCollection(ResultSet rs) throws SQLException {
		Encounter item;
		List<Encounter> returnCollection = new ArrayList<Encounter>();
		if (null != rs) {
			while (rs.next()) {
				item = new Encounter();
				item.setEncounterKey(rs.getLong(EncounterDefaultLayout.EncounterKey));
				item.setEncounterUniqueIdentifier(rs.getString(EncounterDefaultLayout.EncounterUniqueIdentifier));
				item.setPatientKey(rs.getLong(EncounterDefaultLayout.PatientKey));
				item.setInsertDate(rs.getDate(EncounterDefaultLayout.InsertDate));
				item.setInsertedBy(rs.getString(EncounterDefaultLayout.InsertedBy));
				item.setLastUpdated(rs.getDate(EncounterDefaultLayout.LastUpdated));
				item.setLastUpdatedBy(rs.getString(EncounterDefaultLayout.LastUpdatedBy));
				item.setPrimaryInsuranceIdentifier(rs.getString(EncounterDefaultLayout.PrimaryInsuranceIdentifier));
				item.setSecondaryInsuranceIdentifier(rs.getString(EncounterDefaultLayout.SecondaryInsuranceIdentifier));
				item.setTertiaryInsuranceIdentifier(rs.getString(EncounterDefaultLayout.TertiaryInsuranceIdentifier));
				item.setQuartaneryInsuranceIdentifier(rs.getString(EncounterDefaultLayout.QuartaneryInsuranceIdentifier));
				item.setQuinaryInsuranceIdentifier(rs.getString(EncounterDefaultLayout.QuinaryInsuranceIdentifier));
				item.setClinicalDataOriginKey(rs.getInt(EncounterDefaultLayout.ClinicalDataOriginKey));
				returnCollection.add(item);
			}
		}
		return returnCollection;
	}
}