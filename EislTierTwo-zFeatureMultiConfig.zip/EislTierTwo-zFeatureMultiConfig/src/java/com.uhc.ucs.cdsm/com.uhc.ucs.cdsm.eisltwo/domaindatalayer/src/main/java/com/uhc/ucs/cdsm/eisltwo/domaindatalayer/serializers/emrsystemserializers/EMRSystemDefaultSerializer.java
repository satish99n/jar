package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.emrsystemserializers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.ucs.cdsm.domain.models.EMRSystem;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.emrsystemlayouts.EMRSystemDefaultLayout;

// .serializers.emrsystemserializers
public class EMRSystemDefaultSerializer{
public EMRSystem serializeSingle(ResultSet rs) throws SQLException
{
List<EMRSystem> items = this.serializeCollection(rs);
EMRSystem returnItem = items.stream().findFirst().orElse(null);
return returnItem;
}

public List <EMRSystem> serializeCollection(ResultSet rs) throws SQLException {
EMRSystem item;
List<EMRSystem> returnCollection = new ArrayList<EMRSystem>();
if (null != rs) {
while (rs.next()) {
item = new EMRSystem();
item.seteMRSystemKey(rs.getShort(EMRSystemDefaultLayout.EMRSystemKey));

item.seteMRSystemCode(rs.getString(EMRSystemDefaultLayout.EMRSystemCode));

item.seteMRSystemName(rs.getString(EMRSystemDefaultLayout.EMRSystemName));

item.seteMROrganizationKey(rs.getShort(EMRSystemDefaultLayout.EMROrganizationKey));

item.seteMRStandardCode(rs.getString(EMRSystemDefaultLayout.EMRStandardCode));

item.setInsertDate(rs.getDate(EMRSystemDefaultLayout.InsertDate));

item.setCreatedBy(rs.getString(EMRSystemDefaultLayout.CreatedBy));

item.setUpdatedDate(rs.getDate(EMRSystemDefaultLayout.UpdatedDate));

item.setUpdatedBy(rs.getString(EMRSystemDefaultLayout.UpdatedBy));

returnCollection.add(item);
}
}

return returnCollection;
}
}

