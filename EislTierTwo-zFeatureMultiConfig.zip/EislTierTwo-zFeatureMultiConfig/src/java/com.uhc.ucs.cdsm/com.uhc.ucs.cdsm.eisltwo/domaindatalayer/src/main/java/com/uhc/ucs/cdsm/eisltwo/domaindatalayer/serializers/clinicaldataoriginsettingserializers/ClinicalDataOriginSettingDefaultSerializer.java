package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.clinicaldataoriginsettingserializers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.clinicaldataoriginsettinglayouts.ClinicalDataOriginSettingDefaultLayout;

// .serializers.clinicaldataoriginsettingserializers
public class ClinicalDataOriginSettingDefaultSerializer {
    public ClinicalDataOriginSetting serializeSingle(ResultSet rs) throws SQLException {
        List<ClinicalDataOriginSetting> items = this.serializeCollection(rs);
        ClinicalDataOriginSetting returnItem = items.stream().findFirst().orElse(null);
        return returnItem;
    }

    public List<ClinicalDataOriginSetting> serializeCollection(ResultSet rs) throws SQLException {
        ClinicalDataOriginSetting item;
        List<ClinicalDataOriginSetting> returnCollection = new ArrayList<ClinicalDataOriginSetting>();
        if (null != rs) {
            while (rs.next()) {
                item = new ClinicalDataOriginSetting();
                // item.setClinicalDataOriginSettingKey(rs.getInt(ClinicalDataOriginSettingDefaultLayout.ClinicalDataOriginSettingKey));

                item.setClinicalDataOriginKey(rs.getInt(ClinicalDataOriginSettingDefaultLayout.ClinicalDataOriginKey));

                item.setClinicalDataOriginSettingTypeKey(rs.getShort(ClinicalDataOriginSettingDefaultLayout.ClinicalDataOriginSettingTypeKey));

                item.setClinicalDataOriginSettingKeyName(
                        rs.getString(ClinicalDataOriginSettingDefaultLayout.ClinicalDataOriginSettingTypeName));

                // item.setClinicalDataOriginSettingKeyDescription(rs.getString(ClinicalDataOriginSettingDefaultLayout.ClinicalDataOriginSettingKeyDescription));

                item.setClinicalDataOriginSettingKeyValue(
                        rs.getString(ClinicalDataOriginSettingDefaultLayout.ClinicalDataOriginSettingValue));

                /*
                 * item.setInsertDate(rs.getDate(ClinicalDataOriginSettingDefaultLayout.
                 * InsertDate));
                 *
                 * item.setInsertedBy(rs.getString(ClinicalDataOriginSettingDefaultLayout.
                 * InsertedBy));
                 *
                 * item.setLastUpdated(rs.getDate(ClinicalDataOriginSettingDefaultLayout.
                 * LastUpdated));
                 *
                 * item.setLastUpdatedBy(rs.getString(ClinicalDataOriginSettingDefaultLayout.
                 * LastUpdatedBy));
                 */

                returnCollection.add(item);
            }
        }

        return returnCollection;
    }
}
