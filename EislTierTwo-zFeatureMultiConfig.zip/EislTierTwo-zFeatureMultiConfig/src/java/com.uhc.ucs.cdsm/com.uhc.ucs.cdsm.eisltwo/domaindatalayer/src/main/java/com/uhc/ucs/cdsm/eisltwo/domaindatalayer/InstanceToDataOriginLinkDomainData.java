package com.uhc.ucs.cdsm.eisltwo.domaindatalayer;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.UUID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.datalayer.interfaces.IInstanceToDataOriginLinkData;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOrigin;
import com.uhc.ucs.cdsm.domain.models.DeploymentInstance;
import com.uhc.ucs.cdsm.domain.models.DeploymentInstanceToClinicalDataOriginLink;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IInstanceToDataOriginLinkDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.clinicaldataoriginserializers.ClinicalDataOriginDefaultSerializer;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.deploymentinstanceserializers.DeploymentInstanceDefaultSerializer;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.deploymentinstancetoclinicaldataoriginlinkserializers.DeploymentInstanceToClinicalDataOriginLinkDefaultSerializer;

public class InstanceToDataOriginLinkDomainData implements IInstanceToDataOriginLinkDomainData {

    private final Log logger;
    private final IInstanceToDataOriginLinkData instanceToDataOriginLinkDomainData;

    public InstanceToDataOriginLinkDomainData(Log lgr,
            IInstanceToDataOriginLinkData instanceToDataOriginLinkDomainData) {
        if (null == lgr) {
            throw new IllegalArgumentException("Log is null");
        }
        if (null == instanceToDataOriginLinkDomainData) {
            throw new IllegalArgumentException("IInstanceToDataOriginLinkData");
        }
        this.logger = lgr;
        this.instanceToDataOriginLinkDomainData = instanceToDataOriginLinkDomainData;
    }

    public InstanceToDataOriginLinkDomainData(IInstanceToDataOriginLinkData instanceToDataOriginLinkDomainData) {
        if (null == instanceToDataOriginLinkDomainData) {
            throw new IllegalArgumentException("IInstanceToDataOriginLinkData");
        }
        this.logger = LogFactory.getLog(InstanceToDataOriginLinkDomainData.class);
        this.instanceToDataOriginLinkDomainData = instanceToDataOriginLinkDomainData;
    }

    @Override
    public Collection<ClinicalDataOrigin> getClinicalDataOriginLinks(UUID deploymentInstanceUuid)
            throws Exception {
        return instanceToDataOriginLinkDomainData.getClinicalDataOriginLinks(deploymentInstanceUuid,
                this::handleDataOriginLinkResultSetFunction);
    }

    private Collection<ClinicalDataOrigin> handleDataOriginLinkResultSetFunction(CallableStatement cstmt,ResultSet rs) {
        DeploymentInstance deploymentInstance = null;
        Collection<DeploymentInstanceToClinicalDataOriginLink> deploymentInstanceToClinicalDataOriginLink = null;
        Collection<ClinicalDataOrigin> clinicalDataOrigins = null;
        boolean isMoreResults = false;
        try {
            rs = cstmt.getResultSet();
            deploymentInstance = new DeploymentInstanceDefaultSerializer().serializeSingle(rs);

            isMoreResults = cstmt.getMoreResults();
            if(isMoreResults) {
                rs = cstmt.getResultSet();
                deploymentInstanceToClinicalDataOriginLink = new DeploymentInstanceToClinicalDataOriginLinkDefaultSerializer().serializeCollection(rs);
            }

            isMoreResults = cstmt.getMoreResults();
            if(isMoreResults) {
                rs = cstmt.getResultSet();
                clinicalDataOrigins = new ClinicalDataOriginDefaultSerializer().serializeCollection(rs);
            }

        } catch (SQLException e) {
            this.logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
        return clinicalDataOrigins;
    }

}
