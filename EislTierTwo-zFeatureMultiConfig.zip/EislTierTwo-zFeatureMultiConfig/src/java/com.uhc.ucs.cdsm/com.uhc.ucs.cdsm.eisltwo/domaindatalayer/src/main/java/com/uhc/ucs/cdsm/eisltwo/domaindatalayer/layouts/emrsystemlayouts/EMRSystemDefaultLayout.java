package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.emrsystemlayouts;

//.layouts.emrsystemlayouts
public final class EMRSystemDefaultLayout
{
public static final int EMRSystemKey = 1;
public static final int EMRSystemCode = 2;
public static final int EMRSystemName = 3;
public static final int EMROrganizationKey = 4;
public static final int EMRStandardCode = 5;
public static final int InsertDate = 6;
public static final int CreatedBy = 7;
public static final int UpdatedDate = 8;
public static final int UpdatedBy = 9;
}

