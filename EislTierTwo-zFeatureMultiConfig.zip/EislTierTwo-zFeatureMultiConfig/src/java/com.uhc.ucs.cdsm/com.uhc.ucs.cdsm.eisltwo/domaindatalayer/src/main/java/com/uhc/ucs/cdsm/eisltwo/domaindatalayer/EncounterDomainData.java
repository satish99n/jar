package com.uhc.ucs.cdsm.eisltwo.domaindatalayer;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.datalayer.interfaces.IEncounterData;
import com.uhc.ucs.cdsm.domain.models.Encounter;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IEncounterDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.encounterserializers.EncounterDefaultSerializer;

public class EncounterDomainData implements IEncounterDomainData {
    private final Log logger;
    private final IEncounterData chaseRequestGroupHistoryData;

    public EncounterDomainData(Log lgr, IEncounterData icrghd) {

        if (null == lgr) {
            throw new IllegalArgumentException("Log is null");
        }

        if (null == icrghd) {
            throw new IllegalArgumentException("IEncounterData");
        }

        this.logger = lgr;
        this.chaseRequestGroupHistoryData = icrghd;
    }

    public EncounterDomainData(IEncounterData icrghd) {
        this.chaseRequestGroupHistoryData = icrghd;
        this.logger = LogFactory.getLog(EncounterDomainData.class);
    }

    @Override
    public Encounter updateSingle(Encounter pojo) throws Exception {

        Encounter returnItem = null;

        try {
            returnItem = this.chaseRequestGroupHistoryData.updateSingle(pojo, this::HandleUpdateSingleResultSet);
        } catch (SQLException e) {
            this.logger.error(e.getMessage(), e);
            throw new Exception(e);
        }

        return returnItem;

    }

    private Encounter HandleUpdateSingleResultSet(ResultSet rs) {
        Encounter returnItem = null;
        try {
            returnItem = new EncounterDefaultSerializer().serializeSingle(rs);
        } catch (SQLException e) {
            this.logger.error(e.getMessage(), e);
            throw new RuntimeException(e);
        }

        return returnItem;
    }

    @Override
    public void insertInsuranceHistoryDistinct(String primaryInsuranceIdentifier, String secondaryInsuranceIdentifier,
            String tertiaryInsuranceIdentifier, String quartaneryInsuranceIdentifier, String quinaryInsuranceIdentifier, int clinicalDataOriginKey)
            throws Exception {

        try {
            this.chaseRequestGroupHistoryData.insertInsuranceHistoryDistinct(primaryInsuranceIdentifier,
                    secondaryInsuranceIdentifier, tertiaryInsuranceIdentifier, quartaneryInsuranceIdentifier,
                    quinaryInsuranceIdentifier,clinicalDataOriginKey, this::HandleUpdateSingleResultSet);
        } catch (SQLException e) {
            this.logger.error(e.getMessage(), e);
            throw new Exception(e);
        }

        return;

    }
}
