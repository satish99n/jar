package com.uhc.ucs.cdsm.eisltwo.domaindatalayer;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.datalayer.interfaces.IChaseRequestGroupData;
import com.uhc.ucs.cdsm.domain.models.ChaseRequest;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistory;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistory;
import com.uhc.ucs.cdsm.domain.models.Encounter;
import com.uhc.ucs.cdsm.domain.models.Patient;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IChaseRequestGroupDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.objectmappers.ChaseRequestGroupObjectMapper;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.chaserequestgroupserializers.ChaseRequestGroupDefaultSerializer;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.chaserequesthistoryserializers.ChaseRequestHistoryDefaultSerializer;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.chaserequestgrouphistoryserializers.ChaseRequestGroupHistoryDefaultSerializer;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.chaserequestserializers.ChaseRequestDefaultSerializer;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.encounterserializers.EncounterDefaultSerializer;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.patientserializers.PatientDefaultSerializer;

public class ChaseRequestGroupDomainData implements IChaseRequestGroupDomainData {
	private final Log logger;
	private final IChaseRequestGroupData chaseRequestGroupData;

	public ChaseRequestGroupDomainData(Log lgr, IChaseRequestGroupData icrgd) {

		if (null == lgr) {
			throw new IllegalArgumentException("Log is null");
		}

		if (null == icrgd) {
			throw new IllegalArgumentException("IChaseRequestGroupData");
		}

		this.logger = lgr;
		this.chaseRequestGroupData = icrgd;
	}
	
	public ChaseRequestGroupDomainData(IChaseRequestGroupData icrgd) {
		this.chaseRequestGroupData = icrgd;
		this.logger = LogFactory.getLog(ChaseRequestGroupDomainData.class);
	}

	@Override
	public ChaseRequestGroup retrieveSingle(long chaseRequestGroupKey) throws Exception {

		ChaseRequestGroup returnItem = null;

		try {
			returnItem = this.chaseRequestGroupData.RetrieveSingle(chaseRequestGroupKey,
					this::HandleRetrieveSingleResultSet);
		} catch (SQLException e) {
			this.logger.error(e.getMessage(), e);
			throw new Exception(e);
		}

		return returnItem;
	}

	private ChaseRequestGroup HandleRetrieveSingleResultSet(CallableStatement cstmt, ResultSet rs) {
		ChaseRequestGroup returnItem = null;
		Collection<ChaseRequestGroupHistory> crghs = null;
		Collection<ChaseRequest> crs = null;
		Collection<ChaseRequestHistory> crhs = null;
		Collection<Encounter> encs = null;
		Collection<Patient> pats = null;
		try {
			boolean isMoreResults = false;
			returnItem = new ChaseRequestGroupDefaultSerializer().serializeSingle(rs);

			isMoreResults = cstmt.getMoreResults();
			if (isMoreResults) {
				rs = cstmt.getResultSet();
				crghs = new ChaseRequestGroupHistoryDefaultSerializer().serializeCollection(rs);
				isMoreResults = cstmt.getMoreResults();
				if (isMoreResults) {
					rs = cstmt.getResultSet();
					crs = new ChaseRequestDefaultSerializer().serializeCollection(rs);

					isMoreResults = cstmt.getMoreResults();
					if (isMoreResults) {
						rs = cstmt.getResultSet();
						crhs = new ChaseRequestHistoryDefaultSerializer().serializeCollection(rs);

						isMoreResults = cstmt.getMoreResults();
						if (isMoreResults) {
							rs = cstmt.getResultSet();
							encs = new EncounterDefaultSerializer().serializeCollection(rs);
							isMoreResults = cstmt.getMoreResults();
							if (isMoreResults) {
								rs = cstmt.getResultSet();
								pats = new PatientDefaultSerializer().serializeCollection(rs);
							}
						}
					}
				}
			}

			if (null != returnItem) {
				returnItem = new ChaseRequestGroupObjectMapper().StitchTogether(returnItem, crghs, crs, crhs, encs, pats);
			}

		} catch (SQLException e) {
			this.logger.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}

		return returnItem;
	}

	@Override
	public ChaseRequestGroup upsertSingle(ChaseRequestGroup pojo) throws Exception {

		ChaseRequestGroup returnItem = null;

		try {
			returnItem = this.chaseRequestGroupData.UpsertSingle(pojo,
					this::HandleUpsertPatientsAndEncountersResultSet);
		} catch (SQLException e) {
			this.logger.error(e.getMessage(), e);
			throw new Exception(e);
		}

		return returnItem;

	}

	private ChaseRequestGroup HandleUpsertPatientsAndEncountersResultSet(ResultSet rs) {
		ChaseRequestGroup returnItem = null;
		try {
			returnItem = new ChaseRequestGroupDefaultSerializer().serializeSingle(rs);
		} catch (SQLException e) {
			this.logger.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}

		return returnItem;
	}
}
