package com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.function.Function;

import javax.sql.DataSource;
import javax.xml.stream.XMLStreamException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.StopWatch;

import com.uhc.ucs.cdsm.datalayer.interfaces.IPatientData;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.Patient;
import com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer.converters.PatientsToXmlConverter;

public class PatientData extends DataLayerBase implements IPatientData {

    private final Log logger;

    public final static String ProcedureNameUspPatientEncounterUpsert = "[dbo].[uspPatientEncounterUpsert]";

    public PatientData(Log lgr, DataSource dataSource) {
        super(lgr, dataSource);
        logger = lgr;
    }

    public PatientData(DataSource dataSource) {
        super(dataSource);
        logger = LogFactory.getLog(PatientData.class);
    }

    public Collection<ChaseRequestGroup> UpsertPatientsAndEncounters(Collection<Patient> patients,
            Function<ResultSet, Collection<ChaseRequestGroup>> handleResultSetFunction) throws SQLException {

        String convertedXml;
        try
        {
            convertedXml= new PatientsToXmlConverter().Convert(patients);
        }
        catch(XMLStreamException ex)
        {
            this.logger.error(ex.getMessage(), ex);
            throw new RuntimeException(ex);
        }

        Collection<ChaseRequestGroup> returnItems = null;

        Connection conn = null;
        CallableStatement cstmt = null;
        ResultSet rs = null;

        conn = getConnection();

        cstmt = conn.prepareCall("{call " + ProcedureNameUspPatientEncounterUpsert + " (?)}");

        // cstmt.setLong("PatientKey", patientKey);
        cstmt.setString(1, convertedXml);

        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        this.logger.debug(String.format("About to execute %1s (%2s patients.size)", ProcedureNameUspPatientEncounterUpsert, patients.size()));
        boolean resultsExist = cstmt.execute();
        stopWatch.stop();
        this.logger.debug(String.format("Just excecuted %1s (%2s ms)", ProcedureNameUspPatientEncounterUpsert, stopWatch.getTotalTimeMillis()));

        int rowsAffected = 0;

        // Protects against lack of SET NOCOUNT in stored procedure
        while (resultsExist || rowsAffected != -1) {
            if (resultsExist) {
                rs = cstmt.getResultSet();

                if (null != handleResultSetFunction) {
                    returnItems = handleResultSetFunction.apply(rs);
                }

                break;
            } else {
                rowsAffected = cstmt.getUpdateCount();
            }
            resultsExist = cstmt.getMoreResults();
        }

        if (rs != null)
            try {
                rs.close();
                rs = null;
            } catch (SQLException e) {
                this.logger.info(e);
            }
        if (cstmt != null)
            try {
                cstmt.close();
                cstmt = null;
            } catch (SQLException e) {
                this.logger.info(e);
            }
        if (conn != null)
            try {
                conn.close();
                conn = null;
            } catch (SQLException e) {
                this.logger.info(e);
            }

        return returnItems;
    }

    public Patient GetSinglePatientByKey(long patientKey, Function<ResultSet, Patient> handleResultSetFunction)
            throws SQLException {

        Patient returnItem = null;

        Connection conn = null;
        CallableStatement cstmt = null;
        ResultSet rs = null;

        conn = getConnection();

        cstmt = conn.prepareCall("{call dbo.uspPatientGetSingleByKey(?)}", ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_READ_ONLY);

        // cstmt.setLong("PatientKey", patientKey);
        cstmt.setLong(1, patientKey);

        boolean resultsExist = cstmt.execute();
        int rowsAffected = 0;

        // Protects against lack of SET NOCOUNT in stored procedure
        while (resultsExist || rowsAffected != -1) {
            if (resultsExist) {
                rs = cstmt.getResultSet();

                returnItem = handleResultSetFunction.apply(rs);

                break;
            } else {
                rowsAffected = cstmt.getUpdateCount();
            }
            resultsExist = cstmt.getMoreResults();
        }

        if (rs != null)
            try {
                rs.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }
        if (cstmt != null)
            try {
                cstmt.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }
        if (conn != null)
            try {
                conn.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }

        return returnItem;
    }
}
