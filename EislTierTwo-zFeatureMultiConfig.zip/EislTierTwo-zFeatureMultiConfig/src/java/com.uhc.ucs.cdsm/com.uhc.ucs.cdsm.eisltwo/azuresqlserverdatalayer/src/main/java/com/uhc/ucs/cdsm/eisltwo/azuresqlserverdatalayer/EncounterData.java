package com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.function.Function;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.datalayer.interfaces.IEncounterData;
import com.uhc.ucs.cdsm.domain.models.Encounter;

public class EncounterData extends DataLayerBase implements IEncounterData {

    private final Log logger;
    public final static String ProcedureNameuspInsuranceHistoryInsertDistinct = "[history].[uspInsuranceHistoryInsertDistinct]";

    public EncounterData(Log lgr, DataSource dataSource) {
        super(lgr, dataSource);
        logger = lgr;
    }

    public EncounterData(DataSource dataSource) {
        super(dataSource);
        logger = LogFactory.getLog(ChaseRequestHistoryData.class);
    }

    @Override
    public Encounter updateSingle(Encounter pojo, Function<ResultSet, Encounter> handleResultSetFunction)
            throws SQLException {

        Encounter returnItem = null;

        Connection conn = null;
        CallableStatement cstmt = null;
        ResultSet rs = null;

        conn = getConnection();

        cstmt = conn.prepareCall("{call dbo.uspEncounterUpdateSingle(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}",
                ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

        // cstmt.setLong("PatientKey", patientKey);
        cstmt.setLong(1, pojo.getEncounterKey());

        cstmt.setBoolean(2, false);
        cstmt.setString(3, pojo.getEncounterUniqueIdentifier());

        cstmt.setBoolean(4, false);
        cstmt.setLong(5, pojo.getPatientKey());

        cstmt.setBoolean(6, true);
        cstmt.setString(7, pojo.getPrimaryInsuranceIdentifier());

        cstmt.setBoolean(8, true);
        cstmt.setString(9, pojo.getSecondaryInsuranceIdentifier());

        cstmt.setBoolean(10, true);
        cstmt.setString(11, "");

        cstmt.setBoolean(12, true);
        cstmt.setString(13, "");

        cstmt.setBoolean(14, true);
        cstmt.setString(15, "");

        cstmt.setInt(16, pojo.getClinicalDataOriginKey());
        cstmt.setInt(17, 0);

        boolean resultsExist = cstmt.execute();
        int rowsAffected = 0;

        // Protects against lack of SET NOCOUNT in stored procedure
        while (resultsExist || rowsAffected != -1) {
            if (resultsExist) {
                rs = cstmt.getResultSet();

                if (null != handleResultSetFunction) {
                    returnItem = handleResultSetFunction.apply(rs);
                }

                break;
            } else {
                rowsAffected = cstmt.getUpdateCount();
            }
            resultsExist = cstmt.getMoreResults();
        }

        if (rs != null)
            try {
                rs.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }
        if (cstmt != null)
            try {
                cstmt.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }
        if (conn != null)
            try {
                conn.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }

        return returnItem;
    }

    @Override
    public void insertInsuranceHistoryDistinct(String primaryInsuranceIdentifier, String secondaryInsuranceIdentifier,
            String tertiaryInsuranceIdentifier, String quartaneryInsuranceIdentifier, String quinaryInsuranceIdentifier, int clinicalDataOriginKey,
            Function<ResultSet, Encounter> handleResultSetFunction) throws SQLException {

        Connection conn = null;
        CallableStatement cstmt = null;
        ResultSet rs = null;

        conn = getConnection();
        cstmt = conn.prepareCall("{call " + ProcedureNameuspInsuranceHistoryInsertDistinct + " (?,?,?,?,?,?)}",
                ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

        cstmt.setString(1, primaryInsuranceIdentifier);
        cstmt.setString(2, secondaryInsuranceIdentifier);
        cstmt.setString(3, tertiaryInsuranceIdentifier);
        cstmt.setString(4, quartaneryInsuranceIdentifier);
        cstmt.setString(5, quinaryInsuranceIdentifier);
        cstmt.setInt(6, clinicalDataOriginKey);

        boolean resultsExist = cstmt.execute();
        int rowsAffected = 0;

        while (resultsExist || rowsAffected != -1) {
            if (resultsExist) {
                rs = cstmt.getResultSet();

                if (null != handleResultSetFunction) {
                 handleResultSetFunction.apply(rs);
                }

                break;
            } else {
                rowsAffected = cstmt.getUpdateCount();
            }
            resultsExist = cstmt.getMoreResults();
        }

        if (rs != null)
            try {
                rs.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }
        if (cstmt != null)
            try {
                cstmt.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }
        if (conn != null)
            try {
                conn.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }

    }
}
