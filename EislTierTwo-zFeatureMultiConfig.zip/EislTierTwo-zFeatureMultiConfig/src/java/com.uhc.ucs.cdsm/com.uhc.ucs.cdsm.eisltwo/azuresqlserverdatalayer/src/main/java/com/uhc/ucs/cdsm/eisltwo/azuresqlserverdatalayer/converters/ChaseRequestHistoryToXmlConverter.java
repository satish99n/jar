package com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer.converters;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistory;

public class ChaseRequestHistoryToXmlConverter {

    public String ConvertSingle(ChaseRequestHistory crh) throws XMLStreamException {
        List<ChaseRequestHistory> singleItemCollection = Arrays.asList(crh);
        return this.ConvertCollection(singleItemCollection);
    }

    public String ConvertCollection(Collection<ChaseRequestHistory> crhs) throws XMLStreamException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        XMLStreamWriter writer = XMLOutputFactory.newInstance().createXMLStreamWriter(out);

        writer.writeStartElement("root");

       new PatientsToXmlConverter().convertChaseRequestHistorys(writer, crhs);

        writer.writeEndElement(); /* root */

        writer.close();

        return out.toString();
    }
}
