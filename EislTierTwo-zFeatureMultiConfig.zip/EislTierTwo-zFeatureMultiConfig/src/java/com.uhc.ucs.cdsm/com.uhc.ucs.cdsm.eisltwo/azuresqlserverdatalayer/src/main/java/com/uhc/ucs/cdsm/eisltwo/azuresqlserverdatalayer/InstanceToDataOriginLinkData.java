package com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.UUID;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.datalayer.interfaces.IInstanceToDataOriginLinkData;
import com.uhc.ucs.cdsm.datalayer.interfaces.TwoParameterFunction;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOrigin;

public class InstanceToDataOriginLinkData extends DataLayerBase implements IInstanceToDataOriginLinkData {

    private final Log logger;
    private final static String procedureNameUspDeploymentInstanceToCompanyLinkGetByDeploymentInstanceUuid = "dbo.uspDeploymentInstanceToCompanyLinkGetByDeploymentInstanceUuid";

    public InstanceToDataOriginLinkData(Log lgr, DataSource dataSource) {
        super(lgr, dataSource);
        logger = lgr;
    }

    public InstanceToDataOriginLinkData(DataSource dataSource) {
        super(dataSource);
        logger = LogFactory.getLog(InstanceToDataOriginLinkData.class);
    }

    @Override
    public Collection<ClinicalDataOrigin> getClinicalDataOriginLinks(UUID deploymentInstanceUuid,
            TwoParameterFunction<CallableStatement, ResultSet, Collection<ClinicalDataOrigin>> handleResultSetFunction) throws SQLException {
        Collection<ClinicalDataOrigin> clinicalDataOriginsReturned = null;

        Connection conn = null;
        CallableStatement cstmt = null;
        ResultSet rs = null;

        conn = getConnection();
        cstmt = conn.prepareCall(
                "{call " + procedureNameUspDeploymentInstanceToCompanyLinkGetByDeploymentInstanceUuid + "(?)}",
                ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        cstmt.setObject(1, deploymentInstanceUuid);

        boolean resultsExist = cstmt.execute();
        int rowsAffected = 0;

        // Protects against lack of SET NOCOUNT in stored procedure
        while (resultsExist || rowsAffected != -1) {
            if (resultsExist) {
                rs = cstmt.getResultSet();

                if (null != handleResultSetFunction) {
                    clinicalDataOriginsReturned = handleResultSetFunction.apply(cstmt,rs);
                }

                break;
            } else {
                rowsAffected = cstmt.getUpdateCount();
            }
            resultsExist = cstmt.getMoreResults();
        }

        if (rs != null)
            try {
                rs.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }
        if (cstmt != null)
            try {
                cstmt.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }
        if (conn != null)
            try {
                conn.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }

        return clinicalDataOriginsReturned;
    }

}
