package com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.function.Function;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.datalayer.interfaces.ISystemSettingData;
import com.uhc.ucs.cdsm.domain.models.SystemSetting;

public class SystemSettingData extends DataLayerBase implements ISystemSettingData {
    private final Log logger;

    public SystemSettingData(Log lgr, DataSource dataSource) {
        super(lgr, dataSource);
        logger = lgr;
    }

    public SystemSettingData(DataSource dataSource) {
        super(dataSource);
        logger = LogFactory.getLog(SystemSettingData.class);
    }

    public Collection<SystemSetting> GetSystemSettingByCategoryKey(int systemSettingCategoryKey, Function<ResultSet, Collection<SystemSetting>> handleResultSetFunction)
            throws SQLException {

        Collection<SystemSetting> returnItem = null;

        Connection conn = null;
        CallableStatement cstmt = null;
        ResultSet rs = null;

        conn = getConnection();

        cstmt = conn.prepareCall("{call settings.uspSystemSettingGetByCategoryKey(?)}", ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_READ_ONLY);

        // cstmt.setLong("PatientKey", patientKey);
        cstmt.setLong(1, systemSettingCategoryKey);

        boolean resultsExist = cstmt.execute();
        int rowsAffected = 0;

        // Protects against lack of SET NOCOUNT in stored procedure
        while (resultsExist || rowsAffected != -1) {
            if (resultsExist) {
                rs = cstmt.getResultSet();

                returnItem = handleResultSetFunction.apply(rs);

                break;
            } else {
                rowsAffected = cstmt.getUpdateCount();
            }
            resultsExist = cstmt.getMoreResults();
        }

        if (rs != null)
            try {
                rs.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }
        if (cstmt != null)
            try {
                cstmt.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }
        if (conn != null)
            try {
                conn.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }

        return returnItem;
    }
}
