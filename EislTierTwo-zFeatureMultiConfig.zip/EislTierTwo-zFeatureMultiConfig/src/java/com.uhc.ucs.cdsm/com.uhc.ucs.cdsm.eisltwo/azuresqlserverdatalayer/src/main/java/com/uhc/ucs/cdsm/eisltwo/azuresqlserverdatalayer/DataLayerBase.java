package com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public abstract class DataLayerBase {

    protected final Log log;
    protected final DataSource dataSource;

    public DataLayerBase(Log lgr, DataSource dataSource) {

        if (null == lgr) {
            throw new IllegalArgumentException("Log is null");
        }
        if (null == dataSource) {
            throw new IllegalArgumentException("dataSource is null");
        }
        this.dataSource = dataSource;
        this.log = lgr;
    }

    public DataLayerBase(DataSource dataSource) {
        if (null == dataSource) {
            throw new IllegalArgumentException("dataSource is null");
        }
        log = LogFactory.getLog(DataLayerBase.class);
        this.dataSource = dataSource;
    }

    Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

}
