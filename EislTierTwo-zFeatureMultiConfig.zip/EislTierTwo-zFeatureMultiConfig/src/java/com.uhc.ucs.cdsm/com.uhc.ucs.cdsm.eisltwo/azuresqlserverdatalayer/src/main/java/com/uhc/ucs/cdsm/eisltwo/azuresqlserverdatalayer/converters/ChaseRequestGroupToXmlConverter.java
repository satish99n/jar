package com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer.converters;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistory;

public class ChaseRequestGroupToXmlConverter {

	public String ConvertSingle(ChaseRequestGroup crg) throws XMLStreamException {
		List<ChaseRequestGroup> singleItemCollection = Arrays.asList(crg);
		return this.ConvertCollection(singleItemCollection);
	}

	public String ConvertCollection(Collection<ChaseRequestGroup> chaserequestgroups) throws XMLStreamException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		XMLStreamWriter writer = XMLOutputFactory.newInstance().createXMLStreamWriter(out);

		writer.writeStartElement("root");

		writer.writeStartElement("ChaseRequestGroups");
		for (ChaseRequestGroup item : chaserequestgroups) {
			writer.writeStartElement("ChaseRequestGroup");
			writer.writeAttribute("ChaseRequestGroupKey", String.valueOf(item.getChaseRequestGroupKey()));
			if (null != item.getChaseRequestGroupUniqueIdentifier()) {
				writer.writeAttribute("ChaseRequestGroupUniqueIdentifier", item.getChaseRequestGroupUniqueIdentifier());
			}
			if (null != item.getRequestStartDateTime()) {
				writer.writeAttribute("RequestStartDateTime", String.valueOf(item.getRequestStartDateTime()));
			}
			if (null != item.getRequestEndDateTime()) {
				writer.writeAttribute("RequestEndDateTime", String.valueOf(item.getRequestEndDateTime()));
			}
			if (null != item.getInsertDate()) {
				writer.writeAttribute("InsertDate", String.valueOf(item.getInsertDate()));
			}
			if (null != item.getInsertedBy()) {
				writer.writeAttribute("InsertedBy", item.getInsertedBy());
			}
			if (null != item.getLastUpdated()) {
				writer.writeAttribute("LastUpdated", String.valueOf(item.getLastUpdated()));
			}
			if (null != item.getLastUpdatedBy()) {
				writer.writeAttribute("LastUpdatedBy", item.getLastUpdatedBy());
			}
			writer.writeAttribute("ClinicalDataOriginKey", String.valueOf(item.getClinicalDataOriginKey()));
			writer.writeEndElement();
		}
		writer.writeEndElement();

		Collection<ChaseRequestGroupHistory> chaserequestgrouphistorys = chaserequestgroups.stream()
				.map(d -> d.getChaseRequestGroupHistories()).flatMap(l -> l.stream()).collect(Collectors.toList());

		writer.writeStartElement("ChaseRequestGroupHistorys");
		for (ChaseRequestGroupHistory item : chaserequestgrouphistorys) {
			writer.writeStartElement("ChaseRequestGroupHistory");
			writer.writeAttribute("ChaseRequestGroupHistoryKey", String.valueOf(item.getChaseRequestGroupHistoryKey()));
			writer.writeAttribute("ChaseRequestGroupKey", String.valueOf(item.getChaseRequestGroupKey()));
			writer.writeAttribute("MacroStatusKey", String.valueOf(item.getMacroStatusKey()));
			writer.writeAttribute("MicroStatusKey", String.valueOf(item.getMicroStatusKey()));
			if (null != item.getInsertDate()) {
				writer.writeAttribute("InsertDate", String.valueOf(item.getInsertDate()));
			}
			if (null != item.getInsertedBy()) {
				writer.writeAttribute("InsertedBy", item.getInsertedBy());
			}
			if (null != item.getLastUpdated()) {
				writer.writeAttribute("LastUpdated", String.valueOf(item.getLastUpdated()));
			}
			if (null != item.getLastUpdatedBy()) {
				writer.writeAttribute("LastUpdatedBy", item.getLastUpdatedBy());
			}
			writer.writeAttribute("ClinicalDataOriginKey", String.valueOf(item.getClinicalDataOriginKey()));
			writer.writeEndElement();
		}
		writer.writeEndElement();

		writer.writeEndElement(); /* root */

		writer.close();
		return out.toString();
	}
}
