package com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer.converters;

import java.io.ByteArrayOutputStream;
import java.util.Collection;
import java.util.stream.Collectors;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.uhc.ucs.cdsm.domain.models.ChaseRequest;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistory;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistory;
import com.uhc.ucs.cdsm.domain.models.Encounter;
import com.uhc.ucs.cdsm.domain.models.Patient;

public class PatientsToXmlConverter {

    public String Convert(Collection<Patient> patients) throws XMLStreamException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        XMLStreamWriter writer = XMLOutputFactory.newInstance().createXMLStreamWriter(out);

        writer.writeStartElement("root");

        writer.writeStartElement("Patients");
        for (Patient item : patients) {
            writer.writeStartElement("Patient");
            writer.writeAttribute("PatientKey", String.valueOf(item.getPatientKey()));
            if (null != item.getPatientUniqueIdentifier()) {
                writer.writeAttribute("PatientUniqueIdentifier", item.getPatientUniqueIdentifier());
            }
            if (null != item.getInsertDate()) {
                writer.writeAttribute("InsertDate", String.valueOf(item.getInsertDate()));
            }
            if (null != item.getInsertedBy()) {
                writer.writeAttribute("InsertedBy", item.getInsertedBy());
            }
            if (null != item.getLastUpdated()) {
                writer.writeAttribute("LastUpdated", String.valueOf(item.getLastUpdated()));
            }
            if (null != item.getLastUpdatedBy()) {
                writer.writeAttribute("LastUpdatedBy", item.getLastUpdatedBy());
            }
                writer.writeAttribute("ClinicalDataOriginKey", String.valueOf(item.getClinicalDataOriginKey()));
            writer.writeEndElement();
        }
        writer.writeEndElement();

        Collection<Encounter> encounters = patients.stream().map(d -> d.getEncounters()).flatMap(l -> l.stream())
                .collect(Collectors.toList());

        writer.writeStartElement("Encounters");
        for (Encounter item : encounters) {
            writer.writeStartElement("Encounter");
            writer.writeAttribute("EncounterKey", String.valueOf(item.getEncounterKey()));
            if (null != item.getEncounterUniqueIdentifier()) {
                writer.writeAttribute("EncounterUniqueIdentifier", item.getEncounterUniqueIdentifier());
            }
            writer.writeAttribute("PatientKey", String.valueOf(item.getPatientKey()));
            if (null != item.getPrimaryInsuranceIdentifier()) {
                writer.writeAttribute("PrimaryInsuranceIdentifier", item.getPrimaryInsuranceIdentifier());
            }
            if (null != item.getSecondaryInsuranceIdentifier()) {
                writer.writeAttribute("SecondaryInsuranceIdentifier", item.getSecondaryInsuranceIdentifier());
            }
            if (null != item.getInsertDate()) {
                writer.writeAttribute("InsertDate", String.valueOf(item.getInsertDate()));
            }
            if (null != item.getInsertedBy()) {
                writer.writeAttribute("InsertedBy", item.getInsertedBy());
            }
            if (null != item.getLastUpdated()) {
                writer.writeAttribute("LastUpdated", String.valueOf(item.getLastUpdated()));
            }
            if (null != item.getLastUpdatedBy()) {
                writer.writeAttribute("LastUpdatedBy", item.getLastUpdatedBy());
            }
            writer.writeAttribute("ClinicalDataOriginKey", String.valueOf(item.getClinicalDataOriginKey()));
            writer.writeEndElement();
        }
        writer.writeEndElement();

        Collection<ChaseRequest> chaserequests = encounters.stream().map(d -> d.getChaseRequests())
                .flatMap(l -> l.stream()).collect(Collectors.toList());

        writer.writeStartElement("ChaseRequests");
        for (ChaseRequest item : chaserequests) {
            writer.writeStartElement("ChaseRequest");
            writer.writeAttribute("ChaseRequestKey", String.valueOf(item.getChaseRequestKey()));
            writer.writeAttribute("ChaseRequestGroupKey", String.valueOf(item.getChaseRequestGroupKey()));
            writer.writeAttribute("EncounterKey", String.valueOf(item.getEncounterKey()));
            if (null != item.getInsertDate()) {
                writer.writeAttribute("InsertDate", String.valueOf(item.getInsertDate()));
            }
            if (null != item.getInsertedBy()) {
                writer.writeAttribute("InsertedBy", item.getInsertedBy());
            }
            if (null != item.getLastUpdated()) {
                writer.writeAttribute("LastUpdated", String.valueOf(item.getLastUpdated()));
            }
            if (null != item.getLastUpdatedBy()) {
                writer.writeAttribute("LastUpdatedBy", item.getLastUpdatedBy());
            }
            writer.writeAttribute("ClinicalDataOriginKey", String.valueOf(item.getClinicalDataOriginKey()));
            writer.writeEndElement();
        }
        writer.writeEndElement();

        Collection<ChaseRequestHistory> chaserequesthistorys = chaserequests.stream()
                .map(d -> d.getChaseRequestHistories()).flatMap(l -> l.stream()).collect(Collectors.toList());

        convertChaseRequestHistorys(writer, chaserequesthistorys);

        /* get distinct since "parent" may be the same */
        Collection<ChaseRequestGroup> chaserequestgroups = chaserequests.stream()
                .map(d -> d.getParentChaseRequestGroup()).distinct().collect(Collectors.toList());

        writer.writeStartElement("ChaseRequestGroups");
        for (ChaseRequestGroup item : chaserequestgroups) {
            writer.writeStartElement("ChaseRequestGroup");
            writer.writeAttribute("ChaseRequestGroupKey", String.valueOf(item.getChaseRequestGroupKey()));
            if (null != item.getChaseRequestGroupUniqueIdentifier()) {
                writer.writeAttribute("ChaseRequestGroupUniqueIdentifier", item.getChaseRequestGroupUniqueIdentifier());
            }
            if (null != item.getRequestStartDateTime()) {
                writer.writeAttribute("RequestStartDateTime", String.valueOf(item.getRequestStartDateTime()));
            }
            if (null != item.getRequestEndDateTime()) {
                writer.writeAttribute("RequestEndDateTime", String.valueOf(item.getRequestEndDateTime()));
            }
            if (null != item.getInsertDate()) {
                writer.writeAttribute("InsertDate", String.valueOf(item.getInsertDate()));
            }
            if (null != item.getInsertedBy()) {
                writer.writeAttribute("InsertedBy", item.getInsertedBy());
            }
            if (null != item.getLastUpdated()) {
                writer.writeAttribute("LastUpdated", String.valueOf(item.getLastUpdated()));
            }
            if (null != item.getLastUpdatedBy()) {
                writer.writeAttribute("LastUpdatedBy", item.getLastUpdatedBy());
            }
            writer.writeAttribute("ClinicalDataOriginKey", String.valueOf(item.getClinicalDataOriginKey()));
            writer.writeEndElement();
        }
        writer.writeEndElement();

        Collection<ChaseRequestGroupHistory> chaserequestgrouphistorys = chaserequestgroups.stream()
                .map(d -> d.getChaseRequestGroupHistories()).flatMap(l -> l.stream()).collect(Collectors.toList());

        writer.writeStartElement("ChaseRequestGroupHistorys");
        for (ChaseRequestGroupHistory item : chaserequestgrouphistorys) {
            writer.writeStartElement("ChaseRequestGroupHistory");
            writer.writeAttribute("ChaseRequestGroupHistoryKey", String.valueOf(item.getChaseRequestGroupHistoryKey()));
            writer.writeAttribute("ChaseRequestGroupKey", String.valueOf(item.getChaseRequestGroupKey()));
            writer.writeAttribute("MacroStatusKey", String.valueOf(item.getMacroStatusKey()));
            writer.writeAttribute("MicroStatusKey", String.valueOf(item.getMicroStatusKey()));
            if (null != item.getInsertDate()) {
                writer.writeAttribute("InsertDate", String.valueOf(item.getInsertDate()));
            }
            if (null != item.getInsertedBy()) {
                writer.writeAttribute("InsertedBy", item.getInsertedBy());
            }
            if (null != item.getLastUpdated()) {
                writer.writeAttribute("LastUpdated", String.valueOf(item.getLastUpdated()));
            }
            if (null != item.getLastUpdatedBy()) {
                writer.writeAttribute("LastUpdatedBy", item.getLastUpdatedBy());
            }
            writer.writeAttribute("ClinicalDataOriginKey", String.valueOf(item.getClinicalDataOriginKey()));
            writer.writeEndElement();
        }
        writer.writeEndElement();

        writer.writeEndElement(); /* root */

        writer.close();
        return out.toString();
    }

    public void convertChaseRequestHistorys(XMLStreamWriter writer,
            Collection<ChaseRequestHistory> chaserequesthistorys) throws XMLStreamException {
        writer.writeStartElement("ChaseRequestHistorys");
        for (ChaseRequestHistory item : chaserequesthistorys) {
            writer.writeStartElement("ChaseRequestHistory");
            writer.writeAttribute("ChaseRequestHistoryKey", String.valueOf(item.getChaseRequestHistoryKey()));
            writer.writeAttribute("ChaseRequestKey", String.valueOf(item.getChaseRequestKey()));
            writer.writeAttribute("MacroStatusKey", String.valueOf(item.getMacroStatusKey()));
            writer.writeAttribute("MicroStatusKey", String.valueOf(item.getMicroStatusKey()));
            if (null != item.getInsertDate()) {
                writer.writeAttribute("InsertDate", String.valueOf(item.getInsertDate()));
            }
            if (null != item.getInsertedBy()) {
                writer.writeAttribute("InsertedBy", item.getInsertedBy());
            }
            if (null != item.getLastUpdated()) {
                writer.writeAttribute("LastUpdated", String.valueOf(item.getLastUpdated()));
            }
            if (null != item.getLastUpdatedBy()) {
                writer.writeAttribute("LastUpdatedBy", item.getLastUpdatedBy());
            }
            writer.writeAttribute("ClinicalDataOriginKey", String.valueOf(item.getClinicalDataOriginKey()));
            writer.writeEndElement();
        }
        writer.writeEndElement();
    }
}
