package com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.function.Function;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.datalayer.interfaces.IClinicalDataOriginSettingsByOriginKeyData;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;

public class ClinicalDataOriginSettingsByOriginKeyData extends DataLayerBase
        implements IClinicalDataOriginSettingsByOriginKeyData {

    private final Log logger;
    private static final String procedureNameUspClinicalDataOriginAllSettingGetByClinicalDataOriginKey = "settings.uspClinicalDataOriginAllSettingGetByClinicalDataOriginKey";

    public ClinicalDataOriginSettingsByOriginKeyData(Log lgr, DataSource dataSource) {
        super(lgr, dataSource);
        this.logger = lgr;
    }

    public ClinicalDataOriginSettingsByOriginKeyData(DataSource dataSource) {
        super(dataSource);
        logger = LogFactory.getLog(ClinicalDataOriginSettingsByOriginKeyData.class);
    }

    @Override
    public Collection<ClinicalDataOriginSetting> getClinicalDataOriginSecureSettings(int clinicalDataOriginKey,
            Function<ResultSet, Collection<ClinicalDataOriginSetting>> handleResultSetFunction)
            throws SQLException {
        Collection<ClinicalDataOriginSetting> clinicalDataOriginSecureSettings = null;

        Connection conn = null;
        CallableStatement cstmt = null;
        ResultSet rs = null;

        conn = getConnection();
        cstmt = conn.prepareCall(
                "{call " + procedureNameUspClinicalDataOriginAllSettingGetByClinicalDataOriginKey + "(?)}",
                ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        cstmt.setInt(1, clinicalDataOriginKey);

        boolean resultsExist = cstmt.execute();
        int rowsAffected = 0;

        // Protects against lack of SET NOCOUNT in stored procedure
        while (resultsExist || rowsAffected != -1) {
            if (resultsExist) {
                rs = cstmt.getResultSet();

                if (null != handleResultSetFunction) {
                    clinicalDataOriginSecureSettings = handleResultSetFunction.apply(rs);
                }

                break;
            } else {
                rowsAffected = cstmt.getUpdateCount();
            }
            resultsExist = cstmt.getMoreResults();
        }

        if (rs != null)
            try {
                rs.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }
        if (cstmt != null)
            try {
                cstmt.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }
        if (conn != null)
            try {
                conn.close();
            } catch (SQLException e) {
                this.logger.info(e);
            }
        return clinicalDataOriginSecureSettings;
    }

}
