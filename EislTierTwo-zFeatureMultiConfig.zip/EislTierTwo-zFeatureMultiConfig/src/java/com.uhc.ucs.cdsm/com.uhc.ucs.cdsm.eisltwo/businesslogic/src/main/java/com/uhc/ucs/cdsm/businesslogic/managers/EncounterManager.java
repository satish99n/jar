package com.uhc.ucs.cdsm.businesslogic.managers;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.lang3.StringUtils;

import com.uhc.ucs.cdsm.businesslogic.managers.interfaces.IEncounterManager;
import com.uhc.ucs.cdsm.domain.models.Encounter;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IEncounterDomainData;

public class EncounterManager implements IEncounterManager {

    public static final String ErrorMsgEncounterIsNull = "Encounter is null";
    public static final String ErrorMsgEncounterKeyNotSpecified = "Encounter.EncounterKey not specified";
    public static final String ErrorMsgEncounterClinicalDataOriginKeyNotSpecified = "Encounter.ClinicalDataOriginKey not specified";
    public static final String ErrorMsgPatientKeyNotSpecified = "Encounter.PatientKey not specified";

    public static final String ErrorMsgClinicalDataOriginKeyNotSpecified = "ClinicalDataOriginKey not specified";
    public static final String ErrorMsgAllPrimaryInsurancesAreEmptyString = "All insurance names are empty.";

    private final Log logger;
    private IEncounterDomainData encounterDomainData;

    public EncounterManager(IEncounterDomainData encDomainData) {
        this.logger = LogFactory.getLog(EncounterManager.class);
        this.encounterDomainData = encDomainData;
    }

    public EncounterManager(Log lgr, IEncounterDomainData encDomainData) {
        this.logger = LogFactory.getLog(DeploymentInstanceManager.class);
        this.encounterDomainData = encDomainData;
    }

    @Override
    public Encounter updateSingle(Encounter pojo) throws Exception {
        Encounter returnItem = null;
        this.validateEncounter(pojo);
        returnItem = this.encounterDomainData.updateSingle(pojo);
        return returnItem;
    }

    @Override
    public void insertInsuranceHistoryDistinct(String primaryInsuranceIdentifier, String secondaryInsuranceIdentifier,
            String tertiaryInsuranceIdentifier, String quartaneryInsuranceIdentifier, String quinaryInsuranceIdentifier,
            int clinicalDataOriginKey) throws Exception {

        if (clinicalDataOriginKey <= 0) {
            throw new IllegalArgumentException(ErrorMsgClinicalDataOriginKeyNotSpecified);
        }

        if (StringUtils.isEmpty(primaryInsuranceIdentifier) && StringUtils.isEmpty(secondaryInsuranceIdentifier)
                && StringUtils.isEmpty(tertiaryInsuranceIdentifier)
                && StringUtils.isEmpty(quartaneryInsuranceIdentifier)
                && StringUtils.isEmpty(primaryInsuranceIdentifier)) {
            logger.warn(ErrorMsgAllPrimaryInsurancesAreEmptyString);
        }

        else {
            this.encounterDomainData.insertInsuranceHistoryDistinct(primaryInsuranceIdentifier,
                    secondaryInsuranceIdentifier, tertiaryInsuranceIdentifier, quartaneryInsuranceIdentifier,
                    quinaryInsuranceIdentifier, clinicalDataOriginKey);
        }
    }

    private void validateEncounter(Encounter pojo) {

        Boolean isValid = true;
        StringBuilder sb = new StringBuilder();

        if (null == pojo) {
            isValid = false;
            sb.append(ErrorMsgEncounterIsNull + System.lineSeparator());
        } else {
            if (pojo.getEncounterKey() <= 0) {
                isValid = false;
                sb.append(ErrorMsgEncounterKeyNotSpecified + System.lineSeparator());
            }

            if (pojo.getClinicalDataOriginKey() <= 0) {
                isValid = false;
                sb.append(ErrorMsgEncounterClinicalDataOriginKeyNotSpecified + System.lineSeparator());
            }

            if (pojo.getPatientKey() <= 0) {
                isValid = false;
                sb.append(ErrorMsgPatientKeyNotSpecified + System.lineSeparator());
            }
        }

        if (!isValid) {
            throw new IllegalArgumentException(sb.toString());
        }
    }
}
