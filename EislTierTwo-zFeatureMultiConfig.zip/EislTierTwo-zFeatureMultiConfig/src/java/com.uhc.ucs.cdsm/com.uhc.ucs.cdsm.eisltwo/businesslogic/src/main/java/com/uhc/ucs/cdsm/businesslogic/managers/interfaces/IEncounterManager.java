package com.uhc.ucs.cdsm.businesslogic.managers.interfaces;

import com.uhc.ucs.cdsm.domain.models.Encounter;

public interface IEncounterManager {

    Encounter updateSingle(Encounter pojo) throws Exception;

    void insertInsuranceHistoryDistinct(String primaryInsuranceIdentifier, String secondaryInsuranceIdentifier,
            String tertiaryInsuranceIdentifier, String quartaneryInsuranceIdentifier, String quinaryInsuranceIdentifier, int clinicalDataOriginKey)
            throws Exception;	
}
