package com.uhc.ucs.cdsm.businesslogic.managers.asynchronous;

import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;
import com.uhc.ucs.cdsm.adapters.adaptersbase.interfaces.IClinicalAdapter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.DocumentWrapper;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncResult;
import com.uhc.ucs.cdsm.businesslogic.model.DocumentResult;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;

public class DocumentRetrieverTaskImpl extends AbstractAsyncTask<DocumentResult> {

    private final Log logger = LogFactory.getLog(DocumentRetrieverTaskImpl.class);
    private IClinicalAdapter clinicalAdapter;
    private String pID;
    private Collection<ClinicalDataOriginSetting> originSettings;

    public DocumentRetrieverTaskImpl(String id,String pID,IClinicalAdapter clinicalAdapter, Collection<ClinicalDataOriginSetting> originSettings) {
        super(id);
        this.clinicalAdapter = clinicalAdapter;
        this.pID = pID;
        this.originSettings = originSettings;
    }

    @Override
    public AsyncResult<DocumentResult> executeTask() {
        DocumentResult docResult = new DocumentResult();

        logger.info("Getting CCDA document for Patient ID " + pID
                + " with encounter ID " + this.getId());
        DocumentWrapper dw;
        try {
            dw = clinicalAdapter.getCCDA(pID, this.getId(), originSettings);
            docResult.setId(this.getId());
            docResult.setDw(dw);
            docResult.setExecutedNormally(true);
        } catch (ClinicalDataException e) {
            docResult.setExecutedNormally(false);
            docResult.setException(e);
            docResult.setId(this.getId());
        }
        return docResult;
    }

}
