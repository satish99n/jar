package com.uhc.ucs.cdsm.businesslogic.managers.asynchronous;


import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;
import com.uhc.ucs.cdsm.adapters.adaptersbase.interfaces.IClinicalAdapter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Patient;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncResult;
import com.uhc.ucs.cdsm.businesslogic.model.PatientResult;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;

public class PatientRetrieveTaskImpl extends AbstractAsyncTask<PatientResult> {

    private final Log logger = LogFactory.getLog(PatientRetrieveTaskImpl.class);
    private IClinicalAdapter clinicalAdapter;
    private Collection<ClinicalDataOriginSetting> originSettings;
    public PatientRetrieveTaskImpl(String id, IClinicalAdapter clinicalAdapter, Collection<ClinicalDataOriginSetting> originSettings) {
        super(id);
        this.clinicalAdapter = clinicalAdapter;
        this.originSettings = originSettings;
    }

    @Override
    public AsyncResult<PatientResult> executeTask() {
        PatientResult patientResult = new PatientResult();
        Patient patient;
        try {
            logger.info("Getting patient full data for patient ID "
                    + this.getId());
             patient = clinicalAdapter.getPatientDetails(this.getId(), originSettings);
                 patientResult.setId(this.getId());
                patientResult.setPatient(patient);
                patientResult.setExecutedNormally(true);
        } catch (ClinicalDataException e) {
            patientResult.setId(this.getId());
            patientResult.setException(e);
            patientResult.setExecutedNormally(false);
        }
        return patientResult;
    }

}
