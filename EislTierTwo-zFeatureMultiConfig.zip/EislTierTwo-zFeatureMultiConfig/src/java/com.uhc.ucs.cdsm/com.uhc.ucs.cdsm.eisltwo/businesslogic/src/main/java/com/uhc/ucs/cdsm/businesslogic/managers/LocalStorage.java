package com.uhc.ucs.cdsm.businesslogic.managers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.apache.ftpserver.ftplet.FtpException;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.uhc.ucs.cdsm.eisltwo.configuration.originsettingstoconfiguration.ConfigurationUtil;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ILocalStorageConfiguration;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;
import com.uhc.ucs.cdsm.eisltwo.exportservices.interfaces.IExportCCDAService;
import com.uhc.ucs.cdsm.eisltwo.exportservices.models.DocumentDetailsWrapper;

public class LocalStorage implements IExportCCDAService {

    private ILocalStorageConfiguration localStorageConfiguration;
    private static final String FILE_EXTENSION = ".xml";
    private static final String DATEFORMAT = "yyyyMMddhhmmssSSS";
    private static final String TIMEZONE = "UTC";

    public LocalStorage(ILocalStorageConfiguration localStorageConfiguration) {
        this.localStorageConfiguration = localStorageConfiguration;
    }

    @Override
    public void exportDocument(DocumentDetailsWrapper documentDetailsWrapper)
            throws IOException, FtpException, SftpException, JSchException {
        String path = localStorageConfiguration.getLocalStoragePath();
        if (documentDetailsWrapper.getDocument() != null) {
            try (FileOutputStream fos = new FileOutputStream(
                    new File(path + generateCCDADOCFileName(documentDetailsWrapper,
                            getDateTime(documentDetailsWrapper.getDocumentCreationTime()))),
                    true)) {
                fos.write(documentDetailsWrapper.getDocument());
            }
        }
    }

    private String generateCCDADOCFileName(DocumentDetailsWrapper documentDetailsWrapper, String docGenTimestamp) {
        ITWConfiguration tWConfiguration = ConfigurationUtil.createTWConfigurtion(documentDetailsWrapper.getOriginSettings());

        StringBuilder fileName = new StringBuilder(tWConfiguration.getProviderGroupId());
        fileName.append("_");
        fileName.append(tWConfiguration.getEmrStandardCode());
        fileName.append("_");
        fileName.append(docGenTimestamp);
        fileName.append("_");
        fileName.append(tWConfiguration.getTransportProtocol());
        fileName.append("_");
        fileName.append(documentDetailsWrapper.getEncounterID());
        fileName.append("_");
        fileName.append(documentDetailsWrapper.getPatientFullName());
        fileName.append(FILE_EXTENSION);

        return fileName.toString();
    }

    private static  String getDateTime(Date docGenTimestamp){
        DateFormat dateFormat = new SimpleDateFormat(DATEFORMAT);
        dateFormat.setTimeZone(TimeZone.getTimeZone(TIMEZONE));
        return dateFormat.format(docGenTimestamp);
    }
}
