package com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces;

import java.util.concurrent.Future;

public interface AsyncTaskExecutor<V> {
	Future<AsyncResult<V>> executeAsyncTask(AsyncTask<V> task);
}
