package com.uhc.ucs.cdsm.businesslogic.util;

import java.util.Collection;
import java.util.List;

import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Insurance;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Patient;
import com.uhc.ucs.cdsm.domain.dictionaries.SystemSettingCategoryDictionary;
import com.uhc.ucs.cdsm.domain.models.SystemSetting;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.ISystemSettingDomainData;

/**
 * This class validates the following conditions for a patient
 * 
 * Does the patient has Primary Insurance as "UHG" or any regular expression matching the same.
 * Does the patient has Insurance with Self-pay in any of the insurance types.
 */
public class PatientInsuranceValidator {

	public static boolean isPatientWithUHGInsurance(Patient patient, ISystemSettingDomainData systemSettingDomainData)
			throws Exception {

		Collection<SystemSetting> systemSettings = systemSettingDomainData.GetSystemSettingByCategoryKey(
				SystemSettingCategoryDictionary.UnitedHealthcareInsuranceNameRegex.getSystemSettingCategoryKey());
		if (null != systemSettings) {
			List<Insurance> insuranceList = patient.getInsuranceList();
			for (SystemSetting ss : systemSettings) {
				for (Insurance insurance : insuranceList) {
					if (insurance.getType().equals(Insurance.Type.PrimaryInsurance)
							&& insurance.getInsuranceName().matches(ss.getSettingValue())) {
						return true;
					}
				}
			}
		}

		return false;
	}

	public static boolean isPatientSelfPayed(Patient patient, ISystemSettingDomainData systemSettingDomainData)
			throws Exception {

		final Collection<SystemSetting> systemSettingByCategoryKeys = systemSettingDomainData
				.GetSystemSettingByCategoryKey(
						SystemSettingCategoryDictionary.BlacklistInsuranceNameRegex.getSystemSettingCategoryKey());
		if (null != systemSettingByCategoryKeys) {
			List<Insurance> insuranceList = patient.getInsuranceList();
			for (SystemSetting ss : systemSettingByCategoryKeys) {
				for (Insurance insurance : insuranceList) {
					if (insurance.getInsuranceName().matches(ss.getSettingValue())) {
						return true;
					}
				}
			}
		}
		return false;
	}
}
