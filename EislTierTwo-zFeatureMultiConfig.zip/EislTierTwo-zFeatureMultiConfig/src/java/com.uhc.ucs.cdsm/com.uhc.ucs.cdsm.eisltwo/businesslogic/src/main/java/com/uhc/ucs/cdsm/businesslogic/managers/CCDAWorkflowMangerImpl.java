package com.uhc.ucs.cdsm.businesslogic.managers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;
import com.uhc.ucs.cdsm.adapters.adaptersbase.interfaces.IClinicalAdapter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.DocumentWrapper;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Insurance;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Patient;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncTaskManager;
import com.uhc.ucs.cdsm.businesslogic.managers.interfaces.ICCDAWorkflowManger;
import com.uhc.ucs.cdsm.businesslogic.managers.interfaces.IEncounterManager;
import com.uhc.ucs.cdsm.businesslogic.model.DocumentResult;
import com.uhc.ucs.cdsm.businesslogic.model.PatientResult;
import com.uhc.ucs.cdsm.businesslogic.util.PatientInsuranceValidator;
import com.uhc.ucs.cdsm.domain.dictionaries.ChaseRequestGroupHistoryMacroStatusDictionary;
import com.uhc.ucs.cdsm.domain.dictionaries.ChaseRequestGroupHistoryMicroStatusDictionary;
import com.uhc.ucs.cdsm.domain.dictionaries.ChaseRequestHistoryMacroStatusDictionary;
import com.uhc.ucs.cdsm.domain.dictionaries.ChaseRequestHistoryMicroStatusDictionary;
import com.uhc.ucs.cdsm.domain.dictionaries.SystemSettingCategoryDictionary;
import com.uhc.ucs.cdsm.domain.dictionaries.SystemSettingDictionary;
import com.uhc.ucs.cdsm.domain.models.ChaseRequest;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistory;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistory;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistoryMicroStatus;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOrigin;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;
import com.uhc.ucs.cdsm.domain.models.SystemSetting;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IChaseRequestGroupDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IChaseRequestGroupHistoryDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IChaseRequestHistoryDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IClinicalDataOriginSettingsByOriginKeyDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IPatientDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.ISystemSettingDomainData;
import com.uhc.ucs.cdsm.eisltwo.exportservices.interfaces.IExportCCDAService;
import com.uhc.ucs.cdsm.eisltwo.exportservices.models.DocumentDetailsWrapper;
import com.uhc.ucs.cdsm.eisltwo.exportservices.sftpexportservice.ExportCCDAServiceImpl;

/**
 * This class handles and executes the workflow. Following are steps involved.
 *
 * Send request to EHR to fetch encounters. Send request to EHR along patientID
 * to fetch Patient full details. Validate Patient Insurance ( handled in
 * {@link PatientInsuranceValidator}) Send request to EHR along encounterID and
 * patientID to fetch CCDA document. Store the fetched CCDA document in a SFTP
 * location. ( handles in {@link ExportCCDAServiceImpl} )
 *
 */
public class CCDAWorkflowMangerImpl implements ICCDAWorkflowManger {

    private static final String PULLING_DATA_FROM_CLINICAL_ADAPTER = "Pulling data from clinicalAdapter with ClinicalAdapterConcreteName: %s, key:%s";

    private static final String NO_CLINIAL_ADAPTER_NAME = "No clinialAdapter found with ClinicalAdapterConcreteName: %s";
    public static final String NO_CLINICAL_ADAPTERS = "No clinicalAdapters found, so exiting the flow.";

    public static final String MessageNoEncounters = "No encounters from %s to %s";
    public final static String MessagePatientDetailsGetTimeoutSecondsInfo = "PatientDetailsGetTimeoutSeconds = ('%s')";
    public final static String MessageDocumentRetrieveTimeoutSecondsInfo = "DocumentRetrieveTimeoutSeconds = ('%s')";
    public static final String MessageDocumentWrapperIsNull = "DocumentWrapper is null. (EncounterId='%1s')";

    public static final int ChaseRequestGroupStartNegativeSurrogateKey = -1000;
    public static final int PatientStartNegativeSurrogateKey = -10000;
    public static final int EncounterStartNegativeSurrogateKey = -20000;
    public static final int ChaseRequestStartNegativeSurrogateKey = -30000;
    public static final int ChaseRequestHistoryStartNegativeSurrogateKey = -40000;

    private final Log logger;
    private DeploymentInstanceManager deploymentInstanceManager;
    private IExportCCDAService exportService;
    private IChaseRequestHistoryDomainData chaseRequestHistoryDomainData;
    private IChaseRequestGroupHistoryDomainData chaseRequestGroupHistoryDomainData;
    private IChaseRequestGroupDomainData chaseRequestGroupDomainData;
    private IPatientDomainData patientDomainData;
    private IEncounterManager encounterManager;
    private ISystemSettingDomainData systemSettingDomainData;
    private IClinicalDataOriginSettingsByOriginKeyDomainData clinicalDataOriginSettingsByOriginKeyDomainData;
    private AsyncTaskManager<?> asyncTaskManager;
    private Map<String, IClinicalAdapter> clinicalAdapterMap;

    public CCDAWorkflowMangerImpl(DeploymentInstanceManager deploymentInstanceManager, IExportCCDAService exportService,
            IChaseRequestHistoryDomainData chaseRequestHistoryDomainData,
            ISystemSettingDomainData systemSettingDomainData,
            IChaseRequestGroupHistoryDomainData chaseRequestGroupHistoryDomainData,
            IChaseRequestGroupDomainData chaseRequestGroupDomainData, IPatientDomainData patientDomainData,
            IEncounterManager encManager,
            IClinicalDataOriginSettingsByOriginKeyDomainData clinicalDataOriginSettingsByOriginKeyDomainData,
            AsyncTaskManager<?> asyncTaskManager, Map<String, IClinicalAdapter> clinicalAdapterMap) {
        this.logger = LogFactory.getLog(CCDAWorkflowMangerImpl.class);
        this.deploymentInstanceManager = deploymentInstanceManager;
        this.exportService = exportService;
        this.chaseRequestHistoryDomainData = chaseRequestHistoryDomainData;
        this.systemSettingDomainData = systemSettingDomainData;
        this.chaseRequestGroupHistoryDomainData = chaseRequestGroupHistoryDomainData;
        this.chaseRequestGroupDomainData = chaseRequestGroupDomainData;
        this.patientDomainData = patientDomainData;
        this.encounterManager = encManager;
        this.clinicalDataOriginSettingsByOriginKeyDomainData = clinicalDataOriginSettingsByOriginKeyDomainData;
        this.asyncTaskManager = asyncTaskManager;
        this.clinicalAdapterMap = clinicalAdapterMap;
    }

    public CCDAWorkflowMangerImpl(Log lgr, DeploymentInstanceManager deploymentInstanceManager,
            IExportCCDAService exportService, IChaseRequestHistoryDomainData chaseRequestHistoryDomainData,
            ISystemSettingDomainData systemSettingDomainData,
            IChaseRequestGroupHistoryDomainData chaseRequestGroupHistoryDomainData,
            IChaseRequestGroupDomainData chaseRequestGroupDomainData, IPatientDomainData patientDomainData,
            IEncounterManager encManager, AsyncTaskManager<?> asyncTaskManager,
            Map<String, IClinicalAdapter> clinicalAdapterMap) {
        this.logger = lgr;
        this.deploymentInstanceManager = deploymentInstanceManager;
        this.exportService = exportService;
        this.chaseRequestHistoryDomainData = chaseRequestHistoryDomainData;
        this.systemSettingDomainData = systemSettingDomainData;
        this.chaseRequestGroupHistoryDomainData = chaseRequestGroupHistoryDomainData;
        this.chaseRequestGroupDomainData = chaseRequestGroupDomainData;
        this.patientDomainData = patientDomainData;
        this.encounterManager = encManager;
        this.asyncTaskManager = asyncTaskManager;
        this.clinicalAdapterMap = clinicalAdapterMap;
    }

    @Override
    public void performWorkflow(Date fromDate, Date toDate) throws Exception {

        Collection<ClinicalDataOrigin> clinicalDataOrigins = deploymentInstanceManager
                .getActiveClinicalDataOrigins();
        if (CollectionUtils.isEmpty(clinicalDataOrigins)) {
            logger.error(NO_CLINICAL_ADAPTERS);
        }
        for (ClinicalDataOrigin clinicalDataOrigin : clinicalDataOrigins) {
            String clinicalAdapterConcreteName = clinicalDataOrigin.getClinicalAdapterConcreteName();
            int clinicalDataOriginKey = clinicalDataOrigin.getClinicalDataOriginKey();
            IClinicalAdapter iClinicalAdapter = clinicalAdapterMap.get(clinicalAdapterConcreteName);
            if (iClinicalAdapter == null) {
                logger.error(String.format(NO_CLINIAL_ADAPTER_NAME, clinicalAdapterConcreteName));
            } else {
                logger.info(String.format(PULLING_DATA_FROM_CLINICAL_ADAPTER, clinicalAdapterConcreteName,
                        clinicalDataOriginKey));
                try {
                    pullDataFromClinicalDataOrgin(clinicalDataOriginKey, iClinicalAdapter, fromDate, toDate);
                } catch (Exception e) {
                    logger.error("Exception while pulling data from adapter.", e);
                }
            }
        }
        logger.info(" <------  Exiting business logic");
    }

    private void pullDataFromClinicalDataOrgin(int clinicalDataOriginKey, IClinicalAdapter clinicalAdapter,
            Date fromDate, Date toDate) throws Exception {
        logger.info(String.format("Getting CCDA Documents. (fromDate='%1s', toDate='%2s')", fromDate, toDate));
        Collection<SystemSetting> timeoutSettings = null;
        try {
            timeoutSettings = this.systemSettingDomainData.GetSystemSettingByCategoryKey(
                    SystemSettingCategoryDictionary.DefaultTimeouts.getSystemSettingCategoryKey());
        } catch (Exception ex) {
            this.logger.error("SystemSettingDomainData.GetSystemSettingByCategoryKey failed.", ex);
            throw new RuntimeException(ex);
        }

        long patientDetailsGetTimeoutSeconds = this.getPatientDetailsGetTimeoutSeconds(timeoutSettings);
        this.logger.debug(String.format(MessagePatientDetailsGetTimeoutSecondsInfo, patientDetailsGetTimeoutSeconds));
        long documentRetrieveTimeoutSeconds = this.getDocumentRetrieveTimeoutSeconds(timeoutSettings);
        this.logger.debug(String.format(MessageDocumentRetrieveTimeoutSecondsInfo, documentRetrieveTimeoutSeconds));

        Collection<ClinicalDataOriginSetting> originSettings = clinicalDataOriginSettingsByOriginKeyDomainData
                .getClinicalDataOriginSecureSettings(clinicalDataOriginKey);

        ChaseRequestGroup crg = new ChaseRequestGroup();
        crg.setChaseRequestGroupKey(ChaseRequestGroupStartNegativeSurrogateKey);
        crg.setClinicalDataOriginKey(clinicalDataOriginKey);
        ChaseRequestGroup crgWithActualKey = chaseRequestGroupDomainData.upsertSingle(crg);

        // * Inserting ChaseRequestGroupHistoryMacroStatus New *
        ChaseRequestGroupHistory history = ChaseRequestHistoryFactory
                .getChaseRequestGroupHistory(ChaseRequestGroupHistoryMacroStatusDictionary.New, clinicalDataOriginKey);
        history.setParentChaseRequestGroup(crgWithActualKey);
        history.setChaseRequestGroupKey(crgWithActualKey.getChaseRequestGroupKey());
        history.setMicroStatusKey(ChaseRequestGroupHistoryMicroStatusDictionary.NewMicroDefault
                .getChaseRequestGroupHistoryMicroStatusKey());
        chaseRequestGroupHistoryDomainData.UpsertSingle(history);

        // * Inserting AboutToSendBulkEncounterRequestToSourceData*
        history.setMacroStatusKey(
                ChaseRequestGroupHistoryMacroStatusDictionary.AboutToSendBulkEncounterRequestToSourceData
                        .getChaseRequestGroupHistoryMacroStatusKey());
        history.setMicroStatusKey(
                ChaseRequestGroupHistoryMicroStatusDictionary.AboutToSendBulkEncounterRequestToSourceDataMicroDefault
                        .getChaseRequestGroupHistoryMicroStatusKey());
        chaseRequestGroupHistoryDomainData.UpsertSingle(history);

        List<Encounter> encounters;
        try {
            encounters = clinicalAdapter.getEncounters(fromDate, toDate, originSettings);
        } catch (ClinicalDataException e) {
            history.setMacroStatusKey(
                    ChaseRequestGroupHistoryMacroStatusDictionary.SendBulkEncounterRequestToSourceDataFailed
                            .getChaseRequestGroupHistoryMacroStatusKey());
            history.setMicroStatusKey(
                    ChaseRequestGroupHistoryMicroStatusDictionary.SendBulkEncounterRequestToSourceDataFailedMicroDefault
                            .getChaseRequestGroupHistoryMicroStatusKey());
            chaseRequestGroupHistoryDomainData.UpsertSingle(history);
            throw e;
        }
        history.setMacroStatusKey(
                ChaseRequestGroupHistoryMacroStatusDictionary.SendBulkEncounterRequestToSourceDataCompleted
                        .getChaseRequestGroupHistoryMacroStatusKey());
        if (encounters.isEmpty()) {
            String msg = String.format(MessageNoEncounters, fromDate, toDate);
            logger.info(msg);
            history.setMicroStatusKey(
                    ChaseRequestGroupHistoryMicroStatusDictionary.SendBulkEncounterRequestToSourceDataCompletedWithNoEncountersMicroDefault
                            .getChaseRequestGroupHistoryMicroStatusKey());
            chaseRequestGroupHistoryDomainData.UpsertSingle(history);
            return;
        } else {
            history.setMicroStatusKey(
                    ChaseRequestGroupHistoryMicroStatusDictionary.SendBulkEncounterRequestToSourceDataCompletedMicroDefault
                            .getChaseRequestGroupHistoryMicroStatusKey());
            chaseRequestGroupHistoryDomainData.UpsertSingle(history);

            Collection<com.uhc.ucs.cdsm.domain.models.Patient> patientList = populatePatientEncounters(encounters,
                    crgWithActualKey, clinicalDataOriginKey);
            /* BULK insert for encounters */
            Collection<ChaseRequestGroup> crgs = patientDomainData.UpsertPatientsAndEncounters(patientList);
            logger.info("bulk insert for encounters is successful");

            List<Encounter> refinedEncounters = parsePatientResults(encounters, crgs,
                    getPatientList(encounters, crgs, clinicalAdapter, clinicalDataOriginKey, originSettings, patientDetailsGetTimeoutSeconds), clinicalDataOriginKey);
            if (refinedEncounters.isEmpty()) {
                logger.info("No encounter has valid insurance type");
                history.setMacroStatusKey(ChaseRequestGroupHistoryMacroStatusDictionary.CompletedWithNoErrors
                        .getChaseRequestGroupHistoryMacroStatusKey());
                history.setMicroStatusKey(
                        ChaseRequestGroupHistoryMicroStatusDictionary.CompletedWithNoErrorsMicroDefault
                                .getChaseRequestGroupHistoryMicroStatusKey());
                chaseRequestGroupHistoryDomainData.UpsertSingle(history);
                return;
            }
            List<DocumentWrapper> dwList = parseDocumentResults(refinedEncounters, crgs,
                    getCCDAList(refinedEncounters, crgs, clinicalAdapter, clinicalDataOriginKey, originSettings, documentRetrieveTimeoutSeconds),
                    clinicalDataOriginKey);

            Collection<ChaseRequestHistory> exportCompletedList = new ArrayList<>();
            Collection<ChaseRequestHistory> workflowEndedStatusList = new ArrayList<>();
            Collection<ChaseRequest> crList = getChaseRequestList(crgs);
            if (!dwList.isEmpty()) {
                for (Encounter encounter : refinedEncounters) {
                    ChaseRequest chaseRequestForEncounter = crList.stream().filter(x -> x.getParentEncounter()
                            .getEncounterUniqueIdentifier().equals(encounter.getEncounterId())).findFirst()
                            .orElse(null);
                    ChaseRequestHistory resultsToFTP = ChaseRequestHistoryFactory
                            .getChaseRequestHistory(chaseRequestForEncounter, clinicalDataOriginKey);
                    insertChaseRequestHistory(chaseRequestForEncounter, resultsToFTP,
                            ChaseRequestHistoryMacroStatusDictionary.AboutToSendResultsTodestination
                                    .getChaseRequestHistoryMacroStatusKey(),
                            ChaseRequestHistoryMicroStatusDictionary.AboutToSendResultsToDestinationMicroDefault
                                    .getChaseRequestHistoryMicroStatusKey());
                    DocumentWrapper ccdaDocWrapper = dwList.stream()
                            .filter(x -> x.getEncounterID().equals(encounter.getEncounterId())).findFirst()
                            .orElse(null);
                    if (null == ccdaDocWrapper) {
                        this.logger.warn(String.format(MessageDocumentWrapperIsNull, encounter.getEncounterId()));
                    }

                    try {
                        DocumentDetailsWrapper documentDetailsWrapper = new DocumentDetailsWrapper();
                        documentDetailsWrapper.setEncounterID(ccdaDocWrapper.getEncounterID());
                        documentDetailsWrapper.setPatientFullName(getPatientFullName(encounter));
                        documentDetailsWrapper.setDocumentCreationTime(ccdaDocWrapper.getDocumentCreationTime());
                        documentDetailsWrapper.setDocument(ccdaDocWrapper.getDocument());
                        documentDetailsWrapper.setOriginSettings(originSettings);
                        exportService.exportDocument(documentDetailsWrapper);

                        resultsToFTP.setMacroStatusKey(ChaseRequestHistoryMacroStatusDictionary.SendResultsToDestinationCompleted
                                        .getChaseRequestHistoryMacroStatusKey());
                        resultsToFTP.setMicroStatusKey(ChaseRequestHistoryMicroStatusDictionary.SendResultsToDestinationCompletedMicroDefault
                                        .getChaseRequestHistoryMicroStatusKey());
                        chaseRequestForEncounter.getChaseRequestHistories().add(resultsToFTP);
                        exportCompletedList.add(resultsToFTP);
                        ChaseRequestHistory workflowEndedStatus = new ChaseRequestHistory();
                        workflowEndedStatus.setChaseRequestHistoryKey(resultsToFTP.getChaseRequestHistoryKey());
                        workflowEndedStatus.setChaseRequestKey(resultsToFTP.getChaseRequestKey());
                        workflowEndedStatus.setParentChaseRequest(resultsToFTP.getParentChaseRequest());
                        workflowEndedStatus.setClinicalDataOriginKey(resultsToFTP.getClinicalDataOriginKey());

                        workflowEndedStatus.setMacroStatusKey(ChaseRequestHistoryMacroStatusDictionary.Ended.getChaseRequestHistoryMacroStatusKey());
                        workflowEndedStatus.setMicroStatusKey(ChaseRequestHistoryMicroStatusDictionary.EndedResultDeliveredToDestination
                                        .getChaseRequestHistoryMicroStatusKey());
                        chaseRequestForEncounter.getChaseRequestHistories().add(workflowEndedStatus);
                        workflowEndedStatusList.add(workflowEndedStatus);

                    } catch (Exception e) {
                        logger.error(
                                String.format("Sending CCDA document has failed. (EncounterID='%1s', ex.Message='%2s')",
                                        ccdaDocWrapper.getEncounterID(), e.getMessage()),
                                e);
                        insertChaseRequestHistory(chaseRequestForEncounter, resultsToFTP,
                                ChaseRequestHistoryMacroStatusDictionary.SendResultsToDestinationFailed
                                        .getChaseRequestHistoryMacroStatusKey(),
                                ChaseRequestHistoryMicroStatusDictionary.SendResultsToDestinationFailedMicroDefault
                                        .getChaseRequestHistoryMicroStatusKey());

                        insertChaseRequestHistory(chaseRequestForEncounter, resultsToFTP,
                                ChaseRequestHistoryMacroStatusDictionary.Ended.getChaseRequestHistoryMacroStatusKey(),
                                ChaseRequestHistoryMicroStatusDictionary.EndedEndedWithError
                                        .getChaseRequestHistoryMicroStatusKey());
                    }
                }
                bulkInsertChaseRequestHistories(exportCompletedList);
                bulkInsertChaseRequestHistories(workflowEndedStatusList);
            }
        }
    }

    private String getPatientFullName(Encounter encounter) {
        String firstName = encounter.getPatient().getPatientFirstName().replaceAll("[^a-zA-Z0-9]", "");
        String lastName = encounter.getPatient().getPatientLastName().replaceAll("[^a-zA-Z0-9]", "");
        return firstName + lastName;
    }

    private List<PatientResult> getPatientList(List<Encounter> encounters, Collection<ChaseRequestGroup> crgs,
            IClinicalAdapter clinicalAdapter, int clinicalDataOriginKey, Collection<ClinicalDataOriginSetting> originSettings, long patientDetailsGetTimeoutSeconds) throws Exception {

        Collection<ChaseRequest> crList = getChaseRequestList(crgs);

        for (Encounter encounter : encounters) {
            ChaseRequest chaseRequestForEncounter = crList.stream().filter(
                    x -> x.getParentEncounter().getEncounterUniqueIdentifier().equals(encounter.getEncounterId()))
                    .findFirst().orElse(null);
            ChaseRequestHistory crgHistory = ChaseRequestHistoryFactory.getChaseRequestHistory(chaseRequestForEncounter,
                    clinicalDataOriginKey);
            insertChaseRequestHistory(chaseRequestForEncounter, crgHistory,
                    ChaseRequestHistoryMacroStatusDictionary.AboutToSendPatientDetailRequestToSourceData
                            .getChaseRequestHistoryMacroStatusKey(),
                    ChaseRequestHistoryMicroStatusDictionary.AboutToSendPatientDetailRequestToSourceDataMicroDefault
                            .getChaseRequestHistoryMicroStatusKey());
        }

        @SuppressWarnings("unchecked")
        List<PatientResult> results = ClinicalDataRetrievePerformer.retrievePatients(encounters,
                (AsyncTaskManager<PatientResult>) asyncTaskManager, clinicalAdapter, originSettings, patientDetailsGetTimeoutSeconds);

        return results;
    }

    private List<Encounter> parsePatientResults(List<Encounter> encounters, Collection<ChaseRequestGroup> crgs,
            List<PatientResult> results, int clinicalDataOriginKey) throws Exception {

        String primaryInsurance = null;
        String secondaryInsurance = null;
        String tertiaryInsurance = null;
        String quartaneryInsurance = null;
        String quinaryInsurance = null;

        Collection<ChaseRequestHistory> bulkInsertList = new ArrayList<>();

        List<Encounter> refinedEncounters = new ArrayList<>(encounters);
        Collection<ChaseRequest> crList = getChaseRequestList(crgs);

        if (!results.isEmpty()) {
            for (Encounter encounter : encounters) {
                ChaseRequest chaseRequestForEncounter = crList.stream().filter(
                        x -> x.getParentEncounter().getEncounterUniqueIdentifier().equals(encounter.getEncounterId()))
                        .findFirst().orElse(null);
                PatientResult patientResult = results.stream()
                        .filter(patient -> patient.getPatientId().equals(encounter.getPatient().getPatientId()))
                        .findFirst().orElse(null);

                if (patientResult != null) {
                    if (patientResult.isExecutedNormally()) {
                        Patient patient = patientResult.getPatient();
                        boolean isUHGInsurance = PatientInsuranceValidator
                                .isPatientWithUHGInsurance(patient, systemSettingDomainData);
                        boolean isSelfPayed = PatientInsuranceValidator
                                .isPatientSelfPayed(patient, systemSettingDomainData);
                        if (!isUHGInsurance || isSelfPayed) {
                            if (!isUHGInsurance)
                                logger.info("Patient with ID " + patient.getPatientId()
                                        + " doesn't has UHG as primary insurance");
                            else
                                logger.info("patient with ID " + patient.getPatientId()
                                        + " has self-payed");
                            refinedEncounters.remove(encounter);
                            ChaseRequestHistory history = ChaseRequestHistoryFactory
                                    .getChaseRequestHistory(chaseRequestForEncounter, clinicalDataOriginKey);
                            insertChaseRequestHistory(chaseRequestForEncounter, history,
                                    ChaseRequestHistoryMacroStatusDictionary.Ended
                                            .getChaseRequestHistoryMacroStatusKey(),
                                    ChaseRequestHistoryMicroStatusDictionary.EndedInsuranceInformationDidNotMatchEarlyExit
                                            .getChaseRequestHistoryMicroStatusKey());
                        } else {
                            ChaseRequestHistory history = ChaseRequestHistoryFactory
                                    .getChaseRequestHistory(chaseRequestForEncounter, clinicalDataOriginKey);
                            com.uhc.ucs.cdsm.domain.models.Encounter updateEncounter = history.getParentChaseRequest()
                                    .getParentEncounter();
                            List<Insurance> insuranceList = patientResult.getPatient().getInsuranceList();
                            for (Insurance insurance : insuranceList) {
                                if (insurance.getType().equals(Insurance.Type.PrimaryInsurance)) {
                                    primaryInsurance = insurance.getInsuranceName();
                                    updateEncounter.setPrimaryInsuranceIdentifier(primaryInsurance);
                                } else if (insurance.getType().equals(Insurance.Type.SecondaryInsurance)) {
                                    secondaryInsurance = insurance.getInsuranceName();
                                    updateEncounter.setSecondaryInsuranceIdentifier(secondaryInsurance);
                                } else if (insurance.getType().equals(Insurance.Type.TertiaryInsurance)) {
                                    tertiaryInsurance = insurance.getInsuranceName();
                                } else if (insurance.getType().equals(Insurance.Type.QuartaneryInsurance)) {
                                    quartaneryInsurance = insurance.getInsuranceName();
                                } else if (insurance.getType().equals(Insurance.Type.QuinaryInsurance)) {
                                    quinaryInsurance = insurance.getInsuranceName();
                                } else {
                                }
                            }
                            this.encounterManager.updateSingle(updateEncounter);
                            this.encounterManager.insertInsuranceHistoryDistinct(primaryInsurance, secondaryInsurance,
                                    tertiaryInsurance, quartaneryInsurance, quinaryInsurance,
                                    updateEncounter.getClinicalDataOriginKey());
                            history.setMacroStatusKey( ChaseRequestHistoryMacroStatusDictionary.SendPatientDetailRequestToSourceDataCompleted
                                            .getChaseRequestHistoryMacroStatusKey());
                            history.setMicroStatusKey( ChaseRequestHistoryMicroStatusDictionary.SendPatientDetailRequestToSourceDataCompletedMicroDefault
                                            .getChaseRequestHistoryMicroStatusKey());
                            chaseRequestForEncounter.getChaseRequestHistories().add(history);
                            bulkInsertList.add(history);
                        }
                    } else {
                        Exception resultException = patientResult.getException();
                        logger.error(String.format("Error while retrieving patient details for patient id: %s", patientResult.getId()), resultException);
                        ChaseRequestHistory history = ChaseRequestHistoryFactory
                                .getChaseRequestHistory(chaseRequestForEncounter, clinicalDataOriginKey);
                        history.setMacroStatusKey(
                                ChaseRequestHistoryMacroStatusDictionary.SendPatientDetailRequestToSourceDataFailed
                                        .getChaseRequestHistoryMacroStatusKey());
                        history.setMicroStatusKey(
                                ChaseRequestHistoryMicroStatusDictionary.SendPatientDetailRequestToSourceDataFailedMicroDefault
                                        .getChaseRequestHistoryMicroStatusKey());
                        bulkInsertList.add(history);
                    }
                } else {
                    logger.error(String.format(
                            "Failed to fetch patient details for patientId: %s with encounterId: %s, TIMED OUT.",
                            encounter.getEncounterId(), encounter.getPatient().getPatientId()));
                    ChaseRequestHistory history = ChaseRequestHistoryFactory
                            .getChaseRequestHistory(chaseRequestForEncounter, clinicalDataOriginKey);
                    history.setMacroStatusKey(ChaseRequestHistoryMacroStatusDictionary.SendPatientDetailRequestToSourceDataFailed
                            .getChaseRequestHistoryMacroStatusKey());
                    history.setMicroStatusKey(ChaseRequestHistoryMicroStatusDictionary.SendPatientDetailRequestToSourceDataFailedMicroDefault
                            .getChaseRequestHistoryMicroStatusKey());
                    bulkInsertList.add(history);

                }
            }

            bulkInsertChaseRequestHistories(bulkInsertList);
        }
        return refinedEncounters;
    }

    private void bulkInsertChaseRequestHistories(Collection<ChaseRequestHistory> bulkInsertList) throws Exception {
    chaseRequestHistoryDomainData.insertBulkChaseRequest(bulkInsertList);
    }

    private Collection<ChaseRequest> getChaseRequestList(Collection<ChaseRequestGroup> crgs) throws Exception {
        long chaseRequestGroupKey = 0;
        if (crgs.iterator().hasNext()) {
            chaseRequestGroupKey = crgs.iterator().next().getChaseRequestGroupKey();
        }
        ChaseRequestGroup retrievedChaseRequestGroup = chaseRequestGroupDomainData.retrieveSingle(chaseRequestGroupKey);
        Collection<ChaseRequest> crList = retrievedChaseRequestGroup.getChaseRequests();
        return crList;
    }

    private void insertChaseRequestHistory(ChaseRequest cr, ChaseRequestHistory history, short macroStatus,
            short microStatus) throws Exception {

        ChaseRequestHistoryMicroStatus foundChaseRequestHistoryMicroStatus = ChaseRequestHistoryMicroStatusDictionary.AllEntries
                .stream().filter(x -> x.getChaseRequestHistoryMicroStatusKey() == microStatus).findFirst().orElse(null);

        if (null == foundChaseRequestHistoryMicroStatus) {
            throw new NullPointerException(String.format(
                    "ChaseRequestHistoryMicroStatus not found with ChaseRequestHistoryMicroStatusKey.  (Input MicroStatus='%1s'')",
                    microStatus));
        }

        /* the macro and micro MUST BE IN SYNC. do a check for that here */
        if (foundChaseRequestHistoryMicroStatus.getChaseRequestHistoryMacroStatusKey() != macroStatus) {
            throw new IndexOutOfBoundsException(String.format(
                    "The MacroStatus and MicroStatus values are not in sync.  (Input MicroStatus='%1s', Input MicroStatus='%2s', Expected MacroStatus='%3s'')",
                    macroStatus, microStatus,
                    foundChaseRequestHistoryMicroStatus.getChaseRequestHistoryMacroStatusKey()));
        }

        history.setMacroStatusKey(macroStatus);
        history.setMicroStatusKey(microStatus);
        cr.getChaseRequestHistories().add(history);
        chaseRequestHistoryDomainData.InsertChaseRequestHistory(history);
    }

    private List<DocumentResult> getCCDAList(List<Encounter> encounters, Collection<ChaseRequestGroup> crgs,
            IClinicalAdapter clinicalAdapter, int clinicalDataOriginKey, Collection<ClinicalDataOriginSetting> originSettings, long documentRetrieveTimeoutSeconds) throws Exception {

        Collection<ChaseRequest> crList = getChaseRequestList(crgs);
        for (Encounter encounter : encounters) {
            ChaseRequest chaseRequestForEncounter = crList.stream().filter(
                    x -> x.getParentEncounter().getEncounterUniqueIdentifier().equals(encounter.getEncounterId()))
                    .findFirst().orElse(null);
            logger.info("Getting CCDA document for Patient ID " + encounter.getPatient().getPatientId()
                    + " with encounter ID " + encounter.getEncounterId());
            ChaseRequestHistory ccdaRequest = ChaseRequestHistoryFactory
                    .getChaseRequestHistory(chaseRequestForEncounter, clinicalDataOriginKey);
            insertChaseRequestHistory(chaseRequestForEncounter, ccdaRequest,
                    ChaseRequestHistoryMacroStatusDictionary.AboutToSendCcdaRequestToSourceData
                            .getChaseRequestHistoryMacroStatusKey(),
                    ChaseRequestHistoryMicroStatusDictionary.AboutToSendCcdaRequestToSourceDataMicroDefault
                            .getChaseRequestHistoryMicroStatusKey());
        }
        @SuppressWarnings("unchecked")
        List<DocumentResult> results = ClinicalDataRetrievePerformer.retrieveCCDAdoc(encounters,
                (AsyncTaskManager<DocumentResult>) asyncTaskManager, clinicalAdapter, originSettings, documentRetrieveTimeoutSeconds);

        return results;
    }

    private List<DocumentWrapper> parseDocumentResults(List<Encounter> encounters, Collection<ChaseRequestGroup> crgs,
            List<DocumentResult> results, int clinicalDataOriginKey) throws Exception {
        List<DocumentWrapper> dwList = new ArrayList<DocumentWrapper>();
        Collection<ChaseRequestHistory> bulkInsertList = new ArrayList<>();
        Collection<ChaseRequest> crList = getChaseRequestList(crgs);

        for (Encounter encounter : encounters) {
            ChaseRequest chaseRequestForEncounter = crList.stream().filter(
                    x -> x.getParentEncounter().getEncounterUniqueIdentifier().equals(encounter.getEncounterId()))
                    .findFirst().orElse(null);
            if (!results.isEmpty()) {
                DocumentResult docResult = results.stream()
                        .filter(documentResult -> documentResult.getId().equals(encounter.getEncounterId()))
                        .findFirst().orElse(null);
                if (docResult != null) {
                    if (!docResult.isExecutedNormally()) {
                        logger.error(String.format("Error while retrieving CCDA document for encounter id: %s", docResult.getId()), docResult.getException());
                        ChaseRequestHistory ccdaResponseWithExceptions = ChaseRequestHistoryFactory
                                .getChaseRequestHistory(chaseRequestForEncounter, clinicalDataOriginKey);
                        ccdaResponseWithExceptions.setMacroStatusKey(ChaseRequestHistoryMacroStatusDictionary.SendCcdaRequestToSourceDataCompleted
                                .getChaseRequestHistoryMacroStatusKey());
                        ccdaResponseWithExceptions.setMicroStatusKey(ChaseRequestHistoryMicroStatusDictionary.SendCcdaRequestToSourceDataCompletedRequestCompletedWithException
                                .getChaseRequestHistoryMicroStatusKey());
                        bulkInsertList.add(ccdaResponseWithExceptions);
                    } else {
                        dwList.add(docResult.getDw());

                        ChaseRequestHistory ccdaRequestCompleted = ChaseRequestHistoryFactory
                                .getChaseRequestHistory(chaseRequestForEncounter, clinicalDataOriginKey);
                        ccdaRequestCompleted.setMacroStatusKey(ChaseRequestHistoryMacroStatusDictionary.SendCcdaRequestToSourceDataCompleted
                                        .getChaseRequestHistoryMacroStatusKey());
                        ccdaRequestCompleted.setMicroStatusKey(ChaseRequestHistoryMicroStatusDictionary.SendCcdaRequestToSourceDataCompletedMicroDefault
                                .getChaseRequestHistoryMicroStatusKey());
                        bulkInsertList.add(ccdaRequestCompleted);
                    }
                } else {
                    logger.error(String.format("Failed to retrieving CCDA document for encounter id: %s, TIMED OUT.",
                            encounter.getEncounterId()));
                    ChaseRequestHistory ccdaResponseTimedout = ChaseRequestHistoryFactory
                            .getChaseRequestHistory(chaseRequestForEncounter, clinicalDataOriginKey);
                    ccdaResponseTimedout.setMacroStatusKey(ChaseRequestHistoryMacroStatusDictionary.SendCcdaRequestToSourceDataCompleted
                            .getChaseRequestHistoryMacroStatusKey());
                    ccdaResponseTimedout.setMicroStatusKey(ChaseRequestHistoryMicroStatusDictionary.SendCcdaRequestToSourceDataCompletedRequestTimedOut
                    .getChaseRequestHistoryMicroStatusKey());
                    bulkInsertList.add(ccdaResponseTimedout);
                }
            }
        }
        bulkInsertChaseRequestHistories(bulkInsertList);
        return dwList;
    }

    private Map<String, List<Encounter>> getuniqueList(List<Encounter> encounters) {
        Map<String, List<Encounter>> uniqueList = new HashMap<>();
        for (Encounter encounter : encounters) {
            if (null != encounter.getPatient()) {
                if (!uniqueList.containsKey(encounter.getPatient().getPatientId())) {
                    List<Encounter> eList = new ArrayList<>();
                    eList.add(encounter);
                    uniqueList.put(encounter.getPatient().getPatientId(), eList);
                } else {
                    uniqueList.get(encounter.getPatient().getPatientId()).add(encounter);
                }
            }
        }

        return uniqueList;
    }

    private Collection<com.uhc.ucs.cdsm.domain.models.Patient> populatePatientEncounters(List<Encounter> encounters,
            ChaseRequestGroup chaseRequestGroup, int clinicalDataOriginKey) {
        Collection<com.uhc.ucs.cdsm.domain.models.Patient> patientList = new ArrayList<com.uhc.ucs.cdsm.domain.models.Patient>();
        int patientKeyReverseCounter = PatientStartNegativeSurrogateKey;
        int encounterKeyReverseCounter = EncounterStartNegativeSurrogateKey;
        int chaseRequestKeyReverseCounter = ChaseRequestStartNegativeSurrogateKey;
        int chaseRequestHistoryKeyReverseCounter = ChaseRequestHistoryStartNegativeSurrogateKey;

        Map<String, List<Encounter>> uniqueList = getuniqueList(encounters);
        Set<String> patientIDList = uniqueList.keySet();
        for (String pID : patientIDList) {
            patientKeyReverseCounter--;
            com.uhc.ucs.cdsm.domain.models.Patient patient = new com.uhc.ucs.cdsm.domain.models.Patient();
            patient.setPatientKey(patientKeyReverseCounter);
            patient.setPatientUniqueIdentifier(pID);
            patient.setClinicalDataOriginKey(clinicalDataOriginKey);
            for (Encounter encounter : uniqueList.get(pID)) {

                encounterKeyReverseCounter--;
                com.uhc.ucs.cdsm.domain.models.Encounter encounterDomain = new com.uhc.ucs.cdsm.domain.models.Encounter();
                encounterDomain.setEncounterKey(encounterKeyReverseCounter);
                encounterDomain.setEncounterUniqueIdentifier(encounter.getEncounterId());
                encounterDomain.setParentPatient(patient);
                encounterDomain.setPatientKey(patient.getPatientKey());
                encounterDomain.setClinicalDataOriginKey(clinicalDataOriginKey);

                chaseRequestKeyReverseCounter--;
                ChaseRequest currentChaseRequest = new ChaseRequest();
                currentChaseRequest.setChaseRequestKey(chaseRequestKeyReverseCounter);
                currentChaseRequest.setClinicalDataOriginKey(clinicalDataOriginKey);

                /* history */
                chaseRequestHistoryKeyReverseCounter--;
                ChaseRequestHistory currentChaseRequestHistory = new ChaseRequestHistory();
                currentChaseRequestHistory.setClinicalDataOriginKey(clinicalDataOriginKey);
                currentChaseRequestHistory.setChaseRequestHistoryKey(chaseRequestHistoryKeyReverseCounter);
                currentChaseRequestHistory.setMacroStatusKey(
                        (short) ChaseRequestHistoryMacroStatusDictionary.New.getChaseRequestHistoryMacroStatusKey());
                currentChaseRequestHistory
                        .setMicroStatusKey((short) ChaseRequestHistoryMicroStatusDictionary.NewMicroDefault
                                .getChaseRequestHistoryMicroStatusKey());

                currentChaseRequest.getChaseRequestHistories().add(currentChaseRequestHistory);
                currentChaseRequestHistory.setParentChaseRequest(currentChaseRequest);
                currentChaseRequestHistory.setChaseRequestKey(currentChaseRequest.getChaseRequestKey());

                currentChaseRequest.setParentEncounter(encounterDomain);
                currentChaseRequest.setEncounterKey(encounterDomain.getEncounterKey());
                encounterDomain.getChaseRequests().add(currentChaseRequest);

                currentChaseRequest.setParentChaseRequestGroup(chaseRequestGroup);
                currentChaseRequest.setChaseRequestGroupKey(chaseRequestGroup.getChaseRequestGroupKey());
                chaseRequestGroup.getChaseRequests().add(currentChaseRequest);

                patient.getEncounters().add(encounterDomain);
            }
            patientList.add(patient);
        }
        return patientList;
    }

    private long getPatientDetailsGetTimeoutSeconds(Collection<SystemSetting> timeoutSettings) {
        long returnValue = this.getLongSettingValue(timeoutSettings,
                SystemSettingDictionary.PatientDetailsGetTimeoutSeconds.getSystemSettingKey());
        return returnValue;
    }

    private long getDocumentRetrieveTimeoutSeconds(Collection<SystemSetting> timeoutSettings) {
        long returnValue = this.getLongSettingValue(timeoutSettings,
                SystemSettingDictionary.DocumentRetrieveTimeoutSeconds.getSystemSettingKey());
        return returnValue;
    }

    private long getLongSettingValue(Collection<SystemSetting> systemSettings, int systemSettingKey) {
        long returnValue = 0;

        if (null != this.systemSettingDomainData) {
            SystemSetting foundSystemSetting = systemSettings.stream()
                    .filter(x -> x.getSystemSettingKey() == systemSettingKey).findFirst().orElse(null);

            if (null == foundSystemSetting) {
                throw new NullPointerException(String
                        .format("SystemSetting was null or zero count. (SystemSettingKey='%s')", systemSettingKey));
            }

            returnValue = Long.parseLong(foundSystemSetting.getSettingValue());
        } else {
            throw new NullPointerException("SystemSettingDomainData was null");
        }

        return returnValue;
    }

}
