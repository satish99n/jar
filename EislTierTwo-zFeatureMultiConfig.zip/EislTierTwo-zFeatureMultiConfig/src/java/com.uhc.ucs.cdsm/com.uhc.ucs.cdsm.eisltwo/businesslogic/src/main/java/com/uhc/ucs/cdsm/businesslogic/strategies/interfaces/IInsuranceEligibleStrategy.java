package com.uhc.ucs.cdsm.businesslogic.strategies.interfaces;

import com.uhc.ucs.cdsm.domain.models.Patient;

/* Interface for Insurance Eligible Strategies.  As in,  "Strategy Design Pattern" https://www.dofactory.com/net/strategy-design-pattern */
/* Make each strategy independent so that the strategies can be mixed and matched per specific EHR */
public interface IInsuranceEligibleStrategy {
	boolean passesTest(Patient pat);
}
