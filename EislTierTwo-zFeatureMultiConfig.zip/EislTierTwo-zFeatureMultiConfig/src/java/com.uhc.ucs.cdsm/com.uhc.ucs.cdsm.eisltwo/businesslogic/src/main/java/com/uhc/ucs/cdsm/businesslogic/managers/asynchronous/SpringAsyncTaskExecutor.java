package com.uhc.ucs.cdsm.businesslogic.managers.asynchronous;

import java.util.concurrent.Future;

import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncResult;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncTask;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncTaskExecutor;

public class SpringAsyncTaskExecutor<V> implements AsyncTaskExecutor<V> {
	
	private org.springframework.core.task.AsyncTaskExecutor asyncTaskExecutor;
	
	public SpringAsyncTaskExecutor(org.springframework.core.task.AsyncTaskExecutor asyncTaskExecutor) {
		this.asyncTaskExecutor = asyncTaskExecutor;
	}

	@Override
	public Future<AsyncResult<V>> executeAsyncTask(AsyncTask<V> task) {
		return asyncTaskExecutor.submit(task);
	}

}
