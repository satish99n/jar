package com.uhc.ucs.cdsm.businesslogic.managers;

import java.util.Collection;
import java.util.UUID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.domain.models.ClinicalDataOrigin;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.IDeploymentConfiguration;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IInstanceToDataOriginLinkDomainData;

public class DeploymentInstanceManager {

    private final Log logger;
    private IDeploymentConfiguration deploymentConfiguration;
    private IInstanceToDataOriginLinkDomainData instanceToDataOriginLinkDomainData;

    public DeploymentInstanceManager(IDeploymentConfiguration deploymentConfiguration,
            IInstanceToDataOriginLinkDomainData instanceToDataOriginLinkDomainData) {
        this.logger = LogFactory.getLog(DeploymentInstanceManager.class);
        this.deploymentConfiguration = deploymentConfiguration;
        this.instanceToDataOriginLinkDomainData = instanceToDataOriginLinkDomainData;
    }

    public DeploymentInstanceManager(Log lgr, IDeploymentConfiguration deploymentConfiguration,
            IInstanceToDataOriginLinkDomainData instanceToDataOriginLinkDomainData) {
        this.logger = lgr;
        this.deploymentConfiguration = deploymentConfiguration;
        this.instanceToDataOriginLinkDomainData = instanceToDataOriginLinkDomainData;
    }

    public Collection<ClinicalDataOrigin> getActiveClinicalDataOrigins() throws Exception {
        String deploymentInstanceUUID = deploymentConfiguration.getDeploymentInstanceUUID();
        //TODO: return only active ClinicalDataOrigins.
        return instanceToDataOriginLinkDomainData
                .getClinicalDataOriginLinks(UUID.fromString(deploymentInstanceUUID));
    }

}
