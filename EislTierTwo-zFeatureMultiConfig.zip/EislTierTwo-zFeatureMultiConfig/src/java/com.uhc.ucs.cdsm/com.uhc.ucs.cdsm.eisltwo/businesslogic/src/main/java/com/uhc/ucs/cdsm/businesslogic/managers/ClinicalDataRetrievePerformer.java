package com.uhc.ucs.cdsm.businesslogic.managers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.uhc.ucs.cdsm.adapters.adaptersbase.interfaces.IClinicalAdapter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.DocumentRetrieverTaskImpl;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.PatientRetrieveTaskImpl;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncResult;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncTask;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncTaskManager;
import com.uhc.ucs.cdsm.businesslogic.model.DocumentResult;
import com.uhc.ucs.cdsm.businesslogic.model.PatientResult;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;

public class ClinicalDataRetrievePerformer {

    private ClinicalDataRetrievePerformer() {
    }

    public static List<PatientResult> retrievePatients(List<Encounter> encounts,
            AsyncTaskManager<PatientResult> asyncTaskManager, IClinicalAdapter clinicalAdapter, Collection<ClinicalDataOriginSetting> originSettings,  long patientDetailsGetTimeoutSeconds) {
        final List<AsyncTask<PatientResult>> patientRetrieveList = new ArrayList<>();
        List<PatientResult> results = new ArrayList<>();

        for (Encounter encounter : encounts) {
            patientRetrieveList
                    .add(new PatientRetrieveTaskImpl(encounter.getPatient().getPatientId(), clinicalAdapter, originSettings));
        }

        List<AsyncResult<PatientResult>> tasksResults = asyncTaskManager.executeTasks(patientRetrieveList, patientDetailsGetTimeoutSeconds);
        for (AsyncResult<PatientResult> taskResult : tasksResults) {
            if(taskResult != null) {
            results.add(taskResult.getResult());
            }
        }
        return results;
    }

    public static List<DocumentResult> retrieveCCDAdoc(List<Encounter> encounters,
            AsyncTaskManager<DocumentResult> asyncTaskManager, IClinicalAdapter clinicalAdapter, Collection<ClinicalDataOriginSetting> originSettings,  long documentRetrieveTimeoutSeconds) {
        List<AsyncTask<DocumentResult>> docRetrieverList = new ArrayList<>();
        List<DocumentResult> results = new ArrayList<>();
        for (Encounter encounter : encounters) {
            docRetrieverList.add(new DocumentRetrieverTaskImpl(encounter.getEncounterId(),
                    encounter.getPatient().getPatientId(), clinicalAdapter, originSettings));
        }
        List<AsyncResult<DocumentResult>> taskResults = asyncTaskManager.executeTasks(docRetrieverList, documentRetrieveTimeoutSeconds);
        for (AsyncResult<DocumentResult> taskResult : taskResults) {
            if(taskResult != null) {
            results.add(taskResult.getResult());
            }
        }
        return results;
    }

}
