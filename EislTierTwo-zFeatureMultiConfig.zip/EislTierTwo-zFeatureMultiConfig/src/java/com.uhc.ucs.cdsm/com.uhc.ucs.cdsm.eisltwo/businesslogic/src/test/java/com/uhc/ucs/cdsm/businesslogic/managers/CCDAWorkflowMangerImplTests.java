package com.uhc.ucs.cdsm.businesslogic.managers;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;
import com.uhc.ucs.cdsm.adapters.adaptersbase.interfaces.IClinicalAdapter;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncTaskManager;
import com.uhc.ucs.cdsm.businesslogic.managers.interfaces.ICCDAWorkflowManger;
import com.uhc.ucs.cdsm.businesslogic.managers.interfaces.IEncounterManager;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IChaseRequestGroupDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IChaseRequestGroupHistoryDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IChaseRequestHistoryDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IEncounterDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IPatientDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.ISystemSettingDomainData;
import com.uhc.ucs.cdsm.eisltwo.exportservices.interfaces.IExportCCDAService;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.impl.SimpleLog;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class CCDAWorkflowMangerImplTests {

    private static PrintStream originalStdout;

    @BeforeClass
    public static void setUp() throws Exception {

        originalStdout = System.out;
    }

    @AfterClass
    public static void tearDown() throws Exception {

        System.setOut(originalStdout);
    }

    private ByteArrayOutputStream setupSimpleLog(Log lgr) {
        ByteArrayOutputStream pipeOut = new ByteArrayOutputStream();
        PrintStream pipeIn = new PrintStream(pipeOut);
        System.setErr(pipeIn);
        return pipeOut;
    }

    private Log getSimpleLog() {
        Log lgr = new SimpleLog("simplelog");
        return lgr;
    }

    @Test
    public void noEncountersTest() {

        /* TRUE unit test, every dependency is mocked */

        Log lgr = getSimpleLog();
        ByteArrayOutputStream pipeOut = this.setupSimpleLog(lgr);

        IClinicalAdapter iClinicalAdapterMock = this.getDefaultIClinicalAdapterMock(0);
        DeploymentInstanceManager deploymentInstanceManager = this.getDeploymentInstanceManager();
        IExportCCDAService iExportCCDAServiceMock = this.getDefaultIExportCCDAServiceMock();
        IChaseRequestHistoryDomainData iChaseRequestHistoryDomainDataMock = this
                .getDefaultIChaseRequestHistoryDomainDataMock();
        IChaseRequestGroupHistoryDomainData iChaseRequestGroupHistoryDomainDataMock = this
                .getDefaultIChaseRequestGroupHistoryDomainDataMock();
        IChaseRequestGroupDomainData iChaseRequestGroupDomainDataMock = this
                .getDefaultIChaseRequestGroupDomainDataMock();
        IPatientDomainData iPatientDomainDataMock = this.getDefaultIPatientDomainDataMock();
        ISystemSettingDomainData iSystemSettingDomainDataMock = this.getDefaultISystemSettingDomainDataMock();
        IEncounterDomainData iEncounterDomainDataMock = this.getDefaultIEncounterDomainDataMock();
        IEncounterManager iEncounterManagerMock = this.getDefaultIEncounterManagerMock();
        AsyncTaskManager<?> asyncTaskManagerMock = this.getDefaultAsyncTaskManagerMock();

        Map<String, IClinicalAdapter> clinicalAdapterMap =  this.getClinialAdapters();
        /*
         * INJECT the logger, so logged events can be verified. sometimes a log event is
         * the only clue to what road the code went down
         */
        ICCDAWorkflowManger testItem = new CCDAWorkflowMangerImpl(lgr, deploymentInstanceManager, iExportCCDAServiceMock,
                iChaseRequestHistoryDomainDataMock, iSystemSettingDomainDataMock,
                iChaseRequestGroupHistoryDomainDataMock, iChaseRequestGroupDomainDataMock, iPatientDomainDataMock,
                iEncounterManagerMock, asyncTaskManagerMock, clinicalAdapterMap);

        Date fromDate = new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000);
        Date toDate = new Date();

        String msg = String.format(CCDAWorkflowMangerImpl.NO_CLINICAL_ADAPTERS, fromDate, toDate);

        try {
            testItem.performWorkflow(fromDate, toDate);
            String output = new String(pipeOut.toByteArray());

            /* A unit-test MUST assert something */
            assertTrue(output.contains(msg));
            pipeOut.close();

        } catch (ClinicalDataException e) {
            fail();
        } catch (IOException e) {
            fail();
            e.printStackTrace();
        } catch (InterruptedException e) {
            fail();
            e.printStackTrace();
        } catch (ExecutionException e) {
            fail();
            e.printStackTrace();
        } catch (Exception e) {
            fail();
            e.printStackTrace();
        }
    }

    private Map<String, IClinicalAdapter> getClinialAdapters() {
        Map<String, IClinicalAdapter> clinialAdapterMap = new HashMap<>();
        clinialAdapterMap.put("defaultAdapter", this.getDefaultIClinicalAdapterMock(1));
        return clinialAdapterMap;
    }

    //@Test // TODO TO DO, fix this test for one happy path run
    public void happyPathEverythingWorksTest() {

        /* TRUE unit test, every dependency is mocked */

        Log lgr = getSimpleLog();
        ByteArrayOutputStream pipeOut = this.setupSimpleLog(lgr);

        DeploymentInstanceManager deploymentInstanceManager = this.getDeploymentInstanceManager();
        IExportCCDAService iExportCCDAServiceMock = this.getDefaultIExportCCDAServiceMock();
        IChaseRequestHistoryDomainData iChaseRequestHistoryDomainDataMock = this
                .getDefaultIChaseRequestHistoryDomainDataMock();
        IChaseRequestGroupHistoryDomainData iChaseRequestGroupHistoryDomainDataMock = this
                .getDefaultIChaseRequestGroupHistoryDomainDataMock();
        IChaseRequestGroupDomainData iChaseRequestGroupDomainDataMock = this
                .getDefaultIChaseRequestGroupDomainDataMock();
        IPatientDomainData iPatientDomainDataMock = this.getDefaultIPatientDomainDataMock();
        ISystemSettingDomainData iSystemSettingDomainDataMock = this.getDefaultISystemSettingDomainDataMock();
        IEncounterDomainData iEncounterDomainDataMock = this.getDefaultIEncounterDomainDataMock();
        IEncounterManager iEncounterManagerMock = this.getDefaultIEncounterManagerMock();
        AsyncTaskManager<?> asyncTaskManagerMock = this.getDefaultAsyncTaskManagerMock();
        Map<String, IClinicalAdapter> clinicalAdapterMap =  this.getClinialAdapters();

        /*
         * INJECT the logger, so logged events can be verified. sometimes a log event is
         * the only clue to what road the code went down
         */
        ICCDAWorkflowManger testItem = new CCDAWorkflowMangerImpl(lgr, deploymentInstanceManager, iExportCCDAServiceMock,
                iChaseRequestHistoryDomainDataMock, iSystemSettingDomainDataMock,
                iChaseRequestGroupHistoryDomainDataMock, iChaseRequestGroupDomainDataMock, iPatientDomainDataMock,
                iEncounterManagerMock, asyncTaskManagerMock, clinicalAdapterMap);

        Date fromDate = new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000);
        Date toDate = new Date();

        String msg = String.format(CCDAWorkflowMangerImpl.MessageNoEncounters, fromDate, toDate);

        try {
            testItem.performWorkflow(fromDate, toDate);
            String output = new String(pipeOut.toByteArray());
            assertTrue(output.contains(msg));
            pipeOut.close();

        } catch (ClinicalDataException e) {
            fail();
        } catch (IOException e) {
            fail();
            e.printStackTrace();
        } catch (InterruptedException e) {
            fail();
            e.printStackTrace();
        } catch (ExecutionException e) {
            fail();
            e.printStackTrace();
        } catch (Exception e) {
            fail();
            e.printStackTrace();
        }
    }



    private DeploymentInstanceManager getDeploymentInstanceManager() {

        return mock(DeploymentInstanceManager.class);
    }

    private IClinicalAdapter getDefaultIClinicalAdapterMock(int numberEncounters) {

        IClinicalAdapter mockItem = mock(IClinicalAdapter.class);

        Collection<com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter> encounters = getDefaultEncounters(
                numberEncounters);
        List<com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter> encounterList = new ArrayList<com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter>(
                encounters);

        try {
            when(mockItem.getEncounters(any(Date.class), any(Date.class), any(Collection.class))).thenReturn(encounterList);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return mockItem;
    }

    private Collection<com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter> getDefaultEncounters(
            int numberEncounters) {
        Collection<com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter> items = new ArrayList<com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter>();
        if (numberEncounters > 0) {
            for (int i = 0; i <= numberEncounters; i++) {
                com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter enc = new com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter();
                /* TO DO, FILL OUT PROPERTIES HERE */
                items.add(enc);
            }
        }
        return items;
    }

    private IExportCCDAService getDefaultIExportCCDAServiceMock() {

        IExportCCDAService mockItem = mock(IExportCCDAService.class);
        return mockItem;
    }

    IChaseRequestHistoryDomainData getDefaultIChaseRequestHistoryDomainDataMock() {

        IChaseRequestHistoryDomainData mockItem = mock(IChaseRequestHistoryDomainData.class);
        return mockItem;
    }

    IChaseRequestGroupHistoryDomainData getDefaultIChaseRequestGroupHistoryDomainDataMock() {

        IChaseRequestGroupHistoryDomainData mockItem = mock(IChaseRequestGroupHistoryDomainData.class);
        return mockItem;
    }

    IChaseRequestGroupDomainData getDefaultIChaseRequestGroupDomainDataMock() {

        IChaseRequestGroupDomainData mockItem = mock(IChaseRequestGroupDomainData.class);

        ChaseRequestGroup crg = getDefaultChaseRequestGroup();

        try {
            when(mockItem.upsertSingle(any(ChaseRequestGroup.class))).thenReturn(crg);
            when(mockItem.retrieveSingle(anyInt())).thenReturn(crg);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return mockItem;
    }

    private ChaseRequestGroup getDefaultChaseRequestGroup() {
        ChaseRequestGroup returnItem = new ChaseRequestGroup();
        return returnItem;
    }

    IPatientDomainData getDefaultIPatientDomainDataMock() {

        IPatientDomainData mockItem = mock(IPatientDomainData.class);

        // no longer needed in Java 8 //
        // Collection<com.uhc.ucs.cdsm.domain.models.Patient> anyPats =
        // org.mockito.Matchers.any();

        Collection<ChaseRequestGroup> crgs = getDefaultChaseRequestGroupCollection();

        try {
            when(mockItem.UpsertPatientsAndEncounters(any())).thenReturn(crgs);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return mockItem;
    }

    private Collection<ChaseRequestGroup> getDefaultChaseRequestGroupCollection() {
        Collection<ChaseRequestGroup> items = new ArrayList<ChaseRequestGroup>();
        items.add(this.getDefaultChaseRequestGroup());
        return items;
    }

    ISystemSettingDomainData getDefaultISystemSettingDomainDataMock() {

        ISystemSettingDomainData mockItem = mock(ISystemSettingDomainData.class);
        return mockItem;
    }

    IEncounterDomainData getDefaultIEncounterDomainDataMock() {
        IEncounterDomainData mockItem = mock(IEncounterDomainData.class);
        return mockItem;
    }

    IEncounterManager getDefaultIEncounterManagerMock() {
        IEncounterManager mockItem = mock(IEncounterManager.class);
        return mockItem;
    }

    AsyncTaskManager<?> getDefaultAsyncTaskManagerMock() {

        AsyncTaskManager<?> mockItem = mock(AsyncTaskManager.class);
        return mockItem;
    }
}
