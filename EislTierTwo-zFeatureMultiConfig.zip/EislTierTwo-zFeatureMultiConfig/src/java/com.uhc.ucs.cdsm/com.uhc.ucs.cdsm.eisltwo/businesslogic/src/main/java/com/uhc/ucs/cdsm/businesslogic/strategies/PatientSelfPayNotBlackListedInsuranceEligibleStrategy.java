package com.uhc.ucs.cdsm.businesslogic.strategies;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.businesslogic.managers.DeploymentInstanceManager;
import com.uhc.ucs.cdsm.businesslogic.managers.EncounterManager;
import com.uhc.ucs.cdsm.businesslogic.strategies.interfaces.IInsuranceEligibleStrategy;
import com.uhc.ucs.cdsm.domain.models.Patient;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.ISystemSettingDomainData;

public class PatientSelfPayNotBlackListedInsuranceEligibleStrategy implements IInsuranceEligibleStrategy {

	private final Log logger;
	private ISystemSettingDomainData systemSettingDomainData;

	public PatientSelfPayNotBlackListedInsuranceEligibleStrategy(ISystemSettingDomainData systemSettingDomainData) {
		this.logger = LogFactory.getLog(EncounterManager.class);
		this.systemSettingDomainData = systemSettingDomainData;
	}
	
	public PatientSelfPayNotBlackListedInsuranceEligibleStrategy(Log lgr, ISystemSettingDomainData systemSettingDomainData) {
		this.logger = LogFactory.getLog(DeploymentInstanceManager.class);
		this.systemSettingDomainData = systemSettingDomainData;
	}

	@Override
	public boolean passesTest(Patient pat) {
		/* TO DO, implement this Strategy.  Current issue is that logic needs to be implemented against com.uhc.ucs.cdsm.domain.models(.Patient), not allscripts specific ones  */
		return false;
	}
	
}
