package com.uhc.ucs.cdsm.adapters.allscriptsadapter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;
import com.uhc.ucs.cdsm.adapters.adaptersbase.interfaces.IClinicalAdapter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.DocumentWrapper;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Patient;
import com.uhc.ucs.cdsm.adapters.allscriptsadapter.util.ConnectionUtil;
import com.uhc.ucs.cdsm.adapters.allscriptsadapter.util.DomainConverter;
import com.uhc.ucs.cdsm.domain.models.ClinicalDataOriginSetting;
import com.uhc.ucs.cdsm.eisltwo.configuration.originsettingstoconfiguration.ConfigurationUtil;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;

public class AllscriptClinicalAdapterImpl implements IClinicalAdapter {

    private final Log log = LogFactory.getLog(AllscriptClinicalAdapterImpl.class);
    private ConnectionUtil connectionUtil;

    private final String SCHEDULE_ACTION = "GetSchedule";
    private final String PATIENT_FULL = "GetPatientFull";
    private final String CCDA_ACTION = "GetCCDA";
    private final String get_schedule = "getscheduleinfo";
    private final String get_patient = "getpatientfullinfo";
    private final String get_ccda = "getccdainfo";

    public AllscriptClinicalAdapterImpl(ConnectionUtil connectionUtil) {
        this.connectionUtil = connectionUtil;
    }

    @Override
    public List<Encounter> getEncounters(Date fromDate, Date toDate,
            Collection<ClinicalDataOriginSetting> originSettings) throws ClinicalDataException {

        log.debug("Entering into AllScripts getEncounters method ------->");
        ITWConfiguration twConfiguration = ConfigurationUtil.createTWConfigurtion(originSettings);
        List<Encounter> encounters = new ArrayList<>();
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
            String strDate = formatter.format(fromDate);
            String endDate = formatter.format(toDate);

            final String response = connectionUtil.createAndSendRequest(twConfiguration, SCHEDULE_ACTION, "",
                    strDate + "|" + endDate);

            if (response != null && !response.contains("Error")) {
                final JsonObject responseObj = (JsonObject) new JsonParser().parse(response).getAsJsonArray().get(0);
                JsonArray encounterArray = responseObj.get(get_schedule).getAsJsonArray();
                for (JsonElement encounter : encounterArray) {
                    JsonObject eleObj = encounter.getAsJsonObject();
                    Encounter ent = DomainConverter.getEncounter(eleObj);
                    encounters.add(ent);
                }
            }
        } catch (ClinicalDataException e) {
            throw new ClinicalDataException(e);
        }
        log.info("Found " + encounters.size() + " encounters");
        return encounters;
    }

    @Override
    public Patient getPatientDetails(String patientID, Collection<ClinicalDataOriginSetting> originSettings)
            throws ClinicalDataException {

        log.debug("Entering into AllScripts getPatientDetails method ------->");
        ITWConfiguration twConfiguration = ConfigurationUtil.createTWConfigurtion(originSettings);
        Patient patient = new Patient();
        final String response = connectionUtil.createAndSendRequest(twConfiguration, PATIENT_FULL, patientID, "");

        if (response != null && !response.contains("Error")) {
            final JsonObject responseObj = (JsonObject) new JsonParser().parse(response).getAsJsonArray().get(0);
            JsonArray patientDetailsArray = responseObj.get(get_patient).getAsJsonArray();
            JsonObject patientDetailsObj = patientDetailsArray.get(0).getAsJsonObject();
            patient = DomainConverter.getPatient(patientDetailsObj);
            log.info("Found patient details for ID " + patient.getPatientId());
            return patient;
        } else {
            throw new ClinicalDataException("Response: " + response);
        }

    }

    @Override
    public DocumentWrapper getCCDA(String patientID, String encounterID,
            Collection<ClinicalDataOriginSetting> originSettings) throws ClinicalDataException {

        log.debug("Entering into AllScripts getCCDA method ------->");
        ITWConfiguration twConfiguration = ConfigurationUtil.createTWConfigurtion(originSettings);
        boolean validUser = connectionUtil.isValidUser(twConfiguration, patientID);
        if(!validUser) {
            throw new ClinicalDataException("not a valid user.");
        }
        final String response = connectionUtil.createAndSendRequest(twConfiguration, CCDA_ACTION, patientID,
                encounterID);
        if (response != null && !response.contains("Error")) {
            log.info("Fetched CCDA document for encounter " + encounterID);
            final JsonObject ccdaObj = (JsonObject) new JsonParser().parse(response).getAsJsonArray().get(0);
            JsonArray xmlEle = ccdaObj.get(get_ccda).getAsJsonArray();
            JsonObject xmlObj = xmlEle.get(0).getAsJsonObject();
            DocumentWrapper dw = new DocumentWrapper();
            dw = DomainConverter.getDWrapper(xmlObj);
            dw.setEncounterID(encounterID);
            dw.setDocumentCreationTime(Calendar.getInstance().getTime());
            return dw;
        } else {
            throw new ClinicalDataException("Response: " + response);
        }
    }

}
