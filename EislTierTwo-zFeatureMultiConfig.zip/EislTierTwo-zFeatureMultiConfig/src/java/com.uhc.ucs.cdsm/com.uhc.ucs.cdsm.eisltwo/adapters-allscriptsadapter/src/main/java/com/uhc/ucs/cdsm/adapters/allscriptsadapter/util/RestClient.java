package com.uhc.ucs.cdsm.adapters.allscriptsadapter.util;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import javax.annotation.PreDestroy;
import javax.net.ssl.SSLContext;
import javax.security.cert.CertificateException;
import javax.security.cert.X509Certificate;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HeaderElement;
import org.apache.http.HeaderElementIterator;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeaderElementIterator;
import org.apache.http.protocol.HTTP;
import org.apache.http.protocol.HttpContext;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;

import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;

public class RestClient {
      private final Log log = LogFactory.getLog(RestClient.class);
     private CloseableHttpClient client = null;

     public void init() throws ClinicalDataException {

            try {

                final SSLContext sslcontext = SSLContexts.custom().loadTrustMaterial(null, new TrustStrategy() {
                    @SuppressWarnings("unused")
                    public boolean isTrusted(final X509Certificate[] chain, final String authType)
                            throws CertificateException {
                        return true;
                    }

                    public boolean isTrusted(final java.security.cert.X509Certificate[] arg0, final String arg1)
                            throws java.security.cert.CertificateException {
                        return false;
                    }
                }).build();

                final ConnectionKeepAliveStrategy myStrategy = new ConnectionKeepAliveStrategy() {
                    public long getKeepAliveDuration(final HttpResponse response, final HttpContext context) {
                        final HeaderElementIterator it = new BasicHeaderElementIterator(
                                response.headerIterator(HTTP.CONN_KEEP_ALIVE));
                        while (it.hasNext()) {
                            final HeaderElement he = it.nextElement();
                            final String param = he.getName();
                            final String value = he.getValue();
                            if (value != null && param.equalsIgnoreCase("timeout")) {
                                return Long.parseLong(value) * 1000;
                            }
                        }
                        return 5 * 1000;
                    }
                };

                final SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, null, null,
                        new NoopHostnameVerifier());

                client = HttpClients.custom().setKeepAliveStrategy(myStrategy).setSSLSocketFactory(sslsf).build();

            } catch (final KeyManagementException e) {
                throw new ClinicalDataException("Invalid Key", e);
            } catch (final NoSuchAlgorithmException e) {
                throw new ClinicalDataException("NoSuchAlgorithm", e);
            } catch (final KeyStoreException e) {
                throw new ClinicalDataException("Invalid KeyStore ", e);
            }

        }

     public String executeRequest(final HttpRequestBase request) throws ClinicalDataException {

            log.debug("executing request: " + request);
            String response = null;
            CloseableHttpResponse res = null;

            try {
                res = client.execute(request);

                final HttpEntity entity = res.getEntity();
                response = entity == null ? null : EntityUtils.toString(entity, StandardCharsets.UTF_8);

            } catch (final IOException ex) {
                throw new ClinicalDataException("connection issue", ex);
            } finally {
                try {
                    if (res != null) {
                        res.close();
                    }
                } catch (final IOException ex) {
                    throw new ClinicalDataException("connection issue", ex);
                }
            }

            return response;
        }

     @PreDestroy
     public void close() throws ClinicalDataException {
         if (client != null) {
             try {
                 client.close();
             } catch (final IOException ex) {
                 throw new ClinicalDataException("connection issue", ex);
             }
         }
     }
}
