package com.uhc.ucs.cdsm.adapters.allscriptsadapter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

import com.uhc.ucs.cdsm.adapters.allscriptsadapter.util.TokenCacheManager;

public class TokenCacheManagerTest {

    private TokenCacheManager cacheManager = new TokenCacheManager();
    @Test
    public void testGetToken() {
        cacheManager.addTokenToCache(0, "token1");
        String tokenReceived = cacheManager.getTokenFromCache(0);
        assertNotNull(tokenReceived);
        assertEquals("token1", tokenReceived);
    }

    @Test
    public void testGetTokenIfKeyNotExists() {
        String tokenReceived = cacheManager.getTokenFromCache(0);
        assertNull(tokenReceived);
    }
}
