package com.uhc.ucs.cdsm.adapters.allscriptsadapter.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TokenCacheManager {

    private Map<Integer,String> tokenCache = new ConcurrentHashMap<>();

    public void addTokenToCache(int clinicalDataOriginKey, String token) {
        tokenCache.put(clinicalDataOriginKey, token);
    }

    public String getTokenFromCache(int clinicalDataOriginKey) {
        return tokenCache.get(clinicalDataOriginKey);
    }

}
