package com.uhc.ucs.cdsm.adapters.allscriptsadapter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

import java.net.URI;
import java.net.URISyntaxException;

import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.google.gson.JsonObject;
import com.uhc.ucs.cdsm.adapters.allscriptsadapter.util.ConnectionUtil;
import com.uhc.ucs.cdsm.adapters.allscriptsadapter.util.RestClient;
import com.uhc.ucs.cdsm.adapters.allscriptsadapter.util.TokenCacheManager;
import com.uhc.ucs.cdsm.eisltwo.configuration.originsettingstoconfiguration.TWConfigurationImpl;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;

@RunWith(MockitoJUnitRunner.class)
public class ConnectionUtilTest {

    ITWConfiguration twConfiguration = mock(TWConfigurationImpl.class);
    CloseableHttpClient client;
    RestClient restClient = mock(RestClient.class);

    @Before
    public void setup() throws URISyntaxException {

        client = HttpClients.custom().build();
    }

    @Test
    public void getTokenTest() {

        when(twConfiguration.getTWUnitySvcUser()).thenReturn("test");
        when(twConfiguration.getTWUnitySvcPassword()).thenReturn("test");
        when(twConfiguration.getTWUnityEndpoint())
                .thenReturn("testurl");
        TokenCacheManager chacheManager  = mock(TokenCacheManager.class);
        ConnectionUtil connUtil = new ConnectionUtil(chacheManager,restClient);
        String token = null;
        String response = "testToken";
        HttpPost request = mock(HttpPost.class);
        try {
            final JsonObject jb = new JsonObject();
            jb.addProperty("Username", twConfiguration.getTWUnitySvcUser());
            jb.addProperty("Password", twConfiguration.getTWUnitySvcPassword());
          /* request = new HttpPost(new URI(url.toString()));
            final StringEntity strEntity = new StringEntity(jb.toString(), ContentType.APPLICATION_JSON);
            request.setEntity(strEntity);*/
            when(connUtil.createPostRequest(jb, "test")).thenReturn(request);
            when(restClient.executeRequest(request)).thenReturn("testToken");
            token = connUtil.getToken(twConfiguration);
            assertNotNull(token);
            assertEquals(response, token);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
