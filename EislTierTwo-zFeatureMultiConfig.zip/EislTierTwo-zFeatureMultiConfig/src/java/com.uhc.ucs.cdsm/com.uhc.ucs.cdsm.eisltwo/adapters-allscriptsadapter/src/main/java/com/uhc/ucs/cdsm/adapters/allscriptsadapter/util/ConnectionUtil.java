package com.uhc.ucs.cdsm.adapters.allscriptsadapter.util;

import java.net.URI;
import java.net.URISyntaxException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;

public class ConnectionUtil {

    private final Log log = LogFactory.getLog(ConnectionUtil.class);
    private TokenCacheManager cacheManager = null;
    private final String INVALID_TOKEN_ERROR_MESSAGE = "logged out";
    private RestClient restClient = null;

    public ConnectionUtil(TokenCacheManager cacheManager, RestClient restClient) {
        this.cacheManager = cacheManager;
        this.restClient = restClient;
    }

    public String getToken(ITWConfiguration twConfiguration) throws ClinicalDataException {

        log.debug("Requesting for Token");
        final JsonObject jb = new JsonObject();

        jb.addProperty("Username", twConfiguration.getTWUnitySvcUser());
        jb.addProperty("Password", twConfiguration.getTWUnitySvcPassword());

        HttpPost post;
        try {
            post = createPostRequest(jb, twConfiguration.getTWUnityEndpoint());
            String response = restClient.executeRequest(post);
            if (response.contains("Error")) {
                log.error("Token response received as: " + response);
                throw new ClinicalDataException("Invalid token: " + jb.get("Username"));
            }
            log.debug("Token response :" + response);
            return response;
        } catch (URISyntaxException e) {
            throw new ClinicalDataException("Invalid URI", e);
        }

    }

    public HttpPost createPostRequest(final JsonObject jb, final String urlString) throws URISyntaxException {
        final StringBuilder url = new StringBuilder(urlString);
        url.append("GetToken");
        HttpPost post;
        post = new HttpPost(new URI(url.toString()));
        final StringEntity strEntity = new StringEntity(jb.toString(), ContentType.APPLICATION_JSON);
        post.setEntity(strEntity);
        return post;
    }

    public String createAndSendRequest(ITWConfiguration twConfiguration, String action, String patientID, String param1)
            throws ClinicalDataException {

        String response = "";
        final Gson gson = new Gson();
        final JsonObject jb = new JsonObject();
        jb.addProperty("Action", action);
        jb.addProperty("Appname", twConfiguration.getTWUnityAppname());
        jb.addProperty("AppUserID", twConfiguration.getTWUnityUser());
        jb.addProperty("PatientID", patientID);
        String token = cacheManager.getTokenFromCache(twConfiguration.getClinicalDataOriginKey());
        if (token == null) {
            token = getToken(twConfiguration);
            cacheManager.addTokenToCache(twConfiguration.getClinicalDataOriginKey(), token);
        }
        jb.addProperty("Token", token);
        jb.addProperty("Parameter1", param1);
        jb.addProperty("Parameter2", "");
        jb.addProperty("Parameter3", "");
        jb.addProperty("Parameter4", "");
        jb.addProperty("Parameter5", "");
        jb.addProperty("Parameter6", "");
        jb.addProperty("Data", gson.toJson(null));
        final StringBuilder url = new StringBuilder(twConfiguration.getTWUnityEndpoint());
        url.append("MagicJson");
        HttpPost post;

        try {
            post = new HttpPost(new URI(url.toString()));
            log.debug("Created request: " + url.toString());

            final StringEntity strEntity = new StringEntity(jb.toString(), ContentType.APPLICATION_JSON);
            post.setEntity(strEntity);
            response = restClient.executeRequest(post);
            if (response.contains(INVALID_TOKEN_ERROR_MESSAGE)) {
                String tokenReGenerated = getToken(twConfiguration);
                cacheManager.addTokenToCache(twConfiguration.getClinicalDataOriginKey(), tokenReGenerated);
                response = createAndSendRequest(twConfiguration, action, patientID, param1);
            }
        } catch (URISyntaxException e) {
            throw new ClinicalDataException("Invalid URI", e);
        }
        return response;
    }

    public boolean isValidUser(ITWConfiguration twConfiguration, String patientID) throws ClinicalDataException {
        final String response = createAndSendRequest(twConfiguration, "GetUserAuthentication", patientID,
                twConfiguration.getTWUnityPassword());
        if (response != null && !response.contains("\"Error\":")) {
            final JsonObject obj = (JsonObject) new JsonParser().parse(response).getAsJsonArray().get(0);
            JsonArray ele = obj.get("getuserauthenticationinfo").getAsJsonArray();
            JsonObject eleObj = ele.get(0).getAsJsonObject();

            String isValidUser = eleObj.get("ValidUser").toString();
            if (isValidUser.contains("YES")) {
                return true;
            }
        }
        return false;
    }

}
