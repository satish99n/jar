package com.uhc.ucs.cdsm.adapters.allscriptsadapter.util;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.JsonObject;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.DocumentWrapper;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Insurance;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Patient;

public class DomainConverter {

	public static Encounter getEncounter(JsonObject jsonObj) {
		Encounter ent = new Encounter();

		ent.setAppointmentLocation(jsonObj.get("Location").getAsString());
		ent.setAppointmentTime(jsonObj.get("ApptTime").getAsString());
		ent.setApptNumberEXT(jsonObj.get("ApptNumberEXT").getAsString());
		String entID = jsonObj.get("Encounterid").getAsString();
		ent.setEncounterId(entID);
		ent.setEncounterStatus(jsonObj.get("Status").getAsString());
		ent.setOrganizationMRN(jsonObj.get("organizationMRN").getAsString());
		ent.setVisitNumberExt(jsonObj.get("VisitNumberExt").getAsString());
		ent.setPatient(getPatient(jsonObj));
		return ent;
	}

	public static Patient getPatient(JsonObject jsonObj) {
		Patient patient = new Patient();

		if (jsonObj.has("PatientID")) {
			String pID = jsonObj.get("PatientID").getAsString();
			patient.setPatientId(pID);
		}
		else if(jsonObj.has("patientID")) {
			String pID = jsonObj.get("patientID").getAsString();
			patient.setPatientId(pID);
		}

		if (jsonObj.has("PatientFirstName"))
			patient.setPatientFirstName(jsonObj.get("PatientFirstName").getAsString());

		if (jsonObj.has("PatientLastName"))
			patient.setPatientLastName(jsonObj.get("PatientLastName").getAsString());

		if (jsonObj.has("MRN"))
			patient.setMrn(jsonObj.get("MRN").getAsString());
		List<Insurance> insuranceList = new ArrayList<>();
		Insurance insurance;
		if(jsonObj.has("PrimaryInsurance")) {
			insurance = getInsurance(jsonObj, "PrimaryInsurance");
			insuranceList.add(insurance);
		}
		if(jsonObj.has("SecondaryInsurance")) {
			insurance = getInsurance(jsonObj, "SecondaryInsurance");
			insuranceList.add(insurance);
		}
		if(jsonObj.has("TertiaryInsurance")) {
			insurance = getInsurance(jsonObj, "TertiaryInsurance");
			insuranceList.add(insurance);
		}
		if(jsonObj.has("QuartaneryInsurance")) {
			insurance = getInsurance(jsonObj, "QuartaneryInsurance");
			insuranceList.add(insurance);
		}
		if(jsonObj.has("QuinaryInsurance")) {
			insurance = getInsurance(jsonObj, "QuinaryInsurance");
			insuranceList.add(insurance);
		}
		patient.setInsuranceList(insuranceList);

		return patient;
	}

	public static Insurance getInsurance(JsonObject jsonObj, String insuranceType) {
		
		Insurance insurance = new Insurance();
		if (jsonObj.has(insuranceType))
		insurance.setInsuranceName(jsonObj.get(insuranceType).getAsString());
		if (jsonObj.has(insuranceType+"Class"))
		insurance.setInsuranceClass(jsonObj.get(insuranceType+"Class").getAsString());
		insurance.setType(Insurance.Type.getTypeByValue(insuranceType));

		return insurance;
	}

	public static DocumentWrapper getDWrapper(JsonObject je) {
		DocumentWrapper dw = new DocumentWrapper();

		dw.setDocument(je.get("ccdaxml").getAsString().getBytes());

		return dw;
	}

}
