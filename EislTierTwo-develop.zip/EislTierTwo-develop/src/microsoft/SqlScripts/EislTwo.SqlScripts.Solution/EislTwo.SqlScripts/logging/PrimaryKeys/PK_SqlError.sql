﻿ALTER TABLE [logging].[SqlError]
	ADD CONSTRAINT [PK_SqlError]
	PRIMARY KEY (SqlErrorKey)
