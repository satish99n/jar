﻿CREATE TABLE [logging].[SqlError]
(
	  SqlErrorKey			BIGINT NOT NULL IDENTITY(-9223372036854775808 , 1)
	, ErrorNumber			INT
	, ErrorSeverity			INT
	, ErrorState			INT
	, ErrorProcedure		NVARCHAR(128)
	, ErrorLine				INT
	, ErrorMessage			NVARCHAR(4000)
	, XmlFragment			NVARCHAR(MAX) NULL
	, InsertDate			DATETIME			CONSTRAINT [DF_SqlError_InsertDate]	DEFAULT CURRENT_TIMESTAMP NOT NULL
    , InsertedBy			NVARCHAR(64)		CONSTRAINT [DF_SqlError_InsertedBy]	DEFAULT SUSER_SNAME() NOT NULL
)
