﻿CREATE TABLE [history].[EncounterInsuranceHistory]
(
		[EncounterInsuranceHistoryKey]              BIGINT			NOT NULL IDENTITY(1,1) 
       ,[EncounterKey]                              BIGINT			NOT NULL /* FK to Encounter */
	   ,[InsuranceIdentifierType]					SMALLINT				NULL
       ,[BeforeInsuranceIdentifier]          		VARCHAR(256)	NULL
       ,[AfterInsuranceIdentifier]					VARCHAR(256)	NULL
       ,[OriginalRowLastUpdatedDate]                DATETIME		NOT NULL
       ,[InsertDate]                                DATETIME        CONSTRAINT [DF_EncounterInsuranceHistory_InsertDate]	DEFAULT CURRENT_TIMESTAMP NOT NULL
       ,[InsertedBy]								NVARCHAR(64)    CONSTRAINT [DF_EncounterInsuranceHistory_InsertedBy]	DEFAULT SUSER_SNAME() NOT NULL
)