﻿ALTER TABLE [lookup].[ChaseRequestGroupHistoryMicroStatus]
	ADD CONSTRAINT [FK_ChaseRequestGroupHistory_MicroToMacro]
	FOREIGN KEY (ChaseRequestGroupHistoryMacroStatusKey)
	REFERENCES [lookup].[ChaseRequestGroupHistoryMacroStatus] (ChaseRequestGroupHistoryMacroStatusKey)
