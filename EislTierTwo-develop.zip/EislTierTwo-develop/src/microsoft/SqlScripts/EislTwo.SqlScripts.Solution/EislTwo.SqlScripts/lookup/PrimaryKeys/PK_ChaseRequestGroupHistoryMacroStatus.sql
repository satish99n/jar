﻿ALTER TABLE [lookup].[ChaseRequestGroupHistoryMacroStatus]
	ADD CONSTRAINT [PK_ChaseRequestGroupHistoryMacroStatus]
	PRIMARY KEY (ChaseRequestGroupHistoryMacroStatusKey)
