﻿ALTER TABLE [lookup].[ChaseRequestHistoryMicroStatus]
	ADD CONSTRAINT [PK_ChaseRequestHistoryMicroStatus]
	PRIMARY KEY (ChaseRequestHistoryMicroStatusKey)
