﻿CREATE TABLE [lookup].[ChaseRequestGroupHistoryMicroStatus]
(
	ChaseRequestGroupHistoryMicroStatusKey	SMALLINT		NOT NULL,
    ChaseRequestGroupHistoryMicroStatusName	VARCHAR(64)     NOT NULL,
	ChaseRequestGroupHistoryMacroStatusKey	SMALLINT		NOT NULL, /* FK to "Parent" */
    InsertDate								DATETIME        CONSTRAINT [DF_ChaseRequestGroupHistoryMicroStatus_InsertDate]		DEFAULT CURRENT_TIMESTAMP	NOT NULL,
    InsertedBy								NVARCHAR(64)    CONSTRAINT [DF_ChaseRequestGroupHistoryMicroStatus_InsertedBy]		DEFAULT SUSER_SNAME()		NOT NULL,
    LastUpdated								DATETIME        CONSTRAINT [DF_ChaseRequestGroupHistoryMicroStatus_LastUpdated]		DEFAULT CURRENT_TIMESTAMP	NOT NULL,
    LastUpdatedBy							NVARCHAR(64)    CONSTRAINT [DF_ChaseRequestGroupHistoryMicroStatus_LastUpdatedBy]	DEFAULT SUSER_SNAME()		NOT NULL
)
