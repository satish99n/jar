﻿ALTER TABLE [lookup].[ChaseRequestHistoryMacroStatus]
	ADD CONSTRAINT [PK_ChaseRequestGroupMacroStatus]
	PRIMARY KEY (ChaseRequestHistoryMacroStatusKey)
