﻿ALTER TABLE [lookup].[ChaseRequestHistoryMicroStatus]
	ADD CONSTRAINT [FK_ChaseRequestHistory_MicroToMacro]
	FOREIGN KEY (ChaseRequestHistoryMacroStatusKey)
	REFERENCES [lookup].[ChaseRequestHistoryMacroStatus] (ChaseRequestHistoryMacroStatusKey)
