﻿CREATE TABLE [lookup].[ChaseRequestGroupHistoryMacroStatus]
(
	ChaseRequestGroupHistoryMacroStatusKey	SMALLINT	NOT NULL,
    ChaseRequestGroupHistoryMacroStatusName	VARCHAR(64)     NOT NULL,
    InsertDate								DATETIME        CONSTRAINT [DF_ChaseRequestGroupHistoryMacroStatus_InsertDate]		DEFAULT CURRENT_TIMESTAMP NOT NULL,
    InsertedBy								NVARCHAR(64)    CONSTRAINT [DF_ChaseRequestGroupHistoryMacroStatus_InsertedBy]		DEFAULT SUSER_SNAME() NOT NULL,
    LastUpdated								DATETIME        CONSTRAINT [DF_ChaseRequestGroupHistoryMacroStatus_LastUpdated]		DEFAULT CURRENT_TIMESTAMP NOT NULL,
    LastUpdatedBy							NVARCHAR(64)    CONSTRAINT [DF_ChaseRequestGroupHistoryMacroStatus_LastUpdatedBy]	DEFAULT SUSER_SNAME() NOT NULL
)
