﻿ALTER TABLE [dbo].[ChaseRequest]
	ADD CONSTRAINT [PK_ChaseRequest]
	PRIMARY KEY ([ChaseRequestKey])
