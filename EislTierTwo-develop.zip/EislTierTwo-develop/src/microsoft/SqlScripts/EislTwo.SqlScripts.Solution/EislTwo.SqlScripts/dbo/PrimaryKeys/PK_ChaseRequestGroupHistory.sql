﻿ALTER TABLE [dbo].[ChaseRequestGroupHistory]
	ADD CONSTRAINT [PK_ChaseRequestGroupHistory]
	PRIMARY KEY (ChaseRequestGroupHistoryKey)
