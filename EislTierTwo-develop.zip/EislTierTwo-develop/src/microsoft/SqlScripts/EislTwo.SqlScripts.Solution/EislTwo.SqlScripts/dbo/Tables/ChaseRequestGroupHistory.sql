﻿CREATE TABLE [dbo].[ChaseRequestGroupHistory]
(
	[ChaseRequestGroupHistoryKey]			BIGINT NOT NULL IDENTITY(1, 1),
	[ChaseRequestGroupKey]					BIGINT NOT NULL, /* FK */
	[MacroStatusKey]						SMALLINT NOT NULL,
	[MicroStatusKey]						SMALLINT NOT NULL,
    InsertDate								DATETIME        CONSTRAINT [DF_ChaseRequestGroupHistory_InsertDate]		DEFAULT CURRENT_TIMESTAMP NOT NULL,
    InsertedBy								NVARCHAR(64)    CONSTRAINT [DF_ChaseRequestGroupHistory_InsertedBy]		DEFAULT SUSER_SNAME() NOT NULL,
    LastUpdated								DATETIME        CONSTRAINT [DF_ChaseRequestGroupHistory_LastUpdated]	DEFAULT CURRENT_TIMESTAMP NOT NULL,
    LastUpdatedBy							NVARCHAR(64)    CONSTRAINT [DF_ChaseRequestGroupHistory_LastUpdatedBy]	DEFAULT SUSER_SNAME() NOT NULL
)
