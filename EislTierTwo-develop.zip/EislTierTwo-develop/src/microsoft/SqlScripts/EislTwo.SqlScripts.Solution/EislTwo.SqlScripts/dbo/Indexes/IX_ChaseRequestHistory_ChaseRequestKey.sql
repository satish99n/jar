﻿CREATE NONCLUSTERED INDEX IX_ChaseRequestHistory_ChaseRequestKey 
ON [dbo].[ChaseRequestHistory]([ChaseRequestKey])