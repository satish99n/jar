﻿ALTER TABLE [dbo].[ChaseRequestGroupHistory]
	ADD CONSTRAINT [FK_ChaseRequestGroupHistoryToChaseRequestGroup]
	FOREIGN KEY (ChaseRequestGroupKey)
	REFERENCES [ChaseRequestGroup] (ChaseRequestGroupKey)
