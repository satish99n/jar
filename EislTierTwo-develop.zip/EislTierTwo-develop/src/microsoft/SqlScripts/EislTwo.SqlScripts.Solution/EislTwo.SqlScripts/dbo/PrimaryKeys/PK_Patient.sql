﻿ALTER TABLE [dbo].[Patient]
	ADD CONSTRAINT [PK_Patient]
	PRIMARY KEY (PatientKey)
