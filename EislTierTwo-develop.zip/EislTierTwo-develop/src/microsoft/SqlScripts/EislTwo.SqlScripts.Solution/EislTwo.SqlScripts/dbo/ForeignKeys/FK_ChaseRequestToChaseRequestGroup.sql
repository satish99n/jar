﻿ALTER TABLE [dbo].[ChaseRequest]
	ADD CONSTRAINT [FK_ChaseRequestToChaseRequestGroup]
	FOREIGN KEY (ChaseRequestGroupKey)
	REFERENCES [ChaseRequestGroup] (ChaseRequestGroupKey)
