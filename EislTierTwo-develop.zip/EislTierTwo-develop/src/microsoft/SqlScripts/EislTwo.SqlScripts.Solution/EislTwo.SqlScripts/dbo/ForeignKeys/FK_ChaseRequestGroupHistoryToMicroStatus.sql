﻿ALTER TABLE [dbo].[ChaseRequestGroupHistory]
	ADD CONSTRAINT [FK_ChaseRequestGroupHistoryToMicroStatus]
	FOREIGN KEY (MicroStatusKey)
	REFERENCES lookup.[ChaseRequestGroupHistoryMicroStatus] (ChaseRequestGroupHistoryMicroStatusKey)
