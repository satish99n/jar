﻿CREATE PROCEDURE [dbo].[uspChaseRequestGroupHistoryInsertSingle]
	@ChaseRequestGroupKey BIGINT
	, @MacroStatusKey SMALLINT
	, @MicroStatusKey SMALLINT
AS

BEGIN

	SET NOCOUNT ON

	DECLARE @ChaseRequestGroupHistoryKeyIdentity BIGINT 

	INSERT INTO [dbo].[ChaseRequestGroupHistory]
			   ([ChaseRequestGroupKey]
			   ,[MacroStatusKey]
			   ,[MicroStatusKey])
		 VALUES
			   (
				@ChaseRequestGroupKey
				, @MacroStatusKey
				, @MicroStatusKey
				)

		SELECT @ChaseRequestGroupHistoryKeyIdentity = IDENT_CURRENT('[dbo].[ChaseRequestGroupHistory]')

		SELECT  
			alias.[ChaseRequestGroupHistoryKey]
			, alias.[ChaseRequestGroupKey]
			, alias.[MacroStatusKey]
			, alias.[MicroStatusKey]
			, alias.[InsertDate]
			, alias.[InsertedBy]
			, alias.[LastUpdated]
			, alias.[LastUpdatedBy] 
		FROM [ChaseRequestGroupHistory] alias
		WHERE
			alias.ChaseRequestGroupHistoryKey = @ChaseRequestGroupHistoryKeyIdentity

	SET NOCOUNT OFF

END