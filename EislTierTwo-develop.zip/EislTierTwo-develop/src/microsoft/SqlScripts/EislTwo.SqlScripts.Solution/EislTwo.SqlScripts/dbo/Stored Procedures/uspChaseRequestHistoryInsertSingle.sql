﻿CREATE PROCEDURE [dbo].[uspChaseRequestHistoryInsertSingle]
	@ChaseRequestKey BIGINT
	, @MacroStatusKey SMALLINT
	, @MicroStatusKey SMALLINT
AS

BEGIN

	SET NOCOUNT ON

	DECLARE @ChaseRequestHistoryKeyIdentity BIGINT 

	INSERT INTO [dbo].[ChaseRequestHistory]
			   ([ChaseRequestKey]
			   ,[MacroStatusKey]
			   ,[MicroStatusKey])
		 VALUES
			   (
				@ChaseRequestKey
				, @MacroStatusKey
				, @MicroStatusKey
				)

		SELECT @ChaseRequestHistoryKeyIdentity = IDENT_CURRENT('[dbo].[ChaseRequestHistory]')

		SELECT  
			alias.[ChaseRequestHistoryKey]
			, alias.[ChaseRequestKey]
			, alias.[MacroStatusKey]
			, alias.[MicroStatusKey]
			, alias.[InsertDate]
			, alias.[InsertedBy]
			, alias.[LastUpdated]
			, alias.[LastUpdatedBy] 
		FROM [ChaseRequestHistory] alias
		WHERE
			alias.ChaseRequestHistoryKey = @ChaseRequestHistoryKeyIdentity

	SET NOCOUNT OFF

END