﻿ALTER TABLE [dbo].[ChaseRequest]
	ADD CONSTRAINT [FK_ChaseRequestToEncounter]
	FOREIGN KEY (EncounterKey)
	REFERENCES [dbo].[Encounter] (EncounterKey)
