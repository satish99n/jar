﻿ALTER TABLE [dbo].[ChaseRequestHistory]
	ADD CONSTRAINT [FK_ChaseRequestHistoryToChaseRequest]
	FOREIGN KEY (ChaseRequestKey)
	REFERENCES [ChaseRequest] (ChaseRequestKey)
