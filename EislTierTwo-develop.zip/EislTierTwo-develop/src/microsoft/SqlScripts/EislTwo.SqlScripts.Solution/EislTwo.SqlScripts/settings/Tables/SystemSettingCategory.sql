﻿CREATE TABLE [settings].[SystemSettingCategory] (
       [SystemSettingCategoryKey]					[INT] NOT NULL,
       [SystemSettingCategoryName]					[NVARCHAR](128) NOT NULL, 
	   CONSTRAINT [PK_SystemSettingCategory]		PRIMARY KEY ([SystemSettingCategoryKey]),
	   CONSTRAINT [UC_SystemSettingCategoryKey]		UNIQUE ([SystemSettingCategoryKey]),
       CONSTRAINT [UC_SystemSettingCategoryName]	UNIQUE ([SystemSettingCategoryName])
) 

GO     