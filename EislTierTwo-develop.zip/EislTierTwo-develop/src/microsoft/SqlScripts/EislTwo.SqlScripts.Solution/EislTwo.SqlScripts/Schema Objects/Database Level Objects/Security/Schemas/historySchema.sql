﻿/* history schema is about deltas in key data points */
/* first need for this is Encounter.[PrimaryInsuranceIdentifier] and [SecondaryInsuranceIdentifier]. */
/* these tables are NEVER truncated */
CREATE SCHEMA [history] AUTHORIZATION [dbo]