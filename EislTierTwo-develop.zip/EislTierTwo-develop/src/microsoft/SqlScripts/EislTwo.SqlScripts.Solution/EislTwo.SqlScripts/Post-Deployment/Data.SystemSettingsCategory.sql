﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/


/* DEVELOPER READ ME

IF YOU CHANGE THIS FILE, YOU NEED TO UPDATE THE ~DICTIONARY~ java file.
	com.uhc.ucs.cdsm.domain.dictionaries.SystemSettingCategoryDictionary

*/

SET NOCOUNT ON

/* Please use 
Title Case, aka Initial Caps, aka Proper Case for SystemSettingCategoryName
*/
 
MERGE INTO [settings].[SystemSettingCategory] AS TARGET
USING
(
	VALUES
		  (1,	'Queue Watch Process Settings')
		, (2,	'United Healthcare Insurance Name Regex')
		, (3,	'Schedular Job Settings')
		, (4,	'Blacklist Insurance Name Regex')
		, (5,	'Default Timeouts')
) 
AS SOURCE ([SystemSettingCategoryKey], [SystemSettingCategoryName])
ON (TARGET.[SystemSettingCategoryKey] = SOURCE.[SystemSettingCategoryKey])

WHEN MATCHED THEN
	UPDATE SET
		[SystemSettingCategoryName] = SOURCE.[SystemSettingCategoryName]

WHEN NOT MATCHED BY TARGET THEN
	INSERT([SystemSettingCategoryKey], [SystemSettingCategoryName])
	VALUES(SOURCE.[SystemSettingCategoryKey], SOURCE.[SystemSettingCategoryName])

WHEN NOT MATCHED BY SOURCE THEN 
 DELETE; 
GO

DECLARE @mergeError INT, @mergeCount INT

SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT
IF (@mergeError != 0)
BEGIN
	PRINT 'ERROR OCCURRED IN MERGE FOR [SystemSettingCategory]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); 
END
ELSE
BEGIN
	PRINT '[SystemSettingCategory] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));
END
GO
 
SET NOCOUNT OFF
GO
