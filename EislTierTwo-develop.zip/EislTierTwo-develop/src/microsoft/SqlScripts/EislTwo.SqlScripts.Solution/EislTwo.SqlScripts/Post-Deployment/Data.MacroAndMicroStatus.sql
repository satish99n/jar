﻿

/* DEVELOPER README
	IF YOU MAKE CHANGES TO THIS FILE, YOU NEED TO UPDATE THE DICTIONARIES IN THE JAVA.
*/

SET NOCOUNT ON
 
MERGE INTO [lookup].[ChaseRequestHistoryMacroStatus] AS TARGET
USING
(
	VALUES
		(1,	'New')
		, (31,	'About To Send Patient Detail Request To Source Data')
		, (34,	'Send Patient Detail Request To Source Data Completed')
		, (37,	'Send Patient Detail Request To Source Data Failed')
		, (51,	'About To Send Ccda Request To Source Data')
		, (54,	'Send Ccda Request To Source Data Completed')
		, (57,	'Send Ccda Request To Source Data Failed')
		/* below values are about sftp-delivery for pilot */
		, (81,	'About To Send Results To Destination')
		, (84,	'Send Results To Destination Completed')
		, (87,	'Send Results To Destination Failed')
		, (999,	'Ended')
) 
AS SOURCE ([ChaseRequestHistoryMacroStatusKey], [ChaseRequestHistoryMacroStatusName])
ON (TARGET.[ChaseRequestHistoryMacroStatusKey] = SOURCE.[ChaseRequestHistoryMacroStatusKey])

WHEN MATCHED THEN
	UPDATE SET
		[ChaseRequestHistoryMacroStatusName] = SOURCE.[ChaseRequestHistoryMacroStatusName]

WHEN NOT MATCHED BY TARGET THEN
	INSERT([ChaseRequestHistoryMacroStatusKey], [ChaseRequestHistoryMacroStatusName])
	VALUES(SOURCE.[ChaseRequestHistoryMacroStatusKey], SOURCE.[ChaseRequestHistoryMacroStatusName])

WHEN NOT MATCHED BY SOURCE THEN 
 DELETE; 
GO

DECLARE @mergeError INT, @mergeCount INT

SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT
IF (@mergeError != 0)
BEGIN
	PRINT 'ERROR OCCURRED IN MERGE FOR [ChaseRequestHistoryMacroStatus]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); 
END
ELSE
BEGIN
	PRINT '[ChaseRequestHistoryMacroStatus] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));
END
GO

/* ---------------- */

MERGE INTO [lookup].[ChaseRequestHistoryMicroStatus] AS TARGET
USING
(
	VALUES
		(1001,	'Micro Default', 1)
		, (1031,	'Micro Default' , 31)
		, (1034,	'Micro Default' , 34)
		, (1037,	'Micro Default' , 37)
		, (1051,	'Micro Default' , 51)
		, (1054,	'Micro Default' , 54)
		, (1055,	'Request Completed With Exception' , 54)
		, (1056,	'Request Timed Out' , 54)
		, (1057,	'Micro Default' , 57)
		, (1081,	'Micro Default' , 81)
		, (1084,	'Micro Default' , 84)
		, (1087,	'Micro Default' , 87)
		, (9991,	'Result Delivered To Destination' , 999)
		, (9992,	'Insurance Information Did Not Match. Early Exit.' , 999)
		, (9993,	'Ended With Error' , 999)
) 
AS SOURCE ([ChaseRequestHistoryMicroStatusKey], [ChaseRequestHistoryMicroStatusName], [ChaseRequestHistoryMacroStatusKey])
ON (TARGET.[ChaseRequestHistoryMicroStatusKey] = SOURCE.[ChaseRequestHistoryMicroStatusKey])

WHEN MATCHED THEN
	UPDATE SET
		[ChaseRequestHistoryMicroStatusName] = SOURCE.[ChaseRequestHistoryMicroStatusName]
		, [ChaseRequestHistoryMacroStatusKey] = SOURCE.[ChaseRequestHistoryMacroStatusKey]

WHEN NOT MATCHED BY TARGET THEN
	INSERT([ChaseRequestHistoryMicroStatusKey], [ChaseRequestHistoryMicroStatusName], [ChaseRequestHistoryMacroStatusKey])
	VALUES(SOURCE.[ChaseRequestHistoryMicroStatusKey], SOURCE.[ChaseRequestHistoryMicroStatusName], SOURCE.[ChaseRequestHistoryMacroStatusKey])

WHEN NOT MATCHED BY SOURCE THEN 
 DELETE; 
GO

DECLARE @mergeError INT, @mergeCount INT

SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT
IF (@mergeError != 0)
BEGIN
	PRINT 'ERROR OCCURRED IN MERGE FOR [ChaseRequestHistoryMicroStatus]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); 
END
ELSE
BEGIN
	PRINT '[ChaseRequestHistoryMicroStatus] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));
END
GO
 
/* */


MERGE INTO [lookup].[ChaseRequestGroupHistoryMacroStatus] AS TARGET
USING
(
	VALUES
		(5,	'New')
		, (15,	'About To Send Bulk Encounter Request To Source Data')
		, (25,	'Send Bulk Encounter Request To Source Data Completed')
		, (26,	'Send Bulk Encounter Request To Source Data Failed')
		, (55,	'Partially Complete')
		, (105,	'Completed With Some Errors')
		, (155,	'Completed With No Errors')

) 
AS SOURCE ([ChaseRequestGroupHistoryMacroStatusKey], [ChaseRequestGroupHistoryMacroStatusName])
ON (TARGET.[ChaseRequestGroupHistoryMacroStatusKey] = SOURCE.[ChaseRequestGroupHistoryMacroStatusKey])

WHEN MATCHED THEN
	UPDATE SET
		[ChaseRequestGroupHistoryMacroStatusName] = SOURCE.[ChaseRequestGroupHistoryMacroStatusName]

WHEN NOT MATCHED BY TARGET THEN
	INSERT([ChaseRequestGroupHistoryMacroStatusKey], [ChaseRequestGroupHistoryMacroStatusName])
	VALUES(SOURCE.[ChaseRequestGroupHistoryMacroStatusKey], SOURCE.[ChaseRequestGroupHistoryMacroStatusName])

WHEN NOT MATCHED BY SOURCE THEN 
 DELETE; 
GO

DECLARE @mergeError INT, @mergeCount INT

SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT
IF (@mergeError != 0)
BEGIN
	PRINT 'ERROR OCCURRED IN MERGE FOR [ChaseRequestGroupHistoryMacroStatus]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); 
END
ELSE
BEGIN
	PRINT '[ChaseRequestGroupHistoryMacroStatus] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));
END
GO

/* ---------------- */

MERGE INTO [lookup].[ChaseRequestGroupHistoryMicroStatus] AS TARGET
USING
(
	VALUES
		(1005,	'Micro Default', 5)
		, (1015,	'Micro Default', 15)
		, (1025,	'Micro Default', 25)
		, (1026,	'Micro Default', 26)
		, (1027,	'No Encounters found', 25)
		, (1055,	'Micro Default', 55)
		, (1105,	'Micro Default', 105)
		, (1155,	'Micro Default', 155)
) 
AS SOURCE ([ChaseRequestGroupHistoryMicroStatusKey], [ChaseRequestGroupHistoryMicroStatusName], [ChaseRequestGroupHistoryMacroStatusKey])
ON (TARGET.[ChaseRequestGroupHistoryMicroStatusKey] = SOURCE.[ChaseRequestGroupHistoryMicroStatusKey])

WHEN MATCHED THEN
	UPDATE SET
		[ChaseRequestGroupHistoryMicroStatusName] = SOURCE.[ChaseRequestGroupHistoryMicroStatusName]
		, [ChaseRequestGroupHistoryMacroStatusKey] = SOURCE.[ChaseRequestGroupHistoryMacroStatusKey]

WHEN NOT MATCHED BY TARGET THEN
	INSERT([ChaseRequestGroupHistoryMicroStatusKey], [ChaseRequestGroupHistoryMicroStatusName], [ChaseRequestGroupHistoryMacroStatusKey])
	VALUES(SOURCE.[ChaseRequestGroupHistoryMicroStatusKey], SOURCE.[ChaseRequestGroupHistoryMicroStatusName], SOURCE.[ChaseRequestGroupHistoryMacroStatusKey])

WHEN NOT MATCHED BY SOURCE THEN 
 DELETE; 
GO

DECLARE @mergeError INT, @mergeCount INT

SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT
IF (@mergeError != 0)
BEGIN
	PRINT 'ERROR OCCURRED IN MERGE FOR [ChaseRequestGroupHistoryMicroStatus]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); 
END
ELSE
BEGIN
	PRINT '[ChaseRequestGroupHistoryMicroStatus] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));
END
GO
 

SET NOCOUNT OFF
GO
