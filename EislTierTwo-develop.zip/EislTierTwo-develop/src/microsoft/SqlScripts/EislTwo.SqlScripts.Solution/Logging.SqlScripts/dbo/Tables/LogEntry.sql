﻿CREATE TABLE [dbo].[LogEntry]
(
	[LogEntryKey]			BIGINT NOT NULL IDENTITY(-9223372036854775808 , 1),
	[EntryDateUtc]			[DATETIMEOFFSET](7) NOT NULL,
	[Logger]				[VARCHAR](248) NOT NULL,
	[Level]					[VARCHAR](16) NOT NULL,
	[Message]				[VARCHAR](MAX) NOT NULL,
	[UserName]				[VARCHAR](128) NULL,
	[Priority]				[VARCHAR](16) NULL,
	[ElapsedMilliseconds]	[BIGINT] NULL,
	[ThreadName]			[VARCHAR](MAX) NULL,
	[Location]				[VARCHAR](100) NULL,
	[ThrowableMessage]		[VARCHAR](MAX) NULL
)
