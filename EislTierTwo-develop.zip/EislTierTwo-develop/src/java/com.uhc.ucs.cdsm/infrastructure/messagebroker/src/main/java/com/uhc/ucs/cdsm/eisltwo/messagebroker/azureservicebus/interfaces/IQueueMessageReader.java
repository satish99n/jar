package com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.interfaces;

import java.util.function.Function;

import com.microsoft.windowsazure.services.servicebus.models.BrokeredMessage;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.arguments.QueueMessageReadArgs;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.compositions.ReadResult;

public interface IQueueMessageReader<T> {
	public  ReadResult<String> readMessage(QueueMessageReadArgs args, Function<BrokeredMessage, BrokeredMessage> handleMessageFunction) throws Exception;
}
