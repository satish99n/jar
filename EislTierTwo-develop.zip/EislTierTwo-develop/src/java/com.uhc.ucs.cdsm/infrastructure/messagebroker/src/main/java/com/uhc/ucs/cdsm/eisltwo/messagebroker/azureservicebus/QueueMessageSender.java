package com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus;

import org.apache.commons.logging.Log;

import javax.xml.datatype.*;

import com.microsoft.windowsazure.Configuration;
import com.microsoft.windowsazure.exception.ServiceException;
import com.microsoft.windowsazure.services.servicebus.ServiceBusConfiguration;
import com.microsoft.windowsazure.services.servicebus.ServiceBusContract;
import com.microsoft.windowsazure.services.servicebus.ServiceBusService;
import com.microsoft.windowsazure.services.servicebus.models.BrokeredMessage;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.interfaces.IQueueMessageSender;

public class QueueMessageSender implements IQueueMessageSender<String> {

	private final Log logger;

	public QueueMessageSender(Log lgr) {

		if (null == lgr) {
			throw new IllegalArgumentException("Log is null");
		}

		this.logger = lgr;
	}

	@Override
	public void sendMessage(String connectionString, String queueName, String payload) throws ServiceException {
		try {
			Configuration config = new Configuration();
			ServiceBusConfiguration.configureWithConnectionString(null, config, connectionString);
			ServiceBusContract service = ServiceBusService.create(config);
			BrokeredMessage message = new BrokeredMessage(payload);
			service.sendQueueMessage(queueName, message);
		} catch (ServiceException ex) {
			this.logger.error(ex.getMessage(), ex);
			throw ex;
		}
	}
}