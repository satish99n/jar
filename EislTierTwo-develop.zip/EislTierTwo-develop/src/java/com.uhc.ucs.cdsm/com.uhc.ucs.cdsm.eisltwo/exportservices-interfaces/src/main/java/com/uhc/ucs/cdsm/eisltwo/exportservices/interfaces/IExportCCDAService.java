package com.uhc.ucs.cdsm.eisltwo.exportservices.interfaces;

import java.io.IOException;

import org.apache.ftpserver.ftplet.FtpException;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.uhc.ucs.cdsm.eisltwo.exportservices.models.DocumentDetailsWrapper;

public interface IExportCCDAService {

	public void exportDocument(DocumentDetailsWrapper documentdetailsWrapper) throws IOException, FtpException, SftpException, JSchException;

}
