package com.uhc.ucs.cdsm.businesslogic.managers;

import java.util.ArrayList;
import java.util.List;

import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter;
import com.uhc.ucs.cdsm.domain.models.ChaseRequest;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistory;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistoryMacroStatus;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistory;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistoryMacroStatus;
import com.uhc.ucs.cdsm.domain.models.Patient;

public class ChaseRequestHistoryFactory {

	public static ChaseRequestHistory getChaseRequestHistory(ChaseRequestHistoryMacroStatus status) {
		ChaseRequest chR = new ChaseRequest();
		chR.setChaseRequestKey(-222);

		ChaseRequestHistory chrH = new ChaseRequestHistory();
		chrH.setChaseRequestHistoryKey(-466);
		chrH.setMacroStatusKey(status.getChaseRequestHistoryMacroStatusKey());

		chR.getChaseRequestHistories().add(chrH);

		chrH.setParentChaseRequest(chR);
		return chrH;
	}
	
	public static List<ChaseRequestHistory> getChaseRequestHistory(List<Encounter> encounters, ChaseRequestHistoryMacroStatus status) {

		List<ChaseRequestHistory> lchRH = new ArrayList<ChaseRequestHistory>();
		for (Encounter enc : encounters) {
			com.uhc.ucs.cdsm.domain.models.Encounter ent = Mapper.mapEncounter(enc);
			Patient patient = new Patient();

			patient.setPatientKey(-11);
			patient.setPatientUniqueIdentifier(enc.getPatient().getPatientId());

			ent.setEncounterKey(-22);
			ent.setParentPatient(patient);

			ChaseRequest chR = new ChaseRequest();
			chR.setParentEncounter(ent);
			ent.getChaseRequests().add(chR);

			ChaseRequestHistory chrH = new ChaseRequestHistory();
			chrH.setChaseRequestHistoryKey(-333);
			chrH.setMacroStatusKey(status.getChaseRequestHistoryMacroStatusKey());
			chrH.setParentChaseRequest(chR);

			lchRH.add(chrH);
		}

		return lchRH;	}
	
	public static ChaseRequestHistory getChaseRequestHistory(ChaseRequest cr) {

		ChaseRequestHistory chrH = new ChaseRequestHistory();
		chrH.setChaseRequestHistoryKey(-3333);
		chrH.setParentChaseRequest(cr);
		chrH.setChaseRequestKey(cr.getChaseRequestKey());
		
		return chrH;
	}

	public static ChaseRequestGroupHistory getChaseRequestGroupHistory(
			ChaseRequestGroupHistoryMacroStatus status) {
		
		ChaseRequestGroupHistory crgh = new ChaseRequestGroupHistory();
		crgh.setMacroStatusKey(status.getChaseRequestGroupHistoryMacroStatusKey());
		crgh.setChaseRequestGroupHistoryKey(-111111);
		
		return crgh;
	}
}
