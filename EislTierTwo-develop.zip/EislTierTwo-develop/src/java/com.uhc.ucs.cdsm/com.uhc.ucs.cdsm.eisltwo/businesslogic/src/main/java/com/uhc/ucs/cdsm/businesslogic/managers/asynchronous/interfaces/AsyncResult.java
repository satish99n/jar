package com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces;

public interface AsyncResult<V> {
	
	/**
     * Returns the exception occurred while executing work asynchronously.
     * 
     * @return the exception.
     */
    Exception getException();

    /**
     * Returns the Id of task that is correlation between
     * task and result.
     * 
     * @return the Id.
     */
    String getId();

    /**
     * Returns the Result from the async operation.
     * 
     * @return Generic Result.
     */
    V getResult();

    /**
     * Returns if the async work is executed normally without any exceptions.
     * 
     * @return executedNormally.
     */
    boolean isExecutedNormally();

    /**
     * Holds the exception occurred while executing work asynchronously.
     * 
     * @param exception
     *            the exception.
     */
    void setException(Exception exception);

    /**
     * Holds if the async work is executed normally without any exceptions.
     * 
     * @param executedNormally
     *            the executedNormally.
     */
    void setExecutedNormally(boolean executedNormally);

    /**
     * Holds the Id attribute that is used to manage the correlation between
     * work and result.
     * 
     * @param Id
     *            the Id
     */
    void setId(String Id);

    /**
     * Sets the Result from the async operation.
     * 
     * @param result
     *            the Result.
     */
    void setResult(V result);

}
