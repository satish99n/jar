package com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces;

import java.util.List;

public interface AsyncTaskManager<V> {
	List<AsyncResult<V>> executeTasks(List<AsyncTask<V>> task);
	
	List<AsyncResult<V>> executeTasks(List<AsyncTask<V>> task, long timeoutSeconds);
}
