package com.uhc.ucs.cdsm.businesslogic.model;

import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Patient;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncResult;

public class PatientResult implements AsyncResult<PatientResult> {

	private String patientId;
	private Patient patient;
	private boolean executedNormally;
	private Exception exception;

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	@Override
	public Exception getException() {
		return exception;
	}

	@Override
	public String getId() {
		return patientId;
	}

	@Override
	public boolean isExecutedNormally() {
		return executedNormally;
	}

	@Override
	public void setException(Exception exception) {
		this.exception = exception;
	}

	@Override
	public void setExecutedNormally(boolean executedNormally) {
		this.executedNormally = executedNormally;

	}

	@Override
	public void setId(String Id) {
		this.patientId = Id;
	}

	@Override
	public PatientResult getResult() {
		return this;
	}

	@Override
	public void setResult(PatientResult result) {
		// TODO Auto-generated method stub

	}

}
