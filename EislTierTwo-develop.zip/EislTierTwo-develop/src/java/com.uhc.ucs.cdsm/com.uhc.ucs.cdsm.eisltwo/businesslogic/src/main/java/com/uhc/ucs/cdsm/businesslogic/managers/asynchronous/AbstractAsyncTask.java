package com.uhc.ucs.cdsm.businesslogic.managers.asynchronous;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncResult;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncTask;


public abstract class AbstractAsyncTask<V> implements AsyncTask<V> {
	
	private static Log log = LogFactory.getLog(AbstractAsyncTask.class);

	private String id;
	
    public AbstractAsyncTask(final String id) {
        this.id = id;
    }

	@Override
	public AsyncResult<V> call() {
		try {
            return executeTask();
        } catch (final Throwable t) {
            log.error("An async task with id: " + getId() + " was abnormally terminated with following exception.", t);
        }
        return null;
	}

	@Override
	public String getId() {
		return id;
	}

}
