package com.uhc.ucs.cdsm.businesslogic.managers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.apache.ftpserver.ftplet.FtpException;

import com.uhc.ucs.cdsm.eisltwo.exportservices.interfaces.IExportCCDAService;
import com.uhc.ucs.cdsm.eisltwo.exportservices.models.DocumentDetailsWrapper;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;

public class LocalStorage implements IExportCCDAService {

	private ITWConfiguration twConfiguration;
	private static final String FILE_EXTENSION = ".xml";
	private static final String DATEFORMAT = "yyyyMMddhhmmssSSS";
	private static final String TIMEZONE = "UTC";

	public LocalStorage(ITWConfiguration twConfiguration) {
		this.twConfiguration = twConfiguration;
	}

	@Override
	public void exportDocument(DocumentDetailsWrapper documentDetailsWrapper)
			throws IOException, FtpException, SftpException, JSchException {
		String path = twConfiguration.getLocalStoragePath();
		if (documentDetailsWrapper.getDocument() != null) {
			FileOutputStream fos;
			try {
				fos = new FileOutputStream(
						new File(path + generateCCDADOCFileName(documentDetailsWrapper.getEncounterID(),
								documentDetailsWrapper.getPatientFullName(),
								getDateTime(documentDetailsWrapper.getDocumentCreationTime()))), true);
				fos.write(documentDetailsWrapper.getDocument());
				fos.close();
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
	}

	private String generateCCDADOCFileName(String encounterID, String patientFullName, String docGenTimestamp) {

		StringBuffer fileName = new StringBuffer(twConfiguration.getProviderGroupId());
		fileName.append("_");
		fileName.append(twConfiguration.getEmrStandardCode());
		fileName.append("_");
		fileName.append(docGenTimestamp);
		fileName.append("_");
		fileName.append(twConfiguration.getTransportProtocol());
		fileName.append("_");
		fileName.append(encounterID);
		fileName.append("_");
		fileName.append(patientFullName);
		fileName.append(FILE_EXTENSION);

		return fileName.toString();
	}
	
	private static  String getDateTime(Date docGenTimestamp) throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat(DATEFORMAT);
		dateFormat.setTimeZone(TimeZone.getTimeZone(TIMEZONE));
		return dateFormat.format(docGenTimestamp);
	}
}
