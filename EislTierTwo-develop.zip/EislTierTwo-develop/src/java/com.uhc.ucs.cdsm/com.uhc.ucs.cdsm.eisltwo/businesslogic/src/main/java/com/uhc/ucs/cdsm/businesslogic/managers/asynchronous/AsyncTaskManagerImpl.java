package com.uhc.ucs.cdsm.businesslogic.managers.asynchronous;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncResult;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncTask;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncTaskExecutor;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncTaskManager;

public class AsyncTaskManagerImpl<V> implements AsyncTaskManager<V> {
	
	private static Log LOG = LogFactory.getLog(AsyncTaskManagerImpl.class);
	
    private static final int TEN_MILLIS = 10;
    
    private static final int THOUSAND_MILLIS = 1000;
    
    private static final long DEFAULT_TIME_OUT_SECONDS = 30;
    
    public static final String MessageNoWorkSubmitted = "No work is submitted to workers";
    public static final String MessageAsyncWorkerInterrupted = "An async worker was interrupted an exception. (Id='%1s')";
    public static final String MessageAsyncOperationCancelled = "An async operation was cancelled from execution by the work manager. (Id='%1s')";
    public static final String MessageAsyncWorkerInterruptedOrTerminatedWException ="An async worker was interrupted or terminated with following exception. (Id='%1s')";
    public static final String MessageAsyncOperationTimedOut = "An async operation timed out. (Id='%1s', TimeoutSeconds='%2s')";
	
	private AsyncTaskExecutor<V> asyncTaskExecutor;

	public AsyncTaskManagerImpl(AsyncTaskExecutor<V> asyncTaskExecutor) {
		this.asyncTaskExecutor = asyncTaskExecutor;
	}
	
	@Override
	public List<AsyncResult<V>> executeTasks(List<AsyncTask<V>> tasks) {
		List<AsyncResult<V>> results = this.executeTasks(tasks, DEFAULT_TIME_OUT_SECONDS);
		return results;
	}
	
	@Override
	public List<AsyncResult<V>> executeTasks(List<AsyncTask<V>> tasks, long timeoutSeconds) {
		final List<Future<AsyncResult<V>>> asyncFutures = new ArrayList<>();
        final List<AsyncResult<V>> results = new ArrayList<>();

        if (tasks == null || tasks.isEmpty()) {
            throw new IllegalArgumentException(
            		MessageNoWorkSubmitted);
        }
        for (final AsyncTask<V> task : tasks) {
            asyncFutures.add(asyncTaskExecutor.executeAsyncTask(task));
        }
        final long startPlusTimeout = Calendar.getInstance().getTimeInMillis()
                + (timeoutSeconds * THOUSAND_MILLIS);
        for (int i = 0; i < asyncFutures.size(); i = i + 1) {
            final Future<AsyncResult<V>> asyncFuture = asyncFutures.get(i);
            long currentTime = Calendar.getInstance().getTimeInMillis();
            while (!asyncFuture.isCancelled() && !asyncFuture.isDone()
                    && currentTime < startPlusTimeout) {
                try {
                    Thread.sleep(TEN_MILLIS);
                } catch (final InterruptedException ex) {
                    LOG.error(String.format(MessageAsyncWorkerInterrupted, tasks.get(i).getId()), ex);
                }
                currentTime = Calendar.getInstance().getTimeInMillis();
            }
            if (asyncFuture.isCancelled()) {
                LOG.error(String.format(MessageAsyncOperationCancelled, tasks.get(i).getId()));
            }
            if (asyncFuture.isDone()) {
                try {
                    results.add(asyncFuture.get());
                } catch (InterruptedException | ExecutionException e) {
                    LOG.error(String.format(MessageAsyncWorkerInterruptedOrTerminatedWException, tasks.get(i).getId()), e);
                }
            } else {
                results.add(null);
                LOG.error(String.format(MessageAsyncOperationTimedOut, tasks.get(i).getId(), timeoutSeconds));
            }
            if (!asyncFuture.isCancelled() && !asyncFuture.isDone()) {
                asyncFuture.cancel(true);
            }

        }
        return results;
	}
}
