package com.uhc.ucs.cdsm.businesslogic.managers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:/businesslogic-spring-beans-test.xml")
public class CCDAWorkflowMangerImplTest  implements ApplicationContextAware{
	
	ApplicationContext applicationContext;

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}
	
	@Autowired
	CCDAWorkflowMangerImpl ccDAWorkflowManger;
	
	@Test
	public void testGetCCDADocuments() throws Exception {
		Date fromDate = parseDate("2018-04-25");
		Date toDate = parseDate("2018-05-9");
		ccDAWorkflowManger.performWorkflow(fromDate, toDate);
	}
/*	
	@Test
	public void testGetCCDA() throws Exception
	{
	ccDAWorkflowManger.getCCDA();
	}
	*/
	private Date parseDate(String date) {
	     try {
	         return new SimpleDateFormat("yyyy-MM-dd").parse(date);
	     } catch (ParseException e) {
	         return null;
	     }
	  }


}
