package com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces;

import java.util.concurrent.Callable;

public interface AsyncTask<V> extends Callable<AsyncResult<V>>{

	/**
     * Implement this method piece of code that needs to be executed asynchronously.
     * 
     * @return the result
     */
    AsyncResult<V> executeTask();

    /**
     * Unique attribute to manage correlation between task and result.
     * 
     * @return the id of this work.
     */
    String getId();
}
