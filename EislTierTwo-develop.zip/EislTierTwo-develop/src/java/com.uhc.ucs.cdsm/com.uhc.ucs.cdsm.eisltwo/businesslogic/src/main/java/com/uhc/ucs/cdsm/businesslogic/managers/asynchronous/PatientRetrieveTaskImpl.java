package com.uhc.ucs.cdsm.businesslogic.managers.asynchronous;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;
import com.uhc.ucs.cdsm.adapters.adaptersbase.interfaces.IClinicalAdapter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Patient;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncResult;
import com.uhc.ucs.cdsm.businesslogic.model.PatientResult;

public class PatientRetrieveTaskImpl extends AbstractAsyncTask<PatientResult> {
	
	private final Log logger = LogFactory.getLog(PatientRetrieveTaskImpl.class);
	private IClinicalAdapter clinicalAdapter;
	public PatientRetrieveTaskImpl(String id, IClinicalAdapter clinicalAdapter) {
		super(id);
		this.clinicalAdapter = clinicalAdapter;
	}

	@Override
	public AsyncResult<PatientResult> executeTask() {
		PatientResult patientResult = new PatientResult();
		Patient patient;
		try {
			logger.info("Getting patient full data for patient ID "
					+ this.getId());
			 patient = clinicalAdapter.getPatientDetails(this.getId());
			 	patientResult.setId(this.getId());
				patientResult.setPatient(patient);
				patientResult.setExecutedNormally(true);
		} catch (ClinicalDataException e) {
			patientResult.setException(e);
			patientResult.setExecutedNormally(false);
		}
		return patientResult;
	}

}
