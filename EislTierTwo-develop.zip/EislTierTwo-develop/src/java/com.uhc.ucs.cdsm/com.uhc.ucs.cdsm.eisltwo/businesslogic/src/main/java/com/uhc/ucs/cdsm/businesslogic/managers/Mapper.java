package com.uhc.ucs.cdsm.businesslogic.managers;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Patient;

public class Mapper {

	// map the touchworks specific domain obj to domain  layer obj.
	public static com.uhc.ucs.cdsm.domain.models.Encounter mapEncounter(Encounter encounter) {

		com.uhc.ucs.cdsm.domain.models.Encounter encounter1 = new com.uhc.ucs.cdsm.domain.models.Encounter();
		encounter1.setEncounterUniqueIdentifier(encounter.getEncounterId());
		//encounter1.setPrimaryInsuranceIdentifier(encounter.getPatient().getInsurance().getPrimaryInsurance());
		
		return encounter1;
		
	}

	public static com.uhc.ucs.cdsm.domain.models.Patient mapPatient(Patient patient) {
		com.uhc.ucs.cdsm.domain.models.Patient p1 = new com.uhc.ucs.cdsm.domain.models.Patient();
		p1.setPatientUniqueIdentifier(patient.getPatientId());
		
		return p1;
	}
	
	
	
}
