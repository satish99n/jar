package com.uhc.ucs.cdsm.businesslogic.managers.interfaces;

import java.io.IOException;
import java.util.Date;
import java.util.concurrent.ExecutionException;

import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;

public interface ICCDAWorkflowManger {

	void performWorkflow(Date fromDate, Date toDate)
			throws ClinicalDataException, IOException, InterruptedException, ExecutionException, Exception;
}
