package com.uhc.ucs.cdsm.businesslogic.model;

import com.uhc.ucs.cdsm.adapters.adaptersbase.models.DocumentWrapper;
import com.uhc.ucs.cdsm.businesslogic.managers.asynchronous.interfaces.AsyncResult;

public class DocumentResult implements AsyncResult<DocumentResult> {

	private String encounterID;
	private DocumentWrapper dw;
	private boolean executedNormally;
	private Exception exception;

	public DocumentWrapper getDw() {
		return dw;
	}

	public void setDw(DocumentWrapper dw) {
		this.dw = dw;
	}

	@Override
	public Exception getException() {
		return exception;
	}

	@Override
	public String getId() {
		return encounterID;
	}

	@Override
	public DocumentResult getResult() {
		return this;
	}

	@Override
	public boolean isExecutedNormally() {
		return executedNormally;
	}

	@Override
	public void setException(Exception exception) {
		this.exception = exception;
	}

	@Override
	public void setExecutedNormally(boolean executedNormally) {
		this.executedNormally = executedNormally;
	}

	@Override
	public void setId(String Id) {
		this.encounterID = Id;
	}

	@Override
	public void setResult(DocumentResult result) {
		// TODO Auto-generated method stub

	}

}
