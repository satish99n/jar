package com.uhc.ucs.cdsm.domain.models;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

public class ChaseRequestGroupHistoryMacroStatus {
	private short chaseRequestGroupHistoryMacroStatusKey;
	private String chaseRequestGroupHistoryMacroStatusName;
	private Date insertDate;
	
	private Collection<ChaseRequestGroupHistoryMicroStatus> chaseRequestGroupHistoryMicroStatuses;
	
	public ChaseRequestGroupHistoryMacroStatus() {
		this.chaseRequestGroupHistoryMicroStatuses = new ArrayList<>();
	}	


	public Collection<ChaseRequestGroupHistoryMicroStatus> getChaseRequestGroupHistoryMicroStatuses() {
		return chaseRequestGroupHistoryMicroStatuses;
	}


	public void setChaseRequestGroupHistoryMicroStatuses(
			Collection<ChaseRequestGroupHistoryMicroStatus> chaseRequestGroupHistoryMicroStatuses) {
		this.chaseRequestGroupHistoryMicroStatuses = chaseRequestGroupHistoryMicroStatuses;
	}


	public short getChaseRequestGroupHistoryMacroStatusKey() {
		return chaseRequestGroupHistoryMacroStatusKey;
	}

	public void setChaseRequestGroupHistoryMacroStatusKey(short chaseRequestGroupHistoryMacroStatusKey) {
		this.chaseRequestGroupHistoryMacroStatusKey = chaseRequestGroupHistoryMacroStatusKey;
	}

	public String getChaseRequestGroupHistoryMacroStatusName() {
		return chaseRequestGroupHistoryMacroStatusName;
	}

	public void setChaseRequestGroupHistoryMacroStatusName(String chaseRequestGroupHistoryMacroStatusName) {
		this.chaseRequestGroupHistoryMacroStatusName = chaseRequestGroupHistoryMacroStatusName;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;
}
