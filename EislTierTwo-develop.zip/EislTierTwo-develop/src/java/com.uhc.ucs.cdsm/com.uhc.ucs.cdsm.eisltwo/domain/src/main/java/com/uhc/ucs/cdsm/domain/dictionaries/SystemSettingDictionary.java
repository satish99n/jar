package com.uhc.ucs.cdsm.domain.dictionaries;

import com.uhc.ucs.cdsm.domain.models.SystemSetting;

public class SystemSettingDictionary {

	/*
	Select 
	'
		public static final SystemSetting ' + REPLACE(SettingKeyName , ' ' , '')  +' = new SystemSetting() {{
			setSystemSettingKey((short)'+convert(varchar(64), SystemSettingKey)+');
			setSystemSettingCategoryKey((short)'+convert(varchar(64), SystemSettingCategoryKey)+');
			setSettingKeyName("'+SettingKeyName+'");
			setSettingKeyDisplayName("'+SettingKeyDisplayName+'");
			setSettingValueType("'+ISNULL(SettingValueType,'')+'");
			setSettingDefaultValue("'+SettingValue+'");
		}};
	'
	--		Select *
	FROM settings.SystemSetting order by [SystemSettingKey]

 */		
	
	public static final SystemSetting JobProcessingBetweenRunsSleepMilliseconds = new SystemSetting() {
		{
			setSystemSettingKey((short) 101);
			setSystemSettingCategoryKey((short) 1);
			setSettingKeyName("JobProcessingBetweenRunsSleepMilliseconds");
			setSettingKeyDisplayName("Job Processing BetweenRunsSleep Milliseconds");
			setSettingValueType("");
			setSettingDefaultValue("20000");
		}
	};
	public static final SystemSetting UnitedRegexOne = new SystemSetting() {
		{
			setSystemSettingKey((short) 201);
			setSystemSettingCategoryKey((short) 2);
			setSettingKeyName("UnitedRegexOne");
			setSettingKeyDisplayName("United Regex One");
			setSettingValueType("");
			setSettingDefaultValue("(?i:.*UNITED.*)");
		}
	};
	public static final SystemSetting UnitedRegexTwo = new SystemSetting() {
		{
			setSystemSettingKey((short) 202);
			setSystemSettingCategoryKey((short) 2);
			setSettingKeyName("UnitedRegexTwo");
			setSettingKeyDisplayName("United Regex Two");
			setSettingValueType("");
			setSettingDefaultValue("(?i:.*UHG.*)");
		}
	};
	public static final SystemSetting UnitedRegexThree = new SystemSetting() {
		{
			setSystemSettingKey((short) 203);
			setSystemSettingCategoryKey((short) 2);
			setSettingKeyName("UnitedRegexThree");
			setSettingKeyDisplayName("United Regex Three");
			setSettingValueType("");
			setSettingDefaultValue("(?i:.*UHC.*)");
		}
	};
	public static final SystemSetting CrontabExpression = new SystemSetting() {
		{
			setSystemSettingKey((short) 301);
			setSystemSettingCategoryKey((short) 3);
			setSettingKeyName("CrontabExpression");
			setSettingKeyDisplayName("Crontab Expression");
			setSettingValueType("");
			setSettingDefaultValue("*/55 * * * * *");
		}
	};
	public static final SystemSetting NumberOfDays = new SystemSetting() {
		{
			setSystemSettingKey((short) 302);
			setSystemSettingCategoryKey((short) 3);
			setSettingKeyName("NumberOfDays");
			setSettingKeyDisplayName("Number Of Days");
			setSettingValueType("");
			setSettingDefaultValue("1");
		}
	};
	public static final SystemSetting BlacklistRegexOne = new SystemSetting() {
		{
			setSystemSettingKey((short) 401);
			setSystemSettingCategoryKey((short) 4);
			setSettingKeyName("BlacklistRegexOne");
			setSettingKeyDisplayName("Blacklist Regex One");
			setSettingValueType("");
			setSettingDefaultValue("(?i:.*SELFPAY.*)");
		}
	};

	public static final SystemSetting PatientDetailsGetTimeoutSeconds = new SystemSetting() {
		{
			setSystemSettingKey((short) 501);
			setSystemSettingCategoryKey((short) 5);
			setSettingKeyName("PatientDetailsGetTimeoutSeconds");
			setSettingKeyDisplayName("Patient Details Get Timeout Seconds");
			setSettingValueType("");
			setSettingDefaultValue("60");
		}
	};
	
	public static final SystemSetting DocumentRetrieveTimeoutSeconds = new SystemSetting() {
		{
			setSystemSettingKey((short) 502);
			setSystemSettingCategoryKey((short) 5);
			setSettingKeyName("DocumentRetrieveTimeoutSeconds");
			setSettingKeyDisplayName("Document Retrieve Timeout Seconds");
			setSettingValueType("");
			setSettingDefaultValue("60");
		}
	};
}
