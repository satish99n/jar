package com.uhc.ucs.cdsm.domain.models;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

public class ChaseRequest {

	private long chaseRequestKey;
	private long chaseRequestGroupKey;
	private long encounterKey;
	private Date insertDate;
	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;

	private ChaseRequestGroup parentChaseRequestGroup;
	private Collection<ChaseRequestHistory> chaseRequestHistories;
	
	public ChaseRequest() {
		this.chaseRequestHistories = new ArrayList<>();
	}	

	public ChaseRequestGroup getParentChaseRequestGroup() {
		return parentChaseRequestGroup;
	}

	public void setParentChaseRequestGroup(ChaseRequestGroup parentChaseRequestGroup) {
		this.parentChaseRequestGroup = parentChaseRequestGroup;
	}
	
	public Collection<ChaseRequestHistory> getChaseRequestHistories() {
		return chaseRequestHistories;
	}

	public void setChaseRequestHistories(Collection<ChaseRequestHistory> chaseRequestHistories) {
		this.chaseRequestHistories = chaseRequestHistories;
	}	

	private Encounter parentEncounter;

	public Encounter getParentEncounter() {
		return parentEncounter;
	}

	public void setParentEncounter(Encounter parentEncounter) {
		this.parentEncounter = parentEncounter;
	}

	public long getChaseRequestKey() {
		return chaseRequestKey;
	}

	public void setChaseRequestKey(long chaseRequestKey) {
		this.chaseRequestKey = chaseRequestKey;
	}

	public long getChaseRequestGroupKey() {
		return chaseRequestGroupKey;
	}

	public void setChaseRequestGroupKey(long chaseRequestGroupKey) {
		this.chaseRequestGroupKey = chaseRequestGroupKey;
	}

	public long getEncounterKey() {
		return encounterKey;
	}

	public void setEncounterKey(long encounterKey) {
		this.encounterKey = encounterKey;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}


}
