package com.uhc.ucs.cdsm.domain.models;

import java.util.Date;

public class ChaseRequestHistory {
	private long chaseRequestHistoryKey;
	private long chaseRequestKey;
	private short macroStatusKey;
	private short microStatusKey;

	public long getChaseRequestHistoryKey() {
		return chaseRequestHistoryKey;
	}

	public void setChaseRequestHistoryKey(long chaseRequestHistoryKey) {
		this.chaseRequestHistoryKey = chaseRequestHistoryKey;
	}

	public long getChaseRequestKey() {
		return chaseRequestKey;
	}

	public void setChaseRequestKey(long chaseRequestKey) {
		this.chaseRequestKey = chaseRequestKey;
	}

	public short getMacroStatusKey() {
		return macroStatusKey;
	}

	public void setMacroStatusKey(short macroStatusKey) {
		this.macroStatusKey = macroStatusKey;
	}

	public short getMicroStatusKey() {
		return microStatusKey;
	}

	public void setMicroStatusKey(short microStatusKey) {
		this.microStatusKey = microStatusKey;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public ChaseRequest getParentChaseRequest() {
		return parentChaseRequest;
	}

	public void setParentChaseRequest(ChaseRequest parentChaseRequest) {
		this.parentChaseRequest = parentChaseRequest;
	}

	private Date insertDate;
	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;
	private ChaseRequest parentChaseRequest;
}
