package com.uhc.ucs.cdsm.domain.models;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

public class Encounter {
	private long encounterKey;
	private String encounterUniqueIdentifier;
	private long patientKey;
	private String primaryInsuranceIdentifier;
	private String secondaryInsuranceIdentifier;
	private String tertiaryInsuranceIdentifier;
	private String quartaneryInsuranceIdentifier;
	private String quinaryInsuranceIdentifier;

	private Date insertDate;

	private Collection<ChaseRequest> chaseRequests;

	public Collection<ChaseRequest> getChaseRequests() {
		return chaseRequests;
	}

	public void setChaseRequests(Collection<ChaseRequest> chaseRequests) {
		this.chaseRequests = chaseRequests;
	}

	public Encounter() {
		this.chaseRequests = new ArrayList<>();
	}

	private Patient parentPatient;

	public Patient getParentPatient() {
		return parentPatient;
	}

	public void setParentPatient(Patient parentPatient) {
		this.parentPatient = parentPatient;
	}

	public long getEncounterKey() {
		return encounterKey;
	}

	public void setEncounterKey(long encounterKey) {
		this.encounterKey = encounterKey;
	}

	public String getEncounterUniqueIdentifier() {
		return encounterUniqueIdentifier;
	}

	public void setEncounterUniqueIdentifier(String encounterUniqueIdentifier) {
		this.encounterUniqueIdentifier = encounterUniqueIdentifier;
	}

	public long getPatientKey() {
		return patientKey;
	}

	public void setPatientKey(long patientKey) {
		this.patientKey = patientKey;
	}

	public String getPrimaryInsuranceIdentifier() {
		return primaryInsuranceIdentifier;
	}

	public void setPrimaryInsuranceIdentifier(String primaryInsuranceIdentifier) {
		this.primaryInsuranceIdentifier = primaryInsuranceIdentifier;
	}

	public String getSecondaryInsuranceIdentifier() {
		return secondaryInsuranceIdentifier;
	}

	public void setSecondaryInsuranceIdentifier(String secondaryInsuranceIdentifier) {
		this.secondaryInsuranceIdentifier = secondaryInsuranceIdentifier;
	}

	public void setTertiaryInsuranceIdentifier(String secondaryInsuranceIdentifier) {
		this.secondaryInsuranceIdentifier = secondaryInsuranceIdentifier;
	}
	
	public void setQuartaneryInsuranceIdentifier(String secondaryInsuranceIdentifier) {
		this.secondaryInsuranceIdentifier = secondaryInsuranceIdentifier;
	}
	
	public void setQuinaryInsuranceIdentifier(String secondaryInsuranceIdentifier) {
		this.secondaryInsuranceIdentifier = secondaryInsuranceIdentifier;
	}
	public String getTertiaryInsuranceIdentifier() {
		return tertiaryInsuranceIdentifier;
	}
	
	public String getQuartaneryInsuranceIdentifier() {
		return quartaneryInsuranceIdentifier;
	}
	
	public String getQuinaryInsuranceIdentifier() {
		return quinaryInsuranceIdentifier;
	}
	
	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;
}
