package com.uhc.ucs.cdsm.domain.models;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

public class Patient {
	private long patientKey;
	private String patientUniqueIdentifier;
	private Date insertDate;
	private String insertedBy;
	private Date lastUpdated;
	private String lastUpdatedBy;
	
	private Collection<Encounter> encounters;
	
	public Patient()
	{
		this.encounters = new ArrayList<>();
	}

	public Collection<Encounter> getEncounters() {
		return encounters;
	}

	public void setEncounters(Collection<Encounter> encounters) {
		this.encounters = encounters;
	}

	public long getPatientKey() {
		return patientKey;
	}

	public void setPatientKey(long patientKey) {
		this.patientKey = patientKey;
	}

	public String getPatientUniqueIdentifier() {
		return patientUniqueIdentifier;
	}

	public void setPatientUniqueIdentifier(String patientUniqueIdentifier) {
		this.patientUniqueIdentifier = patientUniqueIdentifier;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
}
