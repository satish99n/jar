package com.uhc.ucs.cdsm.domain.dictionaries;

import com.uhc.ucs.cdsm.domain.models.SystemSettingCategory;

public class SystemSettingCategoryDictionary {

	/*
	Select 
	'
		public static final SystemSettingCategory ' + REPLACE(SystemSettingCategoryName , ' ' , '')  +' = new SystemSettingCategory() {{
			setSystemSettingCategoryKey((short)'+convert(varchar(64), SystemSettingCategoryKey)+');
			setSystemSettingCategoryName("'+SystemSettingCategoryName+'");
		}};
	'
	--		Select *
	FROM settings.SystemSettingCategory order by [SystemSettingCategoryKey]
 */		
	
	public static final SystemSettingCategory QueueWatchProcessSettings = new SystemSettingCategory() {
		{
			setSystemSettingCategoryKey((short) 1);
			setSystemSettingCategoryName("Queue Watch Process Settings");
		}
	};

	public static final SystemSettingCategory UnitedHealthcareInsuranceNameRegex = new SystemSettingCategory() {
		{
			setSystemSettingCategoryKey((short) 2);
			setSystemSettingCategoryName("United Healthcare Insurance Name Regex");
		}
	};

	public static final SystemSettingCategory SchedularJobSettings = new SystemSettingCategory() {
		{
			setSystemSettingCategoryKey((short) 3);
			setSystemSettingCategoryName("Schedular Job Settings");
		}
	};

	public static final SystemSettingCategory BlacklistInsuranceNameRegex = new SystemSettingCategory() {
		{
			setSystemSettingCategoryKey((short) 4);
			setSystemSettingCategoryName("Blacklist Insurance Name Regex");
		}
	};

	public static final SystemSettingCategory DefaultTimeouts = new SystemSettingCategory() {
		{
			setSystemSettingCategoryKey((short) 5);
			setSystemSettingCategoryName("Default Timeouts");
		}
	};
}
