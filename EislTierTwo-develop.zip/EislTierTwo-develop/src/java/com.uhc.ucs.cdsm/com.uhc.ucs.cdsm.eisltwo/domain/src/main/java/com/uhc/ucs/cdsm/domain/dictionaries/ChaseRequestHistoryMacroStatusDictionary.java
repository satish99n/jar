package com.uhc.ucs.cdsm.domain.dictionaries;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistoryMacroStatus;

public class ChaseRequestHistoryMacroStatusDictionary {

	/*
	 Select ' public static final ChaseRequestHistoryMacroStatus ' +
	  REPLACE(ChaseRequestHistoryMacroStatusName , ' ' , '') +' = new ChaseRequestHistoryMacroStatus() {{setChaseRequestHistoryMacroStatusKey((short)'
	  +convert(varchar(64), ChaseRequestHistoryMacroStatusKey)+'); setChaseRequestHistoryMacroStatusName("'+ChaseRequestHistoryMacroStatusName+'"); }}; ' 
	  FROM lookup.ChaseRequestHistoryMacroStatus	
	 */

	public static final ChaseRequestHistoryMacroStatus New = new ChaseRequestHistoryMacroStatus() {
		{
			setChaseRequestHistoryMacroStatusKey((short) 1);
			setChaseRequestHistoryMacroStatusName("New");
		}
	};
	public static final ChaseRequestHistoryMacroStatus AboutToSendPatientDetailRequestToSourceData = new ChaseRequestHistoryMacroStatus() {
		{
			setChaseRequestHistoryMacroStatusKey((short) 31);
			setChaseRequestHistoryMacroStatusName("About To Send Patient Detail Request To Source Data");
		}
	};
	public static final ChaseRequestHistoryMacroStatus SendPatientDetailRequestToSourceDataCompleted = new ChaseRequestHistoryMacroStatus() {
		{
			setChaseRequestHistoryMacroStatusKey((short) 34);
			setChaseRequestHistoryMacroStatusName("Send Patient Detail Request To Source Data Completed");
		}
	};
	public static final ChaseRequestHistoryMacroStatus SendPatientDetailRequestToSourceDataFailed = new ChaseRequestHistoryMacroStatus() {
		{
			setChaseRequestHistoryMacroStatusKey((short) 37);
			setChaseRequestHistoryMacroStatusName("Send Patient Detail Request To Source Data Failed");
		}
	};
	public static final ChaseRequestHistoryMacroStatus AboutToSendCcdaRequestToSourceData = new ChaseRequestHistoryMacroStatus() {
		{
			setChaseRequestHistoryMacroStatusKey((short) 51);
			setChaseRequestHistoryMacroStatusName("About To Send Ccda Request To Source Data");
		}
	};
	public static final ChaseRequestHistoryMacroStatus SendCcdaRequestToSourceDataCompleted = new ChaseRequestHistoryMacroStatus() {
		{
			setChaseRequestHistoryMacroStatusKey((short) 54);
			setChaseRequestHistoryMacroStatusName("Send Ccda Request To Source Data Completed");
		}
	};
	public static final ChaseRequestHistoryMacroStatus SendCcdaRequestToSourceDataFailed = new ChaseRequestHistoryMacroStatus() {
		{
			setChaseRequestHistoryMacroStatusKey((short) 57);
			setChaseRequestHistoryMacroStatusName("Send Ccda Request To Source Data Failed");
		}
	};
	public static final ChaseRequestHistoryMacroStatus AboutToSendResultsTodestination = new ChaseRequestHistoryMacroStatus() {
		{
			setChaseRequestHistoryMacroStatusKey((short) 81);
			setChaseRequestHistoryMacroStatusName("About To Send Results To destination");
		}
	};
	public static final ChaseRequestHistoryMacroStatus SendResultsToDestinationCompleted = new ChaseRequestHistoryMacroStatus() {
		{
			setChaseRequestHistoryMacroStatusKey((short) 84);
			setChaseRequestHistoryMacroStatusName("Send Results To Destination Completed");
		}
	};
	public static final ChaseRequestHistoryMacroStatus SendResultsToDestinationFailed = new ChaseRequestHistoryMacroStatus() {
		{
			setChaseRequestHistoryMacroStatusKey((short) 87);
			setChaseRequestHistoryMacroStatusName("Send Results To Destination Failed");
		}
	};
	public static final ChaseRequestHistoryMacroStatus Ended = new ChaseRequestHistoryMacroStatus() {
		{
			setChaseRequestHistoryMacroStatusKey((short) 999);
			setChaseRequestHistoryMacroStatusName("Ended");
		}
	};
}
