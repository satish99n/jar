package com.uhc.ucs.cdsm.adapters.allscriptsadapter.util;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import javax.annotation.PreDestroy;
import javax.net.ssl.SSLContext;
import javax.security.cert.CertificateException;
import javax.security.cert.X509Certificate;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HeaderElement;
import org.apache.http.HeaderElementIterator;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeaderElementIterator;
import org.apache.http.protocol.HTTP;
import org.apache.http.protocol.HttpContext;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;

public class ConnectionUtil {

	private final Log log = LogFactory.getLog(ConnectionUtil.class);
	private ITWConfiguration twConfiguration;
	private CloseableHttpClient client = null;

	public ConnectionUtil(ITWConfiguration twConfiguration) {
		this.twConfiguration = twConfiguration;
	}

	public void init() throws ClinicalDataException {

		try {

			final SSLContext sslcontext = SSLContexts.custom().loadTrustMaterial(null, new TrustStrategy() {
				@SuppressWarnings("unused")
				public boolean isTrusted(final X509Certificate[] chain, final String authType)
						throws CertificateException {
					return true;
				}

				public boolean isTrusted(final java.security.cert.X509Certificate[] arg0, final String arg1)
						throws java.security.cert.CertificateException {
					return false;
				}
			}).build();

			final ConnectionKeepAliveStrategy myStrategy = new ConnectionKeepAliveStrategy() {
				public long getKeepAliveDuration(final HttpResponse response, final HttpContext context) {
					final HeaderElementIterator it = new BasicHeaderElementIterator(
							response.headerIterator(HTTP.CONN_KEEP_ALIVE));
					while (it.hasNext()) {
						final HeaderElement he = it.nextElement();
						final String param = he.getName();
						final String value = he.getValue();
						if (value != null && param.equalsIgnoreCase("timeout")) {
							return Long.parseLong(value) * 1000;
						}
					}
					return 5 * 1000;
				}
			};

			final SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, null, null,
					new NoopHostnameVerifier());

			client = HttpClients.custom().setKeepAliveStrategy(myStrategy).setSSLSocketFactory(sslsf).build();

		} catch (final KeyManagementException e) {
			throw new ClinicalDataException("Invalid Key", e);
		} catch (final NoSuchAlgorithmException e) {
			throw new ClinicalDataException("NoSuchAlgorithm", e);
		} catch (final KeyStoreException e) {
			throw new ClinicalDataException("Invalid KeyStore ", e);
		}

	}

	public String getToken() throws ClinicalDataException {

		log.debug("Requesting for Token");
		final JsonObject jb = new JsonObject();
		String response = "";

		jb.addProperty("Username", twConfiguration.getTWUnitySvcUser());
		jb.addProperty("Password", twConfiguration.getTWUnitySvcPassword());

		final StringBuilder url = new StringBuilder(twConfiguration.getTWUnityEndpoint());
		url.append("GetToken");

		HttpPost post;
		try {
			post = new HttpPost(new URI(url.toString()));
			final StringEntity strEntity = new StringEntity(jb.toString(), ContentType.APPLICATION_JSON);
			post.setEntity(strEntity);

			response = executeRequest(post);
			if (response.contains("Error")) {
				log.error("Token response received as: " + response);
				throw new ClinicalDataException(
						"Invalid token: " + jb.get("Username"));
			}
		} catch (URISyntaxException e) {
			throw new ClinicalDataException("Invalid URI", e);
		}

		log.debug("Token response :" + response);
		return response;
	}

	private String executeRequest(final HttpRequestBase request) throws ClinicalDataException {

		log.debug("executing request: " + request);
		String response = null;
		CloseableHttpResponse res = null;

		try {
			res = client.execute(request);

			final HttpEntity entity = res.getEntity();
			response = entity == null ? null : EntityUtils.toString(entity, StandardCharsets.UTF_8);

		} catch (final IOException ex) {
			throw new ClinicalDataException("connection issue", ex);
		} finally {
			try {
				if (res != null) {
					res.close();
				}
			} catch (final IOException ex) {
				throw new ClinicalDataException("connection issue", ex);
			}
		}

		return response;
	}

	public String createRequest(String action, String patientID, String token, String param1)
			throws ClinicalDataException {

		String response = "";
		final Gson gson = new Gson();
		final JsonObject jb = new JsonObject();
		jb.addProperty("Action", action);
		jb.addProperty("Appname", twConfiguration.getTWUnityAppname());
		jb.addProperty("AppUserID", twConfiguration.getTWUnityUser());
		jb.addProperty("PatientID", patientID);
		jb.addProperty("Token", token);
		jb.addProperty("Parameter1", param1);
		jb.addProperty("Parameter2", "");
		jb.addProperty("Parameter3", "");
		jb.addProperty("Parameter4", "");
		jb.addProperty("Parameter5", "");
		jb.addProperty("Parameter6", "");
		jb.addProperty("Data", gson.toJson(null));
		final StringBuilder url = new StringBuilder(twConfiguration.getTWUnityEndpoint());
		url.append("MagicJson");
		HttpPost post;

		try {
			post = new HttpPost(new URI(url.toString()));
			log.debug("Created request: " + url.toString());

			final StringEntity strEntity = new StringEntity(jb.toString(), ContentType.APPLICATION_JSON);
			post.setEntity(strEntity);
			response = executeRequest(post);
		} catch (URISyntaxException e) {
			throw new ClinicalDataException("Invalid URI", e);
		}
		return response;
	}

	public boolean isValidToken(String token, String patientID) throws ClinicalDataException {
		final String response = createRequest("GetUserAuthentication", patientID, token,
				twConfiguration.getTWUnityPassword());
		if (response != null && !response.contains("\"Error\":")) {
			final JsonObject obj = (JsonObject) new JsonParser().parse(response).getAsJsonArray().get(0);
			JsonArray ele = obj.get("getuserauthenticationinfo").getAsJsonArray();
			JsonObject eleObj = ele.get(0).getAsJsonObject();

			String isValidUser = eleObj.get("ValidUser").toString();
			if (isValidUser.contains("YES")) {
				return true;
			}
		}
		return false;
	}

	@PreDestroy
	private void close() throws ClinicalDataException {
		if (client != null) {
			try {
				client.close();
			} catch (final IOException ex) {
				throw new ClinicalDataException("connection issue", ex);
			}
		}
	}

	public ITWConfiguration getTwConfiguration() {
		return twConfiguration;
	}

	public void setTwConfiguration(ITWConfiguration twConfiguration) {
		this.twConfiguration = twConfiguration;
	}

}
