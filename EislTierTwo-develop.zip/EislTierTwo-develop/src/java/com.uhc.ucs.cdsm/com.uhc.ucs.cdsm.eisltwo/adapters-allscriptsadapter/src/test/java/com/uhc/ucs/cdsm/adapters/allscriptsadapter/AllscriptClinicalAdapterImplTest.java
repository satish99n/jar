package com.uhc.ucs.cdsm.adapters.allscriptsadapter;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;
import com.uhc.ucs.cdsm.adapters.adaptersbase.interfaces.IClinicalAdapter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.DocumentWrapper;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Patient;
import com.uhc.ucs.cdsm.adapters.allscriptsadapter.util.ConnectionUtil;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:/adapters-allscriptsadapter-spring-beans-test.xml")
public class AllscriptClinicalAdapterImplTest implements ApplicationContextAware {

	private ApplicationContext applicationContext;

	@Autowired
	private ConnectionUtil connectionUtil;

	@Autowired
	private IClinicalAdapter wfAdapter;

	private final Log log = LogFactory.getLog(AllscriptClinicalAdapterImplTest.class);

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

	@Test
	public void testApiEndpoint() {
		ITWConfiguration tWConfiguration = (ITWConfiguration) applicationContext.getBean("iTWConfiguration");
		Assert.assertNotNull(tWConfiguration.getApiEndpoint());
	}

	@Test
	public void testGetToken() throws Exception{
		final String token = connectionUtil.getToken();
		log.debug(token+" received token");
        Assert.assertNotNull(token);
	}
	
	@Test
	public void testGetSchedule() throws Exception {

		final String token = connectionUtil.getToken();
		Assert.assertNotNull(token);
		final String response = connectionUtil.createRequest("GetSchedule", "", token, "04/25/2018|05/09/2018");

		final JsonObject obj = (JsonObject) new JsonParser().parse(response).getAsJsonArray().get(0);
		JsonArray objs = obj.get("getscheduleinfo").getAsJsonArray();
		List<Encounter> encounters = new ArrayList<Encounter>();
		for (JsonElement ele : objs) {
			JsonObject eleObj = ele.getAsJsonObject();
			
			Encounter ent = new Encounter();
			ent.setAppointmentLocation(eleObj.get("Location").toString());
			ent.setAppointmentTime(eleObj.get("ApptTime").toString());
			ent.setApptNumberEXT(eleObj.get("ApptNumberEXT").toString());
			ent.setEncounterId(eleObj.get("Encounterid").toString());
			ent.setEncounterStatus(eleObj.get("Status").toString());
			ent.setOrganizationMRN(eleObj.get("organizationMRN").toString());
			ent.setVisitNumberExt(eleObj.get("VisitNumberExt").toString());
			
			Patient patient = new Patient();
			patient.setPatientId(eleObj.get("patientID").toString());
			patient.setPatientFirstName(eleObj.get("PatientFirstName").toString());
			patient.setPatientLastName(eleObj.get("PatientLastName").toString());
			ent.setPatient(patient);
			encounters.add(ent);
		}
		Assert.assertNotNull(encounters);
	}

	@Test
	public void testGetPatientFull() throws ClinicalDataException, InterruptedException, ExecutionException {
		Patient patient = wfAdapter.getPatientDetails("140155");
		Assert.assertNotNull(patient);
	}

	@Test
	public void testGetCCDA() throws ClinicalDataException, InterruptedException, ExecutionException {
		DocumentWrapper dw = wfAdapter.getCCDA("140156", "270922");
		Assert.assertNotNull(dw);
	}

}
