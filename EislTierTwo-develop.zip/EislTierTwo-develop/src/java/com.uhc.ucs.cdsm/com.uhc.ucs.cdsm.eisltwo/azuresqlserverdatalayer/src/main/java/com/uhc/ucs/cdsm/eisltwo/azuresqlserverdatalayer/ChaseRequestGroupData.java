package com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.function.Function;

import javax.xml.stream.XMLStreamException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.StopWatch;

import com.microsoft.sqlserver.jdbc.SQLServerDriver;
import com.uhc.ucs.cdsm.datalayer.interfaces.IChaseRequestGroupData;
import com.uhc.ucs.cdsm.datalayer.interfaces.IChaseRequestGroupHistoryData;
import com.uhc.ucs.cdsm.datalayer.interfaces.TwoParameterFunction;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer.converters.ChaseRequestGroupToXmlConverter;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.IConnectionStringRetriever;

public class ChaseRequestGroupData extends DataLayerBase implements IChaseRequestGroupData {
	
	private final Log logger;

	/* piggyback off this procedure for pilot */
	public final static String ProcedureNameUspPatientEncounterUpsert = "[dbo].[uspPatientEncounterUpsert]";
	
	public final static String ProcedureNameUspChaseRequestGroupDeepGetByKey = "[dbo].[uspChaseRequestGroupDeepGetByKey]"; 

	public ChaseRequestGroupData(Log lgr, IConnectionStringRetriever icsr) {
		super(lgr, icsr);
		logger = lgr;
	}
	
	public ChaseRequestGroupData(IConnectionStringRetriever icsr) {
		super(icsr);
		logger = LogFactory.getLog(ChaseRequestGroupData.class);
	}

	public ChaseRequestGroup RetrieveSingle(long chaseRequestGroupKey,
			TwoParameterFunction<CallableStatement, ResultSet, ChaseRequestGroup> handleResultSetFunction) throws SQLException {
		
		ChaseRequestGroup returnItem = null;

		String url = super.GetPrimaryDatabaseConnectionString();

		SQLServerDriver driver = new SQLServerDriver();

		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;

		conn = DriverManager.getConnection(url);

		cstmt = conn.prepareCall("{call " + ProcedureNameUspChaseRequestGroupDeepGetByKey + " (?)}");

		// cstmt.setLong("PatientKey", patientKey);
		cstmt.setLong(1, chaseRequestGroupKey);

		boolean resultsExist = cstmt.execute();

		int rowsAffected = 0;

		// Protects against lack of SET NOCOUNT in stored procedure
		while (resultsExist || rowsAffected != -1) {
			if (resultsExist) {
				rs = cstmt.getResultSet();

				if (null != handleResultSetFunction) {
					returnItem = handleResultSetFunction.apply(cstmt, rs);
				}

				break;
			} else {
				rowsAffected = cstmt.getUpdateCount();
			}
			resultsExist = cstmt.getMoreResults();
		}

		if (rs != null)
			try {
				rs.close();
				rs = null;
			} catch (SQLException e) {
				this.logger.info(e);
			}
		if (cstmt != null)
			try {
				cstmt.close();
				cstmt = null;
			} catch (SQLException e) {
				this.logger.info(e);
			}
		if (conn != null)
			try {
				conn.close();
				conn = null;
			} catch (SQLException e) {
				this.logger.info(e);
			}

		return returnItem;
	}
	
	@Override
	public ChaseRequestGroup UpsertSingle(ChaseRequestGroup pojo,
			Function<ResultSet, ChaseRequestGroup> handleResultSetFunction) throws SQLException {

		String convertedXml;
		try {
			convertedXml = new ChaseRequestGroupToXmlConverter().ConvertSingle(pojo);
		} catch (XMLStreamException ex) {
			this.logger.error(ex.getMessage(), ex);
			throw new RuntimeException(ex);
		}

		ChaseRequestGroup returnItem = null;

		String url = super.GetPrimaryDatabaseConnectionString();

		SQLServerDriver driver = new SQLServerDriver();

		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;

		conn = DriverManager.getConnection(url);

		cstmt = conn.prepareCall("{call " + ProcedureNameUspPatientEncounterUpsert + " (?)}");

		// cstmt.setLong("PatientKey", patientKey);
		cstmt.setString(1, convertedXml);

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		this.logger.debug(String.format("About to execute %1s (Single ChaseRequestGroup)",
				ProcedureNameUspPatientEncounterUpsert));
		boolean resultsExist = cstmt.execute();
		stopWatch.stop();
		this.logger.debug(String.format("Just excecuted %1s (%2s ms)", ProcedureNameUspPatientEncounterUpsert,
				stopWatch.getTotalTimeMillis()));

		int rowsAffected = 0;

		// Protects against lack of SET NOCOUNT in stored procedure
		while (resultsExist || rowsAffected != -1) {
			if (resultsExist) {
				rs = cstmt.getResultSet();

				if (null != handleResultSetFunction) {
					returnItem = handleResultSetFunction.apply(rs);
				}

				break;
			} else {
				rowsAffected = cstmt.getUpdateCount();
			}
			resultsExist = cstmt.getMoreResults();
		}

		if (rs != null)
			try {
				rs.close();
				rs = null;
			} catch (SQLException e) {
				this.logger.info(e);
			}
		if (cstmt != null)
			try {
				cstmt.close();
				cstmt = null;
			} catch (SQLException e) {
				this.logger.info(e);
			}
		if (conn != null)
			try {
				conn.close();
				conn = null;
			} catch (SQLException e) {
				this.logger.info(e);
			}

		return returnItem;
	}
}
