package com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.function.Function;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.microsoft.sqlserver.jdbc.SQLServerDriver;
import com.uhc.ucs.cdsm.datalayer.interfaces.IChaseRequestGroupHistoryData;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistory;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.IConnectionStringRetriever;

public class ChaseRequestGroupHistoryData extends DataLayerBase implements IChaseRequestGroupHistoryData {
	
	private final Log logger;

	public ChaseRequestGroupHistoryData(Log lgr, IConnectionStringRetriever icsr) {
		super(lgr, icsr);
		this.logger = lgr;
	}
	
	public ChaseRequestGroupHistoryData(IConnectionStringRetriever icsr) {
		super(icsr);
		this.logger =  LogFactory.getLog(ChaseRequestGroupHistoryData.class);
	}

	@Override
	public ChaseRequestGroupHistory InsertSingle(ChaseRequestGroupHistory pojo,
			Function<ResultSet, ChaseRequestGroupHistory> handleResultSetFunction) throws SQLException {

		ChaseRequestGroupHistory returnItem = null;

		String url = super.GetPrimaryDatabaseConnectionString();

		SQLServerDriver driver = new SQLServerDriver();

		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;

		conn = DriverManager.getConnection(url);

		cstmt = conn.prepareCall("{call dbo.uspChaseRequestGroupHistoryInsertSingle(?,?,?)}",
				ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

		// cstmt.setLong("PatientKey", patientKey);
		cstmt.setLong(1, pojo.getChaseRequestGroupKey());
		cstmt.setShort(2, pojo.getMacroStatusKey());
		cstmt.setShort(3, pojo.getMicroStatusKey());

		boolean resultsExist = cstmt.execute();
		int rowsAffected = 0;

		// Protects against lack of SET NOCOUNT in stored procedure
		while (resultsExist || rowsAffected != -1) {
			if (resultsExist) {
				rs = cstmt.getResultSet();

				if (null != handleResultSetFunction) {
					returnItem = handleResultSetFunction.apply(rs);
				}

				break;
			} else {
				rowsAffected = cstmt.getUpdateCount();
			}
			resultsExist = cstmt.getMoreResults();
		}

		if (rs != null)
			try {
				rs.close();
				rs = null;
			} catch (SQLException e) {
				this.logger.info(e);
			}
		if (cstmt != null)
			try {
				cstmt.close();
				cstmt = null;
			} catch (SQLException e) {
				this.logger.info(e);
			}
		if (conn != null)
			try {
				conn.close();
				conn = null;
			} catch (SQLException e) {
				this.logger.info(e);
			}

		return returnItem;
	}
}
