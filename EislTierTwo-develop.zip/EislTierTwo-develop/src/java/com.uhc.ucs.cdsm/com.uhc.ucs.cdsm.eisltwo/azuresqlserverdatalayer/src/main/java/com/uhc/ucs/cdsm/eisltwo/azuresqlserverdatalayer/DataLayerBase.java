package com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.IConnectionStringRetriever;

public abstract class DataLayerBase {

	protected final Log logger;
	private final IConnectionStringRetriever connectionStringRetriever;
	
	public DataLayerBase(Log lgr, IConnectionStringRetriever icsr) {

		if (null == lgr) {
			throw new IllegalArgumentException("Log is null");
		}

		this.logger = lgr;
		this.connectionStringRetriever = icsr;
	}
	
	public DataLayerBase(IConnectionStringRetriever icsr) {
		this.connectionStringRetriever = icsr;
		logger = LogFactory.getLog(DataLayerBase.class);
	}
	
	public String GetPrimaryDatabaseConnectionString()
	{
		return connectionStringRetriever.retrievePrimaryDatabaseConnectionString();
	}
}
