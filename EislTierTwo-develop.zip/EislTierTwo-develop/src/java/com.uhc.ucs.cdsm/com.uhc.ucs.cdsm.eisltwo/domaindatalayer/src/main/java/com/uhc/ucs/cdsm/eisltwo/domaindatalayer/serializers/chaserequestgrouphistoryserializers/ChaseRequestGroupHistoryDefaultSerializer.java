package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.chaserequestgrouphistoryserializers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistory;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.chaserequestgrouphistorylayouts.ChaseRequestGroupHistoryDefaultLayout;

public class ChaseRequestGroupHistoryDefaultSerializer {
	public ChaseRequestGroupHistory serializeSingle(ResultSet rs) throws SQLException {
		List<ChaseRequestGroupHistory> items = this.serializeCollection(rs);
		ChaseRequestGroupHistory returnItem = items.stream().findFirst().orElse(null);
		return returnItem;
	}

	public List<ChaseRequestGroupHistory> serializeCollection(ResultSet rs) throws SQLException {
		ChaseRequestGroupHistory item;
		List<ChaseRequestGroupHistory> returnCollection = new ArrayList<ChaseRequestGroupHistory>();
		if (null != rs) {
			while (rs.next()) {
				item = new ChaseRequestGroupHistory();
				item.setChaseRequestGroupHistoryKey(
						rs.getLong(ChaseRequestGroupHistoryDefaultLayout.ChaseRequestGroupHistoryKey));
				item.setChaseRequestGroupKey(rs.getLong(ChaseRequestGroupHistoryDefaultLayout.ChaseRequestGroupKey));
				item.setMacroStatusKey(rs.getShort(ChaseRequestGroupHistoryDefaultLayout.MacroStatusKey));
				item.setMicroStatusKey(rs.getShort(ChaseRequestGroupHistoryDefaultLayout.MicroStatusKey));
				item.setInsertDate(rs.getDate(ChaseRequestGroupHistoryDefaultLayout.InsertDate));
				item.setInsertedBy(rs.getString(ChaseRequestGroupHistoryDefaultLayout.InsertedBy));
				item.setLastUpdated(rs.getDate(ChaseRequestGroupHistoryDefaultLayout.LastUpdated));
				item.setLastUpdatedBy(rs.getString(ChaseRequestGroupHistoryDefaultLayout.LastUpdatedBy));
				returnCollection.add(item);
			}
		}
		return returnCollection;
	}
}
