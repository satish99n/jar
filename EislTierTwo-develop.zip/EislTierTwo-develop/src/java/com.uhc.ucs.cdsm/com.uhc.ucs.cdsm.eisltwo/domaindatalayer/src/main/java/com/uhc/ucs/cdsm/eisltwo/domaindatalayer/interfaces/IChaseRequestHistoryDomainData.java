package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces;

import java.util.Collection;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistory;
import com.uhc.ucs.cdsm.domain.models.Patient;

public interface IChaseRequestHistoryDomainData {

	void InsertChaseRequestHistory(ChaseRequestHistory pojo) throws Exception;
	
}
