package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.patientserializers;

import com.uhc.ucs.cdsm.domain.models.Patient;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.patientlayouts.PatientDefaultLayout;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PatientDefaultSerializer {
	public Patient serializeSingle(ResultSet rs) throws SQLException {
		List<Patient> items = this.serializeCollection(rs);
		Patient returnItem = items.stream().findFirst().orElse(null);
		return returnItem;
	}

	public List<Patient> serializeCollection(ResultSet rs) throws SQLException {
		Patient item;
		List<Patient> returnCollection = new ArrayList<Patient>();
		if (null != rs) {
			while (rs.next()) {
				item = new Patient();
				item.setPatientKey(rs.getLong(PatientDefaultLayout.PatientKey));
				item.setPatientUniqueIdentifier(rs.getString(PatientDefaultLayout.PatientUniqueIdentifier));
				item.setInsertDate(rs.getDate(PatientDefaultLayout.InsertDate));
				item.setInsertedBy(rs.getString(PatientDefaultLayout.InsertedBy));
				item.setLastUpdated(rs.getDate(PatientDefaultLayout.LastUpdated));
				item.setLastUpdatedBy(rs.getString(PatientDefaultLayout.LastUpdatedBy));
				returnCollection.add(item);
			}
		}
		return returnCollection;
	}
}