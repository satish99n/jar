package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.serializers.systemsettingserializers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.ucs.cdsm.domain.models.SystemSetting;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.systemsettinglayouts.SystemSettingDefaultLayout;

public class SystemSettingDefaultSerializer {
	public SystemSetting serializeSingle(ResultSet rs) throws SQLException {
		List<SystemSetting> items = this.serializeCollection(rs);
		SystemSetting returnItem = items.stream().findFirst().orElse(null);
		return returnItem;
	}

	public List<SystemSetting> serializeCollection(ResultSet rs) throws SQLException {
		SystemSetting item;
		List<SystemSetting> returnCollection = new ArrayList<SystemSetting>();
		if (null != rs) {
			while (rs.next()) {
				item = new SystemSetting();
				item.setSystemSettingKey(rs.getInt(SystemSettingDefaultLayout.SystemSettingKey));
				item.setSystemSettingCategoryKey(rs.getInt(SystemSettingDefaultLayout.SystemSettingCategoryKey));
				item.setSettingKeyName(rs.getString(SystemSettingDefaultLayout.SettingKeyName));
				item.setSettingKeyDisplayName(rs.getString(SystemSettingDefaultLayout.SettingKeyDisplayName));
				item.setSettingValue(rs.getString(SystemSettingDefaultLayout.SettingValue));
				item.setSettingValueType(rs.getString(SystemSettingDefaultLayout.SettingValueType));
				item.setInsertDate(rs.getDate(SystemSettingDefaultLayout.InsertDate));
				item.setInsertedBy(rs.getString(SystemSettingDefaultLayout.InsertedBy));
				item.setLastUpdated(rs.getDate(SystemSettingDefaultLayout.LastUpdated));
				item.setLastUpdatedBy(rs.getString(SystemSettingDefaultLayout.LastUpdatedBy));
				returnCollection.add(item);
			}
		}
		return returnCollection;
	}
}
