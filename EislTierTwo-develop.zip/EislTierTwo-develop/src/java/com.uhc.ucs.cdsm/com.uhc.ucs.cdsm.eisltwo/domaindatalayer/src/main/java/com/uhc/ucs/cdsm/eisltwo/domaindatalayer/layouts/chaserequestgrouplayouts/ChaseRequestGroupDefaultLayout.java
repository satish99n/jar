package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.chaserequestgrouplayouts;

public final class ChaseRequestGroupDefaultLayout {
	public static final int ChaseRequestGroupKey = 1;
	public static final int ChaseRequestGroupUniqueIdentifier = 2;
	public static final int InsertDate = 3;
	public static final int InsertedBy = 4;
	public static final int LastUpdated = 5;
	public static final int LastUpdatedBy = 6;
}
