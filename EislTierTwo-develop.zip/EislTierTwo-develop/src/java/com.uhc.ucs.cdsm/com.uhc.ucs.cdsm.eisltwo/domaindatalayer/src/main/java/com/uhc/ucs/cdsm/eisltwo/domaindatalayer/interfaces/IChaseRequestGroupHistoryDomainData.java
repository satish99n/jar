package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistory;

public interface IChaseRequestGroupHistoryDomainData {
	ChaseRequestGroupHistory UpsertSingle(ChaseRequestGroupHistory pojo) throws Exception;
}
