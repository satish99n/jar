package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.chaserequestgrouphistorylayouts;

public final class ChaseRequestGroupHistoryDefaultLayout {
	public static final int ChaseRequestGroupHistoryKey = 1;
	public static final int ChaseRequestGroupKey = 2;
	public static final int MacroStatusKey = 3;
	public static final int MicroStatusKey = 4;
	public static final int InsertDate = 5;
	public static final int InsertedBy = 6;
	public static final int LastUpdated = 7;
	public static final int LastUpdatedBy = 8;
}
