package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.objectmappers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;
import java.util.stream.Collectors;

import com.uhc.ucs.cdsm.domain.models.ChaseRequest;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistory;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistory;
import com.uhc.ucs.cdsm.domain.models.Encounter;
import com.uhc.ucs.cdsm.domain.models.Patient;

public class ChaseRequestGroupObjectMapper {

	public ChaseRequestGroup StitchTogether(ChaseRequestGroup crg, Collection<ChaseRequestGroupHistory> allCrghs,
			Collection<ChaseRequest> allCrs, Collection<ChaseRequestHistory> allCrhs, Collection<Encounter> allEncs,
			Collection<Patient> allPats) {

		ChaseRequestGroup returnItem = null;

		Collection<ChaseRequestGroup> allCrgs = new ArrayList<ChaseRequestGroup>(Arrays.asList(crg));

		Collection<ChaseRequestGroup> coll = this.StitchTogether(allCrgs, allCrghs, allCrs, allCrhs, allEncs, allPats);
		if (null != coll) {
			Optional<ChaseRequestGroup> result = coll.stream().findAny();
			if (result.isPresent()) {
				returnItem = result.get();
			}
		}

		return returnItem;
	}

	public Collection<ChaseRequestGroup> StitchTogether(Collection<ChaseRequestGroup> allCrgs,
			Collection<ChaseRequestGroupHistory> allCrghs, Collection<ChaseRequest> allCrs,
			Collection<ChaseRequestHistory> allCrhs, Collection<Encounter> allEncs, Collection<Patient> allPats) {

		if (null != allCrgs) {
			for (ChaseRequestGroup crg : allCrgs) {
				if (null != allCrs) {

					Collection<ChaseRequestGroupHistory> foundChaseRequestGroupHistorys = allCrghs.stream()
							.filter(x -> x.getChaseRequestGroupKey() == crg.getChaseRequestGroupKey())
							.collect(Collectors.toList());

					if (null != foundChaseRequestGroupHistorys) {
						crg.setChaseRequestGroupHistories(foundChaseRequestGroupHistorys);
						for (ChaseRequestGroupHistory foundChaseRequestGroupHistory : foundChaseRequestGroupHistorys) {
							foundChaseRequestGroupHistory.setChaseRequestGroupKey(crg.getChaseRequestGroupKey());
							foundChaseRequestGroupHistory.setParentChaseRequestGroup(crg);
						}
					}

					Collection<ChaseRequest> foundChaseRequests = allCrs.stream()
							.filter(x -> x.getChaseRequestGroupKey() == crg.getChaseRequestGroupKey())
							.collect(Collectors.toList());

					if (null != foundChaseRequests) {
						crg.setChaseRequests(foundChaseRequests);
						for (ChaseRequest foundChaseRequest : foundChaseRequests) {
							foundChaseRequest.setChaseRequestGroupKey(crg.getChaseRequestGroupKey());
							foundChaseRequest.setParentChaseRequestGroup(crg);
							
							
							Collection<ChaseRequestHistory> foundChaseRequestHistorys = allCrhs.stream()
									.filter(x -> x.getChaseRequestKey() == foundChaseRequest.getChaseRequestKey())
									.collect(Collectors.toList());

							if (null != foundChaseRequestHistorys) {
								foundChaseRequest.setChaseRequestHistories(foundChaseRequestHistorys);
								for (ChaseRequestHistory foundChaseRequestHistory : foundChaseRequestHistorys) {
									foundChaseRequestHistory.setChaseRequestKey(foundChaseRequest.getChaseRequestKey());
									foundChaseRequestHistory.setParentChaseRequest(foundChaseRequest);
								}
							}

							/* now Encounters */
							Encounter foundFirstEncounter = allEncs.stream()
									.filter(x -> x.getEncounterKey() == foundChaseRequest.getEncounterKey()).findFirst()
									.orElse(null);							

							if (null != foundFirstEncounter) {
								foundChaseRequest.setParentEncounter(foundFirstEncounter);
								foundFirstEncounter.getChaseRequests().add(foundChaseRequest);

								Patient foundFirstPatient = allPats.stream()
										.filter(x -> x.getPatientKey() == foundFirstEncounter.getPatientKey())
										.findFirst().orElse(null);

								if (null != foundFirstPatient) {
									foundFirstEncounter.setParentPatient(foundFirstPatient);
									foundFirstPatient.getEncounters().add(foundFirstEncounter);
								}
							}
						}
					}
				}
			}
		}

		return allCrgs;
	}
}
