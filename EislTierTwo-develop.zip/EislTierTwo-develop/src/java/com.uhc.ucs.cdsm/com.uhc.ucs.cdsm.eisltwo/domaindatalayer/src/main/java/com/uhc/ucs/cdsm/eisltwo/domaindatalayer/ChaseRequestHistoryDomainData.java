package com.uhc.ucs.cdsm.eisltwo.domaindatalayer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.datalayer.interfaces.IChaseRequestHistoryData;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistory;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IChaseRequestHistoryDomainData;

public class ChaseRequestHistoryDomainData implements IChaseRequestHistoryDomainData {

	private final Log logger;
	private final IChaseRequestHistoryData chaseRequestHistoryData;

	public ChaseRequestHistoryDomainData(Log lgr, IChaseRequestHistoryData icrhd) {

		if (null == lgr) {
			throw new IllegalArgumentException("Log is null");
		}

		if (null == icrhd) {
			throw new IllegalArgumentException("IChaseRequestHistoryData");
		}

		this.logger = lgr;
		this.chaseRequestHistoryData = icrhd;
	}
	
	public ChaseRequestHistoryDomainData(IChaseRequestHistoryData icrhd) {

		if (null == icrhd) {
			throw new IllegalArgumentException("IChaseRequestHistoryData");
		}

		this.logger = LogFactory.getLog(ChaseRequestHistoryDomainData.class);;
		this.chaseRequestHistoryData = icrhd;
	}
	
	public void InsertChaseRequestHistory(ChaseRequestHistory pojo) throws Exception {
		this.chaseRequestHistoryData.InsertSingle(pojo, null);
	}

}
