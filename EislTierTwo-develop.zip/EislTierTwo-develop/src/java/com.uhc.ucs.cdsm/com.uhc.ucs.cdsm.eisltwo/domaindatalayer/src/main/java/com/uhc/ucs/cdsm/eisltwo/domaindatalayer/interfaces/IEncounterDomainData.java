package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces;

import com.uhc.ucs.cdsm.domain.models.Encounter;

public interface IEncounterDomainData {
	Encounter updateSingle(Encounter pojo) throws Exception;

	void insertInsuranceHistoryDistinct(String primaryInsuranceIdentifier, String secondaryInsuranceIdentifier,
			String tertiaryInsuranceIdentifier, String quartaneryInsuranceIdentifier, String quinaryInsuranceIdentifier)
			throws Exception;
}
