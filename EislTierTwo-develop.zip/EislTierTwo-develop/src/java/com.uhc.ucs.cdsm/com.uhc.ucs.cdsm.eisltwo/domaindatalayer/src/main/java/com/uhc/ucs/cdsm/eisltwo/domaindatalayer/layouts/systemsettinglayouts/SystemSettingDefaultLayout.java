package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.layouts.systemsettinglayouts;

public final class SystemSettingDefaultLayout {
	public static final int SystemSettingKey = 1;
	public static final int SystemSettingCategoryKey = 2;
	public static final int SettingKeyName = 3;
	public static final int SettingKeyDisplayName = 4;
	public static final int SettingValue = 5;
	public static final int SettingValueType = 6;
	public static final int InsertDate = 7;
	public static final int InsertedBy = 8;
	public static final int LastUpdated = 9;
	public static final int LastUpdatedBy = 10;
}