package com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces;

import java.util.Collection;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.Patient;

public interface IPatientDomainData {
	Patient GetPatientByKey(long patientKey) throws Exception;
	
	Collection<ChaseRequestGroup> UpsertPatientsAndEncounters(Collection<Patient> patients) throws Exception;
}
