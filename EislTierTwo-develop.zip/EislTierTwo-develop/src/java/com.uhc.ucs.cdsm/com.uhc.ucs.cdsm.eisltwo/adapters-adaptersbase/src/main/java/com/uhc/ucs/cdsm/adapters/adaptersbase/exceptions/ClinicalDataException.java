package com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions;

public class ClinicalDataException extends Exception {

	private static final long serialVersionUID = 1L;

	public ClinicalDataException()
	{
		super();
	}
	

	public ClinicalDataException(String  meassage, Throwable th) {
		super(meassage, th);
	}

	public ClinicalDataException(String meassage) {
		super(meassage);
	}

	public ClinicalDataException(Throwable th) {
		super(th);
	}
}
