package com.uhc.ucs.cdsm.adapters.adaptersbase.models;

public class Insurance {
	private String insuranceName;
	private Type type;
	private  Address address;
	private String groupNumber;
	private  String InsuranceClass;
	private String InsuranceConcact;
	
public enum Type{
		PrimaryInsurance,SecondaryInsurance,TertiaryInsurance,QuartaneryInsurance,QuinaryInsurance;

	public static Type getTypeByValue(String value) {
		 Type type = null;
		 switch(value) {
		 case "PrimaryInsurance":
			 type = PrimaryInsurance;
			 break;
		 case "SecondaryInsurance":
			 type = SecondaryInsurance;
			 break;
		 case "TertiaryInsurance":
			 type = TertiaryInsurance;
			 break;
		 case "QuartaneryInsurance":
			 type = QuartaneryInsurance;
			 break;
		 case "QuinaryInsurance":
			 type=QuinaryInsurance;
			 break;
			 
			 default:
				 break;
		 }
		 
		 return type;
	 }
	}
	
	public String getInsuranceName() {
		return insuranceName;
	}
	public void setInsuranceName(String insuranceName) {
		this.insuranceName = insuranceName;
	}
	public Type getType() {
		return type;
	}
	public void setType(Type type) {
		this.type = type;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getGroupNumber() {
		return groupNumber;
	}
	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}
	public String getInsuranceClass() {
		return InsuranceClass;
	}
	public void setInsuranceClass(String insuranceClass) {
		InsuranceClass = insuranceClass;
	}
	public String getInsuranceConcact() {
		return InsuranceConcact;
	}
	public void setInsuranceConcact(String insuranceConcact) {
		InsuranceConcact = insuranceConcact;
	}
	@Override
	public String toString() {
		return "Insurance [primaryInsurance=" + insuranceName + ", type=" + type + ", address=" + address
				+ ", groupNumber=" + groupNumber + ", InsuranceClass=" + InsuranceClass + ", InsuranceConcact="
				+ InsuranceConcact + "]";
	}
	
	
	
	
	

}

