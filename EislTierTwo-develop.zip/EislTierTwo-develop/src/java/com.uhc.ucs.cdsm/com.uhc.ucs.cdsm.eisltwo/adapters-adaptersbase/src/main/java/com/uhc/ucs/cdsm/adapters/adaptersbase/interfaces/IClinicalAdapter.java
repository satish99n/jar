package com.uhc.ucs.cdsm.adapters.adaptersbase.interfaces;

import java.util.Date;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.DocumentWrapper;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Encounter;
import com.uhc.ucs.cdsm.adapters.adaptersbase.models.Patient;

public interface IClinicalAdapter {

	List<Encounter> getEncounters(Date fromDate, Date toDate) throws ClinicalDataException;
	
	Patient getPatientDetails(String patientID)  throws ClinicalDataException;
	
	DocumentWrapper getCCDA(String patientID, String encounterID)  throws ClinicalDataException;
}
