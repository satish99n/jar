package com.uhc.ucs.cdsm.eisltwo.webclient.consoleone;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;
import java.util.Random;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.microsoft.windowsazure.services.servicebus.models.BrokeredMessage;
import com.uhc.ucs.cdsm.datalayer.interfaces.IChaseRequestGroupData;
import com.uhc.ucs.cdsm.datalayer.interfaces.IChaseRequestGroupHistoryData;
import com.uhc.ucs.cdsm.datalayer.interfaces.IChaseRequestHistoryData;
import com.uhc.ucs.cdsm.datalayer.interfaces.IEncounterData;
import com.uhc.ucs.cdsm.datalayer.interfaces.IPatientData;
import com.uhc.ucs.cdsm.datalayer.interfaces.ISystemSettingData;
import com.uhc.ucs.cdsm.domain.dictionaries.ChaseRequestGroupHistoryMacroStatusDictionary;
import com.uhc.ucs.cdsm.domain.dictionaries.ChaseRequestGroupHistoryMicroStatusDictionary;
import com.uhc.ucs.cdsm.domain.dictionaries.ChaseRequestHistoryMacroStatusDictionary;
import com.uhc.ucs.cdsm.domain.dictionaries.ChaseRequestHistoryMicroStatusDictionary;
import com.uhc.ucs.cdsm.domain.dictionaries.SystemSettingCategoryDictionary;
import com.uhc.ucs.cdsm.domain.models.ChaseRequest;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroupHistory;
import com.uhc.ucs.cdsm.domain.models.ChaseRequestHistory;
import com.uhc.ucs.cdsm.domain.models.Encounter;
import com.uhc.ucs.cdsm.domain.models.Patient;
import com.uhc.ucs.cdsm.domain.models.SystemSetting;
import com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer.ChaseRequestGroupData;
import com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer.ChaseRequestGroupHistoryData;
import com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer.ChaseRequestHistoryData;
import com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer.EncounterData;
import com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer.PatientData;
import com.uhc.ucs.cdsm.eisltwo.azuresqlserverdatalayer.SystemSettingData;
import com.uhc.ucs.cdsm.eisltwo.clientproxies.ExampleProxy;
import com.uhc.ucs.cdsm.eisltwo.clientproxies.interfaces.IExampleProxy;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.ConnectionStringRetrieverNoEncryption;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.IConnectionStringRetriever;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.ChaseRequestGroupDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.EncounterDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.PatientDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.SystemSettingDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IChaseRequestGroupDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IEncounterDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.IPatientDomainData;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.ISystemSettingDomainData;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.QueueMessageReader;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.QueueMessageSender;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.arguments.QueueMessageReadArgs;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.compositions.ReadResult;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.interfaces.IQueueMessageReader;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.interfaces.IQueueMessageSender;

public class App {

	private static Log mlog = LogFactory.getLog(App.class);

	public static void main(String[] args) {
		mlog.info("Hello World!");

		try {
			// ObjectModelDemo(mlog);
			RunDomainData(mlog);
			// RunExampleProxy(mlog);
			// RunServiceBusSample(mlog);
		} catch (Exception ex) {
			Throwable thr = ex;
			while (null != thr) {
				System.out.println(ex.getMessage());
				thr = thr.getCause();
			}
		} finally {
			mlog.info("DONE");
		}

		System.out.println("Done");
	}

	private static void RunDomainData(Log log) throws Exception {

		IConnectionStringRetriever csr = new ConnectionStringRetrieverNoEncryption(log);

		Encounter encounterToUpdate = null;

		IChaseRequestGroupData crgd = new ChaseRequestGroupData(log, csr);
		IChaseRequestGroupDomainData crgdd = new ChaseRequestGroupDomainData(log, crgd);

		log.info("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		ChaseRequestGroup retrievedChaseRequestGroup = crgdd.retrieveSingle(0);
		if (null != retrievedChaseRequestGroup) {
			log.info(String.format("getChaseRequestGroupKey=%s", retrievedChaseRequestGroup.getChaseRequestGroupKey()));
			log.info(String.format("getChaseRequestGroupUniqueIdentifier=%s",
					retrievedChaseRequestGroup.getChaseRequestGroupUniqueIdentifier()));

			Collection<ChaseRequestGroupHistory> crghs = retrievedChaseRequestGroup.getChaseRequestGroupHistories();
			if (null != crghs) {
				for (ChaseRequestGroupHistory crgh : crghs) {
					log.debug(String.format("    ChaseRequestGroupHistory.getChaseRequestGroupHistoryKey %s",
							crgh.getChaseRequestGroupHistoryKey()));
					log.debug(String.format("    ChaseRequestGroupHistory.getChaseRequestGroupKey %s",
							crgh.getChaseRequestGroupKey()));
					log.debug(String.format("    ChaseRequestGroupHistory.getInsertedBy %s", crgh.getInsertedBy()));
				}
			} else {
				throw new NullPointerException("getChaseRequestGroupHistories");
			}

			if (null != retrievedChaseRequestGroup.getChaseRequests()) {
				for (ChaseRequest cr : retrievedChaseRequestGroup.getChaseRequests()) {
					log.debug(String.format("    ChaseRequest.getChaseRequestKey %s", cr.getChaseRequestKey()));
					log.debug(
							String.format("    ChaseRequest.getChaseRequestGroupKey %s", cr.getChaseRequestGroupKey()));
					log.debug(String.format("    ChaseRequest.getEncounterKey %s", cr.getEncounterKey()));
					log.debug(String.format("    ChaseRequest.getInsertedBy %s", cr.getInsertedBy()));

					Collection<ChaseRequestHistory> crhs = cr.getChaseRequestHistories();
					if (null != crhs) {
						for (ChaseRequestHistory crh : crhs) {
							log.debug(String.format("    ChaseRequestHistory.getChaseRequestHistoryKey %s",
									crh.getChaseRequestHistoryKey()));
							log.debug(String.format("    ChaseRequestHistory.getChaseRequestKey %s",
									crh.getChaseRequestKey()));
							log.debug(String.format("    ChaseRequestHistory.getInsertedBy %s", crh.getInsertedBy()));
						}
					} else {
						throw new NullPointerException("getChaseRequestHistories");
					}

					Encounter enc = cr.getParentEncounter();

					if (null != enc) {
						encounterToUpdate = enc;

						log.debug(String.format("    Encounter.getEncounterKey %s", enc.getEncounterKey()));
						log.debug(String.format("    Encounter.getEncounterUniqueIdentifier %s",
								enc.getEncounterUniqueIdentifier()));
						log.debug(String.format("    Encounter.getPatientKey %s", enc.getPatientKey()));
						log.debug(String.format("    Encounter.getInsertedBy %s", enc.getInsertedBy()));

						Patient pat = enc.getParentPatient();
						if (null != pat) {
							log.debug(String.format("    Patient.getPatientKey %s", pat.getPatientKey()));
							log.debug(String.format("    Patient.getPatientUniqueIdentifier %s",
									pat.getPatientUniqueIdentifier()));
							log.debug(String.format("    Patient.getInsertedBy %s", enc.getInsertedBy()));
						} else {
							throw new NullPointerException("getParentPatient");
						}
					} else {
						throw new NullPointerException("getParentEncounter");
					}
				}
			} else {
				throw new NullPointerException("getChaseRequests");
			}
		} else {
			throw new NullPointerException("retrievedChaseRequestGroup");
		}

		log.info("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");

		IEncounterData ed = new EncounterData(log, csr);
		IEncounterDomainData edd = new EncounterDomainData(log, ed);

		if (null != encounterToUpdate) {
			
			encounterToUpdate.setPrimaryInsuranceIdentifier("PrimaryInsuranceIdentifier" + java.util.UUID.randomUUID().toString());
			encounterToUpdate.setSecondaryInsuranceIdentifier("SecondaryInsuranceIdentifier" + java.util.UUID.randomUUID().toString());
			
			Encounter updatedEnc = edd.updateSingle(encounterToUpdate);
			if (null != updatedEnc) {
				log.debug(String.format("    Encounter.getEncounterKey %s", updatedEnc.getEncounterKey()));
				log.debug(String.format("    Encounter.getEncounterUniqueIdentifier %s",
						updatedEnc.getEncounterUniqueIdentifier()));
				log.debug(String.format("    Encounter.getPatientKey %s", updatedEnc.getPatientKey()));
				log.debug(String.format("    Encounter.getInsertedBy %s", updatedEnc.getInsertedBy()));
				
				log.debug(String.format("    Encounter.getPrimaryInsuranceIdentifier %s", updatedEnc.getPrimaryInsuranceIdentifier()));
				log.debug(String.format("    Encounter.getSecondaryInsuranceIdentifier %s", updatedEnc.getSecondaryInsuranceIdentifier()));
				
			}
		}

		Thread.sleep(7000);

		long fakeChaseRequestGroupKey = -123;
		ChaseRequestGroup crgPojo = new ChaseRequestGroup();
		crgPojo.setChaseRequestGroupKey(fakeChaseRequestGroupKey);

		long masterChaseRequestGroupHistoryKey = -222;

		ChaseRequestGroupHistory newStatusChaseRequestGroup = new ChaseRequestGroupHistory();
		newStatusChaseRequestGroup.setChaseRequestGroupHistoryKey(masterChaseRequestGroupHistoryKey);
		newStatusChaseRequestGroup.setChaseRequestGroupKey(crgPojo.getChaseRequestGroupKey());
		newStatusChaseRequestGroup.setParentChaseRequestGroup(crgPojo);

		/* create the very first "history" row */
		newStatusChaseRequestGroup.setMacroStatusKey(
				(short) ChaseRequestGroupHistoryMacroStatusDictionary.New.getChaseRequestGroupHistoryMacroStatusKey());
		newStatusChaseRequestGroup
				.setMicroStatusKey((short) ChaseRequestGroupHistoryMicroStatusDictionary.NewMicroDefault
						.getChaseRequestGroupHistoryMicroStatusKey());
		crgPojo.getChaseRequestGroupHistories().add(newStatusChaseRequestGroup);

		ChaseRequestGroup postDbUpsertCrgPojo = crgdd.upsertSingle(crgPojo);

		if (null != postDbUpsertCrgPojo) {
			log.info(String.format("getChaseRequestGroupKey=%s", postDbUpsertCrgPojo.getChaseRequestGroupKey()));
			log.info(String.format("getChaseRequestGroupUniqueIdentifier=%s",
					postDbUpsertCrgPojo.getChaseRequestGroupUniqueIdentifier()));
		}

		Thread.sleep(3000);

		IPatientData pd = new PatientData(log, csr);
		IPatientDomainData pdd = new PatientDomainData(log, pd);

		Collection<Patient> patients = ObjectModelDemo(log, postDbUpsertCrgPojo.getChaseRequestGroupKey());
		Collection<ChaseRequestGroup> crgs = pdd.UpsertPatientsAndEncounters(patients);
		if (null != crgs) {
			for (ChaseRequestGroup crg : crgs) {
				log.debug(String.format("    ChaseRequestGroup.getChaseRequestGroupKey %s",
						crg.getChaseRequestGroupKey()));
				log.debug(String.format("    ChaseRequestGroup.getChaseRequestGroupUniqueIdentifier %s",
						crg.getChaseRequestGroupUniqueIdentifier()));
				log.debug(String.format("    ChaseRequestGroup.getInsertedBy %s", crg.getInsertedBy()));
			}
		}

		log.info("BULK UPDATE WORKED....GO SET BASED CODE!");

		long existingPatientKey = patients.stream().findFirst().get().getPatientKey();
		Patient p = pdd.GetPatientByKey(existingPatientKey);
		if (null != p) {
			log.info(String.format("getPatientKey=%s", p.getPatientKey()));
			log.info(String.format("getPatientUniqueIdentifier=%s", p.getPatientUniqueIdentifier()));
		}

		ChaseRequestGroup foundChaseRequestGroup = patients.stream().findFirst().get().getEncounters().stream()
				.findFirst().get().getChaseRequests().stream().findFirst().get().getParentChaseRequestGroup();
		IChaseRequestGroupHistoryData crghd = new ChaseRequestGroupHistoryData(log, csr);
		ChaseRequestGroupHistory crghPojo = new ChaseRequestGroupHistory();
		crghPojo.setChaseRequestGroupKey(foundChaseRequestGroup.getChaseRequestGroupKey()); /* FK must exist already */
		crghPojo.setMacroStatusKey(ChaseRequestGroupHistoryMacroStatusDictionary.CompletedWithNoErrors
				.getChaseRequestGroupHistoryMacroStatusKey());
		crghPojo.setMicroStatusKey(ChaseRequestGroupHistoryMicroStatusDictionary.CompletedWithNoErrorsMicroDefault
				.getChaseRequestGroupHistoryMicroStatusKey());
		crghd.InsertSingle(crghPojo, null);

		ChaseRequest foundChaseRequest = patients.stream().findFirst().get().getEncounters().stream().findFirst().get()
				.getChaseRequests().stream().findFirst().get();
		IChaseRequestHistoryData crhd = new ChaseRequestHistoryData(log, csr);
		ChaseRequestHistory crhPojo = new ChaseRequestHistory();
		crhPojo.setChaseRequestKey(foundChaseRequest.getChaseRequestKey()); /* FK must exist already */
		crhPojo.setMacroStatusKey(ChaseRequestHistoryMacroStatusDictionary.New.getChaseRequestHistoryMacroStatusKey());
		crhPojo.setMicroStatusKey(
				ChaseRequestHistoryMicroStatusDictionary.NewMicroDefault.getChaseRequestHistoryMicroStatusKey());
		// crhd.InsertSingle(crhPojo, null);

		ISystemSettingData ssd = new SystemSettingData(log, csr);
		ISystemSettingDomainData ssdd = new SystemSettingDomainData(log, ssd);
		Collection<SystemSetting> systemSettings = ssdd.GetSystemSettingByCategoryKey(
				SystemSettingCategoryDictionary.UnitedHealthcareInsuranceNameRegex.getSystemSettingCategoryKey());
		if (null != systemSettings) {
			for (SystemSetting ss : systemSettings) {
				log.debug(String.format("    SystemSetting.getSystemSettingKey %s", ss.getSystemSettingKey()));
				log.debug(String.format("    SystemSetting.getSystemSettingCategoryKey %s",
						ss.getSystemSettingCategoryKey()));
				log.debug(String.format("    SystemSetting.getSettingValue %s", ss.getSettingValue()));
			}
		}

	}

	private static void RunServiceBusSample(Log log) {
		try {
			String sendConnectionString = "Endpoint=sb://shh001-servicebus-name.servicebus.windows.net/;SharedAccessKeyName=managerule;SharedAccessKey=sqZvHgsdiVGKYZi/4yJamAUWeKN2fKRvoG5cwMKygN0=";
			String listenConnectionString = "Endpoint=sb://shh001-servicebus-name.servicebus.windows.net/;SharedAccessKeyName=managerule;SharedAccessKey=sqZvHgsdiVGKYZi/4yJamAUWeKN2fKRvoG5cwMKygN0=";
			String queueName = "queueone";

			for (int i = 0; i < 10; i++) {
				String payload = "hello:" + Integer.toString(i) + ":"
						+ new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss", Locale.US).format(new Date());
				IQueueMessageSender<String> qms = new QueueMessageSender(log);
				qms.sendMessage(sendConnectionString, queueName, payload);
			}

			QueueMessageReadArgs args = new QueueMessageReadArgs();
			args.setConnectionString(listenConnectionString);
			args.setQueueName(queueName);
			IQueueMessageReader<String> qmr = new QueueMessageReader(log);
			ReadResult<String> readRes = qmr.readMessage(args, App::handleBrokeredMessage);
			System.out.println(readRes.getSuccessfulItems().size());

		} catch (Exception ex) {
			Throwable thr = ex;
			while (null != thr) {
				System.out.println(ex.getMessage());
				thr = thr.getCause();
			}
		}
	}

	private static BrokeredMessage handleBrokeredMessage(BrokeredMessage message) {
		System.out.println("Body: " + message.toString());
		System.out.println("MessageID: " + message.getMessageId());
		System.out.println("Custom Property: " + message.getProperty("TestProperty"));
		return message;
	}

	private static void RunExampleProxy(Log log) {
		IExampleProxy ep = new ExampleProxy(log);
		String result = ep.examplePerformGet();
		System.out.println(result);
	}

	private static Collection<AllscriptsEncounterMimic> CreateFakeAllscriptsEncounters() {
		Collection<AllscriptsEncounterMimic> returnItems = new ArrayList<AllscriptsEncounterMimic>();

		for (int i = 1001; i <= 1100; i++) {

			for (int k = 1; k <= 2; k++) {

				AllscriptsEncounterMimic aem1 = new App().new AllscriptsEncounterMimic();
				aem1.setPatientValue("PatientAbc" + Integer.toString(i));
				aem1.setEncounterValue("MyEncounter" + Integer.toString(i) + "." + Integer.toString(k));
				returnItems.add(aem1);
			}
		}

		return returnItems;
	}

	private static String GetPatientInsuranceInformation(String patientValue) {
		Random rand = new Random();
		int n = rand.nextInt(10000) + 1000;
		// 50 is the maximum and the 1 is our minimum
		return patientValue + Integer.toString(n) + " InsuranceInfo";
	}

	private static Collection<Patient> ObjectModelDemo(Log log, long masterChaseRequestGroupKey) throws Exception {

		Collection<Patient> returnItems = new ArrayList<Patient>();

		/*
		 * 2 patients, 2 encounters per patient 1 ChaseRequest per Encounter (so 4 total
		 * ChaseRequests. One ChaseRequestHistory per ChaseRequest 1 ChaseRequestGroup.
		 * 1 ChaseRequestGroupHistory
		 */

		long masterChaseRequestGroupHistoryKey = -222;

		ChaseRequestGroup masterChaseRequestGroup = new ChaseRequestGroup();
		masterChaseRequestGroup.setChaseRequestGroupKey(masterChaseRequestGroupKey);/* use existing number */

		ChaseRequestGroupHistory newStatusChaseRequestGroup = new ChaseRequestGroupHistory();
		newStatusChaseRequestGroup.setChaseRequestGroupHistoryKey(masterChaseRequestGroupHistoryKey);
		newStatusChaseRequestGroup.setChaseRequestGroupKey(masterChaseRequestGroup.getChaseRequestGroupKey());
		newStatusChaseRequestGroup.setParentChaseRequestGroup(masterChaseRequestGroup);

		/* create the very first "history" row */
		newStatusChaseRequestGroup.setMacroStatusKey(
				(short) ChaseRequestGroupHistoryMacroStatusDictionary.SendBulkEncounterRequestToSourceDataCompleted
						.getChaseRequestGroupHistoryMacroStatusKey()); /* todo, change to New status */
		newStatusChaseRequestGroup.setMicroStatusKey(
				(short) ChaseRequestGroupHistoryMicroStatusDictionary.SendBulkEncounterRequestToSourceDataCompletedMicroDefault
						.getChaseRequestGroupHistoryMicroStatusKey()); /* todo, change to New status */
		masterChaseRequestGroup.getChaseRequestGroupHistories().add(newStatusChaseRequestGroup);

		/*
		 * take your json, get the distinct list of patientids (because in hte json,
		 * patientid might be repeated
		 */
		/*
		 * loop over each of these distinct patientids int patietnCounter = -1001 int
		 * entCOunter = -10001 patietnCounter-- Patient p = new Patient();
		 * p1.setPatientKey(patietnCounter); /* this way you get distinct values
		 * 
		 * entCOunter--; Encounter = new Ecounter(). e1a.setParentPatient(p);
		 * e2a.setEncounterKey(-entCOunter);
		 * 
		 * 
		 */

		/* this below mimics the allscripts json */
		Collection<AllscriptsEncounterMimic> fakeAllscriptRows = CreateFakeAllscriptsEncounters();

		/* there may be a better "distinct" java-stream way */
		Collection<AllscriptsEncounterMimic> distinctPatientValues = fakeAllscriptRows.stream()
				.collect(Collectors.groupingBy((p) -> p.patientValue)).values().stream()
				.flatMap(e -> e.stream().limit(1)).collect(Collectors.toList());

		int patientKeyReverseCounter = -10000;
		int encounterKeyReverseCounter = -20000;
		int chaseRequestKeyReverseCounter = -30000;
		int chaseRequestHistoryKeyReverseCounter = -40000;
		for (AllscriptsEncounterMimic distinctPatientAllscriptsEncounterMimic : distinctPatientValues) {

			patientKeyReverseCounter--;

			Patient currentPatient = new Patient();
			currentPatient.setPatientKey(patientKeyReverseCounter);
			currentPatient.setPatientUniqueIdentifier(distinctPatientAllscriptsEncounterMimic.getPatientValue());
			/* to do, populate scalar properties */

			Collection<AllscriptsEncounterMimic> encoutersForThisPatient = fakeAllscriptRows.stream()
					.filter(p -> p.getPatientValue().equals(distinctPatientAllscriptsEncounterMimic.getPatientValue()))
					.collect(Collectors.toList());

			for (AllscriptsEncounterMimic encouterMimicForThisPatient : encoutersForThisPatient) {

				encounterKeyReverseCounter--;

				Encounter currentEncounter = new Encounter();
				currentEncounter.setEncounterKey(encounterKeyReverseCounter);
				currentEncounter.setEncounterUniqueIdentifier(encouterMimicForThisPatient.getEncounterValue());
				/* to do, populate scalar properties */
				currentEncounter.setParentPatient(currentPatient);
				currentEncounter.setPatientKey(currentPatient.getPatientKey());

				/* ----------------------------------------------------------------------- */

				/* --- */
				chaseRequestKeyReverseCounter--;

				ChaseRequest currentChaseRequest = new ChaseRequest();
				currentChaseRequest.setChaseRequestKey(chaseRequestKeyReverseCounter);

				/* history */
				chaseRequestHistoryKeyReverseCounter--;
				ChaseRequestHistory currentChaseRequestHistory = new ChaseRequestHistory();
				currentChaseRequestHistory.setChaseRequestHistoryKey(chaseRequestHistoryKeyReverseCounter);
				currentChaseRequestHistory.setMacroStatusKey(
						(short) ChaseRequestHistoryMacroStatusDictionary.New.getChaseRequestHistoryMacroStatusKey());
				currentChaseRequestHistory
						.setMicroStatusKey((short) ChaseRequestHistoryMicroStatusDictionary.NewMicroDefault
								.getChaseRequestHistoryMicroStatusKey());

				/* reciprocal object-mapping */
				currentChaseRequest.getChaseRequestHistories().add(currentChaseRequestHistory);
				currentChaseRequestHistory.setParentChaseRequest(currentChaseRequest);
				currentChaseRequestHistory.setChaseRequestKey(currentChaseRequest.getChaseRequestKey());

				/* back to Encounter */ /* reciprocal object-mapping */
				currentChaseRequest.setParentEncounter(currentEncounter);
				currentChaseRequest.setEncounterKey(currentEncounter.getEncounterKey());
				currentEncounter.getChaseRequests().add(currentChaseRequest);

				/*
				 * remember to set "reciprocal" relationships, here is simple example;
				 * Department d = new Department(); /// Department has N number of Employees
				 * d.setDeptKey(111); Employee emp = new Employee(); // below is the
				 * "reciprocal". set objects and "Foreign Keys" emp.setParentDepartment = d;
				 * emp.setDepartmentKey(d.getDeptKey()); // finally, add this (child) emp back
				 * to the (parent) Dept's collection for Employees d.getEmployees.Add(emp) ;
				 */

				currentChaseRequest.setParentChaseRequestGroup(masterChaseRequestGroup);
				currentChaseRequest.setChaseRequestGroupKey(masterChaseRequestGroupKey);
				masterChaseRequestGroup.getChaseRequests().add(currentChaseRequest);

				/* --- */

				currentPatient.getEncounters().add(currentEncounter);
			}

			returnItems.add(currentPatient);
		}

		if (null != masterChaseRequestGroup) {
			log.debug(String.format("masterChaseRequestGroup.getChaseRequestGroupKey %s",
					masterChaseRequestGroup.getChaseRequestGroupKey()));
			log.debug("........................");
			for (ChaseRequestGroupHistory crgh : masterChaseRequestGroup.getChaseRequestGroupHistories()) {
				log.debug(String.format("    ChaseRequestGroupHistory.getChaseRequestGroupHistoryKey %s",
						crgh.getChaseRequestGroupHistoryKey()));
				log.debug(String.format("    ChaseRequestGroupHistory.getMacroStatusKey %s", crgh.getMacroStatusKey()));
				log.debug(String.format("    ChaseRequestGroupHistory.getMicroStatusKey %s", crgh.getMicroStatusKey()));
			}
			log.debug("........................");
			for (ChaseRequest cr : masterChaseRequestGroup.getChaseRequests()) {
				log.debug(String.format("    ChaseRequest.getChaseRequestKey %s", cr.getChaseRequestKey()));

				for (ChaseRequestHistory crgh : cr.getChaseRequestHistories()) {
					log.debug(String.format("    ChaseRequestHistory.getChaseRequestHistoryKey %s",
							crgh.getChaseRequestHistoryKey()));
					log.debug(String.format("    ChaseRequestHistory.getMacroStatusKey %s", crgh.getMacroStatusKey()));
					log.debug(String.format("    ChaseRequestHistory.getMicroStatusKey %s", crgh.getMicroStatusKey()));
				}
				log.debug("........................");

				Encounter currentEncounter = cr.getParentEncounter();
				if (null != currentEncounter) {
					{
						log.debug(String.format("        Encounter.getEncounterKey %s",
								currentEncounter.getEncounterKey()));
						log.debug(String.format("        Encounter.getEncounterUniqueIdentifier %s",
								currentEncounter.getEncounterUniqueIdentifier()));

						Patient currentPatient = currentEncounter.getParentPatient();
						if (null != currentPatient) {
							log.debug(String.format("            Patient.getPatientKey %s",
									currentPatient.getPatientKey()));
							log.debug(String.format("            Patient.getPatientUniqueIdentifier %s",
									currentPatient.getPatientUniqueIdentifier()));
						}

					}
					log.debug("........................");
				}
			}
			log.debug("........................");
			log.debug("........................");
			log.debug("........................");

		}

		return returnItems;

	}

	private class AllscriptsEncounterMimic {
		private String encounterValue;
		private String patientValue;

		public String getEncounterValue() {
			return encounterValue;
		}

		public void setEncounterValue(String encounterValue) {
			this.encounterValue = encounterValue;
		}

		public String getPatientValue() {
			return patientValue;
		}

		public void setPatientValue(String patientValue) {
			this.patientValue = patientValue;
		}
	}

}
