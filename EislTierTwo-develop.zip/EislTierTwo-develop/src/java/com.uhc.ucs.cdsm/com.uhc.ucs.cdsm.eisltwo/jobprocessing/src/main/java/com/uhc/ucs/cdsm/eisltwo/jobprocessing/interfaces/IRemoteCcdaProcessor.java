package com.uhc.ucs.cdsm.eisltwo.jobprocessing.interfaces;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;

public interface IRemoteCcdaProcessor {
	void performWork(String fromDateString, String toDateString) throws ClinicalDataException, IOException, InterruptedException, ExecutionException, Exception;
}
