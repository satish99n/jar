package com.uhc.ucs.cdsm.eisltwo.jobprocessing;

import com.uhc.ucs.cdsm.adapters.adaptersbase.exceptions.ClinicalDataException;
import com.uhc.ucs.cdsm.businesslogic.managers.interfaces.ICCDAWorkflowManger;
import com.uhc.ucs.cdsm.domain.dictionaries.SystemSettingCategoryDictionary;
import com.uhc.ucs.cdsm.domain.dictionaries.SystemSettingDictionary;
import com.uhc.ucs.cdsm.domain.models.SystemSetting;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.ISystemSettingDomainData;
import com.uhc.ucs.cdsm.eisltwo.jobprocessing.interfaces.IRemoteCcdaProcessor;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.concurrent.ExecutionException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class RemoteCcdaProcessor implements IRemoteCcdaProcessor {

	private Log log;
	private ISystemSettingDomainData systemSettingDomainData;
	private ICCDAWorkflowManger cCDAWorkflowManger;
	
	private static final int SCHEDULAR_JOB_SETTINGS_KEY = SystemSettingCategoryDictionary.SchedularJobSettings.getSystemSettingCategoryKey();
	private static final int NO_OF_DAYS_SYSTEM_SETTING_KEY = SystemSettingDictionary.NumberOfDays.getSystemSettingKey();
	
	public RemoteCcdaProcessor(Log log, ISystemSettingDomainData systemSettingDomainData, ICCDAWorkflowManger iCCDAWorkflowManger) {
		this.log = log;
		this.systemSettingDomainData = systemSettingDomainData;
		this.cCDAWorkflowManger = iCCDAWorkflowManger;
	}
	
	public RemoteCcdaProcessor(ISystemSettingDomainData systemSettingDomainData, ICCDAWorkflowManger iCCDAWorkflowManger) {
		log = LogFactory.getLog(RemoteCcdaProcessor.class);
		this.systemSettingDomainData = systemSettingDomainData;
		this.cCDAWorkflowManger = iCCDAWorkflowManger;
	}
	
	public void performWork(String fromDateString, String toDateString) throws ClinicalDataException, IOException, InterruptedException, ExecutionException, Exception
	{
		if (StringUtils.isNotBlank(fromDateString) && StringUtils.isNotBlank(toDateString)) {
			Date fromDate = parseDate(fromDateString);
			Date toDate = parseDate(toDateString);
			if (fromDate != null && toDate != null) {
				log.info(String.format("running job with specific dates. (fromDate='%1s', toDate='%2s'')", fromDate , toDate));
				cCDAWorkflowManger.performWorkflow(fromDate, toDate);
			}
		}
		final Date toDateDefault = new Date();
		final Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -numberOfDaysOfRetrieveCCDA());
		final Date fromDateDefault = calendar.getTime();
		log.info(String.format("running job with default dates. (fromDateDefault='%1s', toDateDefault='%2s'')", fromDateDefault , toDateDefault));
		cCDAWorkflowManger.performWorkflow(fromDateDefault, toDateDefault);
	}
	
	private Date parseDate(String date) {
	     try {
	         return new SimpleDateFormat("yyyy-MM-dd").parse(date);
	     } catch (ParseException e) {
	         return null;
	     }
	  }
	
	private int numberOfDaysOfRetrieveCCDA() {
		try {
			final Collection<SystemSetting>  systemSettingByCategoryKeys = systemSettingDomainData.GetSystemSettingByCategoryKey(SCHEDULAR_JOB_SETTINGS_KEY);
			
			if (null == systemSettingByCategoryKeys || systemSettingByCategoryKeys.size() <= 0) {
				throw new NullPointerException(String.format(
						"Collection<SystemSetting> was null or zero count. (SystemSettingByCategoryKey='%s')",
						SCHEDULAR_JOB_SETTINGS_KEY));
			}

			SystemSetting foundSystemSetting = systemSettingByCategoryKeys.stream()
					.filter(x -> x.getSystemSettingKey() == NO_OF_DAYS_SYSTEM_SETTING_KEY).findFirst()
					.orElse(null);

			if (null == foundSystemSetting) {
				throw new NullPointerException(
						String.format("SystemSetting was null or zero count. (SystemSettingKey='%s')",
								NO_OF_DAYS_SYSTEM_SETTING_KEY));
			}			
			
			return Integer.parseInt(foundSystemSetting.getSettingValue());

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}
