package com.uhc.ucs.cdsm.eisltwo.jobprocessing;

import org.apache.commons.logging.Log;

import com.microsoft.windowsazure.services.servicebus.models.BrokeredMessage;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.IConnectionStringRetriever;
import com.uhc.ucs.cdsm.eisltwo.jobprocessing.interfaces.IQueueReadingJobProcessor;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.QueueMessageReader;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.arguments.QueueMessageReadArgs;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.compositions.ReadResult;
import com.uhc.ucs.cdsm.eisltwo.messagebroker.azureservicebus.interfaces.IQueueMessageReader;

public class QueueReadingJobProcessor implements IQueueReadingJobProcessor {

	private final Log logger;
	private final IConnectionStringRetriever connectionStringRetriever;
	private final IQueueMessageReader<String> queueMessageReader;

	public QueueReadingJobProcessor(Log lgr, IConnectionStringRetriever csr, IQueueMessageReader<String> qmr) {

		if (null == lgr) {
			throw new IllegalArgumentException("Log is null");
		}

		if (null == csr) {
			throw new IllegalArgumentException("IConnectionStringRetriever");
		}

		if (null == qmr) {
			throw new IllegalArgumentException("IQueueMessageReader");
		}

		this.logger = lgr;
		this.connectionStringRetriever = csr;
		this.queueMessageReader = qmr;
	}

	public void searchForAndInitiateJob() throws Exception {
		this.logger.debug("searchForAndInitiateJob started");

		String listenConnectionString = this.connectionStringRetriever.retrieveMessageBrokerListenConnectionString();
		
		String queueName = "Need To Get From Some Configuration Retriever";

		QueueMessageReadArgs args = new QueueMessageReadArgs();
		args.setConnectionString(listenConnectionString);
		args.setQueueName(queueName);
		ReadResult<String> readRes = this.queueMessageReader.readMessage(args, this::handleBrokeredMessage);
		System.out.println(readRes.getSuccessfulItems().size());

		this.logger.debug("searchForAndInitiateJob exiting");
	}

	private BrokeredMessage handleBrokeredMessage(BrokeredMessage message) {
		System.out.println("Body: " + message.toString());
		System.out.println("MessageID: " + message.getMessageId());
		System.out.println("Custom Property: " + message.getProperty("TestProperty"));
		return message;
	}
}
