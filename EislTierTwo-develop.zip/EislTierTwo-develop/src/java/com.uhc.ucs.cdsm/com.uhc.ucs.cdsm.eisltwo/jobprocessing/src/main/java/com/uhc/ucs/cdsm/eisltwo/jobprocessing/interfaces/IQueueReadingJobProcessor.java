package com.uhc.ucs.cdsm.eisltwo.jobprocessing.interfaces;

public interface IQueueReadingJobProcessor {
 void searchForAndInitiateJob() throws Exception;
}
