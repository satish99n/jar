package com.uhc.ucs.cdsm.datalayer.interfaces;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.function.Function;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;
import com.uhc.ucs.cdsm.domain.models.Patient;

public interface IPatientData {
	Patient GetSinglePatientByKey(long patientKey, Function<ResultSet, Patient> handleResultSetFunction)
			throws SQLException;

	Collection<ChaseRequestGroup> UpsertPatientsAndEncounters(Collection<Patient> patients,
			Function<ResultSet, Collection<ChaseRequestGroup>> handleResultSetFunction) throws SQLException;
}
