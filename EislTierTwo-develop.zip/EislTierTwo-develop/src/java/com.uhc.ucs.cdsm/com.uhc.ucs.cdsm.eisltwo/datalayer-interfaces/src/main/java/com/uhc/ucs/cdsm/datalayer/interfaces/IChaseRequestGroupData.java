package com.uhc.ucs.cdsm.datalayer.interfaces;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.function.Function;

import com.uhc.ucs.cdsm.domain.models.ChaseRequestGroup;

public interface IChaseRequestGroupData {
	ChaseRequestGroup UpsertSingle(ChaseRequestGroup pojo,
			Function<ResultSet, ChaseRequestGroup> handleResultSetFunction) throws SQLException;

	ChaseRequestGroup RetrieveSingle(long chaseRequestGroupKey,
			TwoParameterFunction<CallableStatement, ResultSet, ChaseRequestGroup> handleResultSetFunction) throws SQLException;
}
