package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers;

import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;
import oshi.hardware.HardwareAbstractionLayer;
import oshi.software.os.OperatingSystem;

public class SystemInfoDetails  {
	
	private  static String delimiter = "#";

	public static char[] getSysInfoDetails() {
		 SystemInfo systemInfo = new SystemInfo();
	        OperatingSystem operatingSystem = systemInfo.getOperatingSystem();
	        HardwareAbstractionLayer hardwareAbstractionLayer = systemInfo.getHardware();
	        CentralProcessor centralProcessor = hardwareAbstractionLayer.getProcessor();

	        StringBuilder sb = new StringBuilder(operatingSystem.getManufacturer());
	        sb.append(delimiter);
	        sb.append(centralProcessor.getSystemSerialNumber());
	        sb.append(delimiter);
	        sb.append(centralProcessor.getIdentifier());
	        sb.append(delimiter);
	        sb.append(centralProcessor.getLogicalProcessorCount());

	        return sb.toString().toCharArray();
	}
}
