package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;

public class TWConfigurationFileImplNoEncryption implements ITWConfiguration {
	
    private final Log logger;
	
	private String apiEndpoint;
	
	private String tWUnityEndpoint;
	
	private String tWUnityUser;
	
	private String tWUnityPassword;
	
	private String tWUnitySvcUser;
	
	private String tWUnitySvcPassword;
	
	private String tWUnityAppname;
	
	private String localStoragePath;
	
	private String providerGroupId;
	
	private String emrStandardCode;
	
	private String transportProtocol;
	
	private Properties props = new Properties();
	private String propertyFilePath = "allscripttwNoEncryption.properties";
	
	public TWConfigurationFileImplNoEncryption(Log lgr) throws IOException {

		if (null == lgr) {
			throw new IllegalArgumentException("Log is null");
		}

		this.logger = lgr;
		loadProperties();
	}
	
	public TWConfigurationFileImplNoEncryption() throws IOException {
		this.logger = LogFactory.getLog(TWConfigurationFileImplNoEncryption.class);
		loadProperties();
	}
	
	public void loadProperties() throws IOException {
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		try(InputStream resourceStream = loader.getResourceAsStream(propertyFilePath)) {
		    props.load(resourceStream);
		    logger.debug("Loaded properties from " + propertyFilePath);
		    
		    setApiEndpoint(props.getProperty("ehr.touchworks.fhir.endpoint"));
		    settWUnityEndpoint(props.getProperty("ehr.touchworks.unity.endpoint"));
		    settWUnityUser(props.getProperty("ehr.touchworks.unity.user"));
		    settWUnityPassword(props.getProperty("ehr.touchworks.unity.password"));
		    settWUnitySvcUser(props.getProperty("ehr.touchworks.unity.svc.user"));
		    settWUnitySvcPassword(props.getProperty("ehr.touchworks.unity.svc.password"));
		    settWUnityAppname(props.getProperty("ehr.touchworks.unity.appname"));
		    setLocalStoragePath(props.getProperty("local_storage_location"));
		    setProviderGroupId(props.getProperty("tw.ProviderGroupId"));
		    setEmrStandardCode(props.getProperty("tw.EmrStandardCode"));
		    setTransportProtocol(props.getProperty("tw.TransportProtocol"));
		}
	}
	
	@Override
	public String getApiEndpoint() {
		return apiEndpoint;
	}

	@Override
	public String getTWUnityEndpoint() {
		return tWUnityEndpoint;
	}

	@Override
	public String getTWUnityUser() {
		return tWUnityUser;
	}

	@Override
	public String getTWUnityPassword() {
		return tWUnityPassword;
	}

	@Override
	public String getTWUnitySvcUser() {
		return tWUnitySvcUser;
	}

	@Override
	public String getTWUnitySvcPassword() {
		return tWUnitySvcPassword;
	}

	@Override
	public String getTWUnityAppname() {
		return tWUnityAppname;
	}

	@Override
	public String getLocalStoragePath() {
		return localStoragePath;
	}

	public void setApiEndpoint(String apiEndpoint) {
		this.apiEndpoint = apiEndpoint;
	}

	public void settWUnityEndpoint(String tWUnityEndpoint) {
		this.tWUnityEndpoint = tWUnityEndpoint;
	}

	public void settWUnityUser(String tWUnityUser) {
		this.tWUnityUser = tWUnityUser;
	}

	public void settWUnityPassword(String tWUnityPassword) {
		this.tWUnityPassword = tWUnityPassword;
	}

	public void settWUnitySvcUser(String tWUnitySvcUser) {
		this.tWUnitySvcUser = tWUnitySvcUser;
	}

	public void settWUnitySvcPassword(String tWUnitySvcPassword) {
		this.tWUnitySvcPassword = tWUnitySvcPassword;
	}

	public void settWUnityAppname(String tWUnityAppname) {
		this.tWUnityAppname = tWUnityAppname;
	}

	public void setLocalStoragePath(String localStoragePath) {
		this.localStoragePath = localStoragePath;
	}
	
	@Override
	public String getProviderGroupId() {
		return providerGroupId;
	}

	public void setProviderGroupId(String providerGroupId) {
		this.providerGroupId = providerGroupId;
	}

	@Override
	public String getEmrStandardCode() {
		return emrStandardCode;
	}

	public void setEmrStandardCode(String emrStandardCode) {
		this.emrStandardCode = emrStandardCode;
	}

	@Override
	public String getTransportProtocol() {
		return transportProtocol;
	}

	public void setTransportProtocol(String transportProtocol) {
		this.transportProtocol = transportProtocol;
	}
}
