package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces;

public interface IJobProcessingSettingsRetriever {
	int getBetweenRunsSleepMilliseconds();
}
