package com.uhc.ucs.cdsm.eisltwo.configuration.retrievers;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.IConnectionStringRetriever;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:/configuration-spring-beans-test.xml")
public class ConnectionStringRetrieverTest {
	
	@Autowired
	private IConnectionStringRetriever connectionStringRetriever;

	@Test
	public void testRetrievePrimaryDatabaseConnectionString() {
		String expectedValue = "jdbc:sqlserver://MyMachine\\MyInstance:52931;databaseName=CoreDB;user=user1;password=mypwd#";
		assertEquals(expectedValue, connectionStringRetriever.retrievePrimaryDatabaseConnectionString());
	}

}
