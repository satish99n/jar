package com.uhc.ucs.cdsm.eisltwo.exportservices.sftpexportservice;

import java.io.InputStream;

public class FTPInformation {
	String FileDestination;
	String HostName;
	String Username;
	String Password;
	int Port;
	String FilePattern;
	InputStream inputStream;
	
	public static final int DEFAULTSFTPPORT = 22;
	
	public FTPInformation()
	{
		this.setHostName("");
		this.setUsername("");
		this.setPassword("");
		this.setFileDestination("");
		this.setFilePattern("");
		this.setPort(DEFAULTSFTPPORT);
	}

	public InputStream getInputStream() {
		return inputStream;
	}

	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}

	public int getPort() {
		return Port;
	}

	public void setPort(int port) {
		Port = port;
	}

	public String getFilePattern() {
		return FilePattern;
	}

	public void setFilePattern(String filePattern) {
		FilePattern = filePattern;
	}

	public String getFileDestination() {
		return FileDestination;
	}

	public void setFileDestination(String fileDestination) {
		FileDestination = fileDestination;
	}

	public String getHostName() {
		return HostName;
	}

	public void setHostName(String hostName) {
		HostName = hostName;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

}
