package com.uhc.ucs.cdsm.eisltwo.exportservices.sftpexportservice;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ftpserver.ftplet.FtpException;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ISFTPConfiguration;
import com.uhc.ucs.cdsm.eisltwo.configuration.retrievers.interfaces.ITWConfiguration;
import com.uhc.ucs.cdsm.eisltwo.exportservices.interfaces.IExportCCDAService;
import com.uhc.ucs.cdsm.eisltwo.exportservices.models.DocumentDetailsWrapper;

public class ExportCCDAServiceImpl implements IExportCCDAService {

	private Log logger = null;
	private ISFTPConfiguration isftpConfiguration;
	private ITWConfiguration twConfiguration;
	private SFTPService sftpService;
	private static final String FILE_EXTENSION = ".xml";
	private static final String DATEFORMAT = "yyyyMMddhhmmssSSS";
	private static final String TIMEZONE = "UTC";

	public ExportCCDAServiceImpl(ISFTPConfiguration isftpConfiguration, ITWConfiguration twConfiguration,
			SFTPService sftpService) {
		this.isftpConfiguration = isftpConfiguration;
		this.twConfiguration = twConfiguration;
		this.sftpService = sftpService;
		this.logger = LogFactory.getLog(ExportCCDAServiceImpl.class);
	}

	public ExportCCDAServiceImpl(Log lgr, ISFTPConfiguration isftpConfiguration, SFTPService sftpService) {
		this.logger = lgr;
	}

	@Override
	public void exportDocument(DocumentDetailsWrapper documentDetailsWrapper)
			throws IOException, FtpException, SftpException, JSchException {

		FTPInformation ftp = new FTPInformation();
		ftp.setUsername(isftpConfiguration.getUsername());
		ftp.setHostName(isftpConfiguration.getHostName());
		ftp.setPassword(isftpConfiguration.getPassword());
		ftp.setFileDestination(isftpConfiguration.getFileDestination());
		ftp.setPort(Integer.parseInt(isftpConfiguration.getPort()));
		try {
			ftp.setFilePattern(generateCCDADOCFileName(documentDetailsWrapper.getEncounterID(),
					documentDetailsWrapper.getPatientFullName(),
					getDateTime(documentDetailsWrapper.getDocumentCreationTime())));
		} catch (ParseException e) {
			this.logger.error(e.getMessage(), e);
			throw new FtpException(e.getMessage(), e);
		}
		InputStream inputStream = new ByteArrayInputStream(documentDetailsWrapper.getDocument());
		ftp.setInputStream(inputStream);

		String lgrMsgSuffix = String.format(" (HostName='%1s', FileDestination='%2s', FilePattern='%3s', Port='%4s')",
				isftpConfiguration.getHostName(), ftp.getFileDestination(), ftp.getFilePattern(),
				isftpConfiguration.getPort());
		this.logger.debug("About to call writeViaSFTP." + lgrMsgSuffix);
		sftpService.writeViaSFTP(ftp);
		this.logger.info("Just finished the call to writeViaSFTP." + lgrMsgSuffix);
	}

	private String generateCCDADOCFileName(String encounterID, String patientFullName, String docGenTimestamp) {

		StringBuffer fileName = new StringBuffer(twConfiguration.getProviderGroupId());
		fileName.append("_");
		fileName.append(twConfiguration.getEmrStandardCode());
		fileName.append("_");
		fileName.append(docGenTimestamp);
		fileName.append("_");
		fileName.append(twConfiguration.getTransportProtocol());
		fileName.append("_");
		fileName.append(encounterID);
		fileName.append("_");
		fileName.append(patientFullName);
		fileName.append(FILE_EXTENSION);

		return fileName.toString();
	}

	private static String getDateTime(Date docGenTimestamp) throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat(DATEFORMAT);
		dateFormat.setTimeZone(TimeZone.getTimeZone(TIMEZONE));
		return dateFormat.format(docGenTimestamp);
	}
}
