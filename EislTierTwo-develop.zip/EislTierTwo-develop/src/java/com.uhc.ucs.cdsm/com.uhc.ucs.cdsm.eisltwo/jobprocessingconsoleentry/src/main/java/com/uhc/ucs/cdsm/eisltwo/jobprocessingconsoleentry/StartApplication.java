package com.uhc.ucs.cdsm.eisltwo.jobprocessingconsoleentry;

import java.io.FileNotFoundException;
import java.net.URL;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
@ImportResource({ "classpath*:application-spring-context.xml" })
public class StartApplication {
	private static Log m_log = LogFactory
			.getLog(com.uhc.ucs.cdsm.eisltwo.jobprocessingconsoleentry.StartApplication.class);

	public static void main(String[] args) {
		try {
			URL resource = StartApplication.class.getResource("/application-spring-context.xml");
			if(resource != null && StringUtils.isNotBlank(resource.getPath())) {
				SpringApplication.run(StartApplication.class, args);
			} else {
				throw new FileNotFoundException("application-spring-context.xml not found");
			}
		} catch (BeanCreationException | FileNotFoundException ex) {
			Throwable realCause = unwrap(ex);
			m_log.error(realCause.getMessage(), realCause);
		}
	}

	public static Throwable unwrap(Throwable ex) {
		if (ex != null && BeanCreationException.class.isAssignableFrom(ex.getClass())) {
			return unwrap(ex.getCause());
		} else {
			return ex;
		}
	}
}
