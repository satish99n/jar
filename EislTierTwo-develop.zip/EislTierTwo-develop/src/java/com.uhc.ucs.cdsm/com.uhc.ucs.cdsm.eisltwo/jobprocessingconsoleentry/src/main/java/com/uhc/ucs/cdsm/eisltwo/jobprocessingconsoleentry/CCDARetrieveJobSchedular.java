package com.uhc.ucs.cdsm.eisltwo.jobprocessingconsoleentry;

import java.util.Collection;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.support.CronTrigger;

import com.uhc.ucs.cdsm.domain.dictionaries.SystemSettingCategoryDictionary;
import com.uhc.ucs.cdsm.domain.dictionaries.SystemSettingDictionary;
import com.uhc.ucs.cdsm.domain.models.SystemSetting;
import com.uhc.ucs.cdsm.eisltwo.domaindatalayer.interfaces.ISystemSettingDomainData;
import com.uhc.ucs.cdsm.eisltwo.jobprocessing.interfaces.IRemoteCcdaProcessor;

/**
 * This class has the following responsibilities.
 * Read the CRON statement.
 * Fire code against the injected dependency on that schedule.
 * Collection any input parameters and pass onto the injected dependency.
 * 
 * This class should not contain business logic for the "scheduled task".
 */
@EnableScheduling
public class CCDARetrieveJobSchedular implements SchedulingConfigurer {

	private static final int SCHEDULAR_JOB_SETTINGS_KEY = SystemSettingCategoryDictionary.SchedularJobSettings
			.getSystemSettingCategoryKey();
	private static final int CRONTAB_EXPRESSION_SYSTEM_SETTING_KEY = SystemSettingDictionary.CrontabExpression
			.getSystemSettingKey();
	private static final String CRONTAB_EXPRESSION_DEFAULT = SystemSettingDictionary.CrontabExpression.getSettingDefaultValue();

	private Log log;
	private ISystemSettingDomainData systemSettingDomainData;
	private IRemoteCcdaProcessor remoteCcdaProcessor;

	public CCDARetrieveJobSchedular(Log log, ISystemSettingDomainData systemSettingDomainData,
			IRemoteCcdaProcessor ircp) {
		this.log = log;
		this.systemSettingDomainData = systemSettingDomainData;
		this.remoteCcdaProcessor = ircp;
	}

	public CCDARetrieveJobSchedular(ISystemSettingDomainData systemSettingDomainData, IRemoteCcdaProcessor ircp) {
		log = LogFactory.getLog(CCDARetrieveJobSchedular.class);
		this.systemSettingDomainData = systemSettingDomainData;
		this.remoteCcdaProcessor = ircp;
	}

	private String retrieveCronConfigurationValue() {
		try {
			final Collection<SystemSetting> systemSettingByCategoryKeys = systemSettingDomainData
					.GetSystemSettingByCategoryKey(SCHEDULAR_JOB_SETTINGS_KEY);

			if (null == systemSettingByCategoryKeys || systemSettingByCategoryKeys.size() <= 0) {
				throw new NullPointerException(String.format(
						"Collection<SystemSetting> was null or zero count. (SystemSettingByCategoryKey='%s')",
						SCHEDULAR_JOB_SETTINGS_KEY));
			}

			SystemSetting foundSystemSetting = systemSettingByCategoryKeys.stream()
					.filter(x -> x.getSystemSettingKey() == CRONTAB_EXPRESSION_SYSTEM_SETTING_KEY).findFirst()
					.orElse(null);

			if (null == foundSystemSetting) {
				throw new NullPointerException(
						String.format("SystemSetting was null or zero count. (SystemSettingKey='%s')",
								CRONTAB_EXPRESSION_SYSTEM_SETTING_KEY));
			}

			return foundSystemSetting.getSettingValue();

		} catch (Exception e) {
			log.error("Exception while retrieving crontab expression value:", e);
			throw new RuntimeException(e);
		}
		
		////return CRONTAB_EXPRESSION_DEFAULT;
	}

	@Override
	public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
		taskRegistrar.addTriggerTask(new Runnable() {
			@Override
			public void run() {
				
				String fromDateString = "";
				String toDateString = "";
				
				log.debug("run started");
				try {
					fromDateString = System.getProperty("fromDate");
					toDateString = System.getProperty("toDate");
					/* now pass any collected parameters to the injected dependency */
					log.debug(String.format("IRemoteCcdaProcessor about to be called (fromDate='%1s', toDate='%2s')", fromDateString, toDateString));
					remoteCcdaProcessor.performWork(fromDateString, toDateString);
					
				} catch (Exception e) {
					log.error("Exception while executing the workflowManager.", e);
				}
				finally {
					System.clearProperty("fromDate");
					System.clearProperty("toDate");
				}
			
				log.debug(String.format("run ended (fromDate='%1s', toDate='%2s')", fromDateString, toDateString));
			}
		}, new Trigger() {
			@Override
			public Date nextExecutionTime(TriggerContext triggerContext) {
				String cron = retrieveCronConfigurationValue();
				log.info(cron);
				CronTrigger trigger = new CronTrigger(cron);
				return trigger.nextExecutionTime(triggerContext);
			}
		});
	}
}
