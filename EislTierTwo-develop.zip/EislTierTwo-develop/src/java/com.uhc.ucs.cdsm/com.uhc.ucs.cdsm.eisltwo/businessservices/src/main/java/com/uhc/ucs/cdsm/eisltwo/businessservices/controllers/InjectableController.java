package com.uhc.ucs.cdsm.eisltwo.businessservices.controllers;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.logging.Log;

import org.springframework.beans.factory.annotation.Autowire;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InjectableController {

//	private final Log logger;
//
//	public InjectableController(Log lgr) {
//
//		if (null == lgr) {
//			throw new IllegalArgumentException("Log is null");
//		}
//
//		this.logger = lgr;
//	}

	@GetMapping("/injectGreeting")
	public String getGreeting() {
		String currentDateString = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
		return "Hello Spring World! '" + currentDateString + "'";
	}

	@RequestMapping(value = "/injectDocument", method = RequestMethod.GET)
	public ResponseEntity<String> getDocument() {

		String payload = "getDocument "
				+ LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));

		Boolean noError = true;
		if (noError) {
			return new ResponseEntity<String>(payload, HttpStatus.OK);
		} else {
			return new ResponseEntity<String>(payload, HttpStatus.BAD_REQUEST);
		}
	}
}